from pathlib import Path
import json,subprocess,shlex,os
root=Path(__file__).resolve().parent.parent
scratch=root/'.local-inputs/fx-alignment-v28';scratch.mkdir(exist_ok=True)
os.environ['TMP']=str(scratch);os.environ['TEMP']=str(scratch)
db=json.loads((root/'port/android-native/app/.cxx/Debug/5a1n3w3m/arm64-v8a/compile_commands.json').read_text())
entry=next(e for e in db if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
args=entry.get('arguments')or[s.strip('"')for s in shlex.split(entry['command'],posix=False)]
flags=[s for s in args[1:]if s.startswith(('--target=','--sysroot=','-I','-isystem'))]
for i,s in enumerate(args):
 if s=='-isystem':flags.append(args[i+1])
sources=['.local-inputs/fx_visual_outer_v28_oracle.cpp','port/level-world/source_fx_node_matrix_v4.cpp','port/level-world/character_fx_anchor_rotation_v28.cpp','port/level-world/visual_motion.cpp','port/level-world/physical_controls.cpp','port/engine-math/math.cpp','port/scene-materials/scene.cpp']
cmd=[args[0],*flags,'-std=c++17','-O1','-fno-builtin','-fPIC','-shared','-static-libstdc++','-DDH2_VISUAL_KERNEL_ONLY','-fno-fast-math','-ffp-contract=off',*[str(root/p)for p in sources],'-o',str(scratch/'libfx_visual_outer_v28.so')]
run=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(scratch/'compile.log').write_text(run.stdout+run.stderr);print(run.returncode,run.stderr[:4000]);assert run.returncode==0
