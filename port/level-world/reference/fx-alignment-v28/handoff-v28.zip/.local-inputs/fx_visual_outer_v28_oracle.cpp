#include "../port/level-world/source_fx_node_matrix_v4.hpp"
#include "../port/level-world/character_fx_anchor_rotation_v28.hpp"
extern "C" int dh2_fx_visual_outer_v28(dh2::math::Matrix4f* out,const float* p,const float* r,const float* s){
 if(!out||!p||!r||!s)return -1;dh2::fx::source_fx_trs_matrix_v4(*out,p,r,s);return 0;
}
extern "C" int dh2_fx_anchor_rotation_v28(float* out,const dh2::visual::Root* root){if(!out||!root)return -1;std::string e;return dh2::fx::character_fx_anchor_rotation_v28(out,*root,e)?0:-1;}
