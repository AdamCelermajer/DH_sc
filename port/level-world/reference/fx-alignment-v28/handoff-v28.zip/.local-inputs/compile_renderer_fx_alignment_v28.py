from pathlib import Path
p=Path(__file__).with_name('compile_renderer_kill_live_v21.py');s=p.read_text()
s=s.replace("s=src.read_text();s='#include \"character_kill_live_v21.hpp\"\\n#include \"character_kill_loot_connection_v10.hpp\"\\n'+s",'s=src.read_text()')
s=s.replace("key='#include \"renderer_npc_death_v2.inc\"';assert key in s;s=s.replace(key,key+'\\n#include \"renderer_character_kill_live_v21.inc\"')",'')
s=s.replace('model_renderer_kill_live_v21.cpp','model_renderer_fx_alignment_v28.cpp').replace('renderer_kill_live_v21_','renderer_fx_alignment_v28_')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
