from pathlib import Path
p=Path(__file__).with_name('compile_authored_fx_v4.py');s=p.read_text();a=s.index('files=[');b=s.index('\nfor abi',a)
s=s[:a]+"files=['port/level-world/source_fx_node_matrix_v4.cpp','port/level-world/character_fx_anchor_rotation_v28.cpp','port/level-world/character_mesh_fx_owner_v4.cpp']"+s[b:]
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
