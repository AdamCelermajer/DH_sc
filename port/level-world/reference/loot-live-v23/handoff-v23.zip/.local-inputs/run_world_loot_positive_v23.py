from pathlib import Path
import json,os,sys,subprocess
root=Path(__file__).resolve().parent.parent
scratch=root/'.local-inputs/loot-v23-compiler-temp';scratch.mkdir(exist_ok=True)
os.environ['TMP']=str(scratch);os.environ['TEMP']=str(scratch)
remote='/data/local/tmp/dh2-loot-v23-positive-data'
compile_only='--compile-only' in sys.argv
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
def push(p,name):
 if compile_only:return
 subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote+'/'+str(Path(name).parent).replace('\\','/')],check=True,capture_output=True)
 subprocess.run([adb,'-s','emulator-5554','push',str(p),remote+'/'+name],check=True,capture_output=True)
paths=[('.local-inputs/player-loot-v7/cache','loot',['loot_table_pyarray.bin','loot_table_pyarraynames.bin','loot_table_pystructnames.bin']),('.local-inputs/loot-world-v8/cache','audiovisual',['loot_audiovisual_pyarray.bin','loot_audiovisual_pyarraynames.bin','loot_audiovisual_pystructnames.bin']),('.local-inputs/item-visual-cache-v2','visual',['itemdrops.bdae'])]
for folder,name,names in paths:
 for fn in names:push(root/folder/fn,name+'/'+fn)
push(root/'port/level-world/reference/character-game-design/real-cache-inputs.bin','design.bin')
assets=root/'port/android-native/app/src/main/assets'
for p in (assets/'original-cache/data/pydata').glob('common_text_*.bin'):push(p,'assets/original-cache/data/pydata/'+p.name)
for fn in ['fonts_pyarray.bin','fonts_pystructnames.bin']:push(assets/'data'/fn,'assets/original-cache/data/pydata/'+fn)
# Exact same localization assets consumed by the existing ItemText owner.
for p in (assets/'original-cache/data/text').glob('*.english'):push(p,'assets/original-cache/data/'+p.relative_to(assets/'original-cache/data').as_posix())
for p in (assets/'original-cache/data/text').glob('*.symbols'):push(p,'assets/original-cache/data/'+p.relative_to(assets/'original-cache/data').as_posix())
if not compile_only:subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote+'/private'],check=True,capture_output=True)
receipt=json.loads((root/'port/level-world/reports/android-native-owner-tests/world-item-pool-graph-v3/receipt.json').read_text())
sources=[s['path'].replace('\\','/')for s in receipt['sources']][1:]
sources.insert(0,'port/level-world/tests/world_loot_positive_v23.cpp')
sources+=['port/level-world/canonical_object_manager_v1.cpp','port/level-world/canonical_property_map_v1.cpp','port/level-world/world_item_live_owner_v5.cpp','port/level-world/world_item_pf_connection_v4.cpp','port/level-world/game_object_initialization_owner_v1.cpp','port/level-world/character_game_design.cpp','port/engine-ui/character_menu_font_palette_v1.cpp','port/level-world/vox_play3d_owner_v2.cpp']
p=Path(__file__).with_name('root_android_linked_owner_test.py')
s=p.read_text().replace("remote='/data/local/tmp/dh2-linked-'+name","remote='/data/local/tmp/dh2-loot-v23-'+name").replace("'-Wno-misleading-indentation'","'-Wno-misleading-indentation','-Wno-unused-private-field'")
if compile_only:
 s=s.replace("remote='/data/local/tmp/dh2-loot-v23-'+name", "(out/'build-only.json').write_text(json.dumps(dict(status='COMPILED_NOT_EXECUTED',apk_sha256=apk_hash,sources=hashes,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),compile=cmd),indent=2));print('COMPILED_NOT_EXECUTED '+str(binary));raise SystemExit(0)\nremote='/data/local/tmp/dh2-loot-v23-'+name")
sys.argv=[str(p),'positive',*dict.fromkeys(sources),'--',*[remote+'/'+name for name in ['loot','audiovisual','visual','design.bin','assets','private']]]
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
