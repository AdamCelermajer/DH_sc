from pathlib import Path
p=Path(__file__).with_name('compile_renderer_kill_live_v21.py');s=p.read_text()
s=s.replace('character_kill_live_v21.hpp','world_loot_gameplay_v23.hpp').replace('character_kill_loot_connection_v10.hpp','renderer_loot_gpu_v27.hpp')
s=s.replace("s='#include", "s='#include \\\"condition_data_init_v3.hpp\\\"\\n#include \\\"game_object_spawn_probability_v1.hpp\\\"\\n#include")
s=s.replace('renderer_npc_death_v2.inc','renderer_canonical_world_v4.inc').replace('renderer_character_kill_live_v21.inc','renderer_item_graph_v4.inc"\n#include "renderer_character_loot_gameplay_v23.inc')
# Preserve Python source escaping for the inserted C++ include string.
s=s.replace('renderer_item_graph_v4.inc"\n#include "renderer_character_loot_gameplay_v23.inc','renderer_item_graph_v4.inc"\\n#include "renderer_character_loot_gameplay_v23.inc')
s=s.replace('model_renderer_kill_live_v21.cpp','model_renderer_loot_gameplay_v23.cpp').replace('renderer_kill_live_v21_','renderer_loot_gameplay_v23_')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
