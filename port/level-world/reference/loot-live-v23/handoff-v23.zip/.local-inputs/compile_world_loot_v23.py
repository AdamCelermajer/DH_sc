from pathlib import Path
p=Path(__file__).with_name('compile_authored_fx_v4.py');s=p.read_text();a=s.index('files=[');b=s.index('\nfor abi',a)
s=s[:a]+"files=['port/level-world/gameobject_update_prefix_v23.cpp','port/level-world/status_message_owner_v23.cpp','port/level-world/world_loot_pickup_v23.cpp','port/level-world/world_loot_gameplay_v23.cpp','port/level-world/world_item_visual_v2.cpp','port/level-world/world_item_live_owner_v5.cpp']"+s[b:]
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
