# _ZN6CharAI16AI_DoRangeAttackEP10GameObjectb
003d076c: push {r4, r5, r6, r7, r8, sb, sl, fp, lr}
003d0770: ldr r4, [pc, #0x3dc]
003d0774: ldr r5, [pc, #0x3dc]
003d0778: mov r6, r0
003d077c: add r4, pc, r4
003d0780: ldr r0, [r4, r5]
003d0784: mov r7, r1
003d0788: ldr r3, [r6, #4]
003d078c: ldr r1, [r0]
003d0790: sub sp, sp, #0xc4
003d0794: mov r0, r3
003d0798: str r1, [sp, #0xbc]
003d079c: ldr r3, [r3]
003d07a0: mov r8, r2
003d07a4: mov lr, pc
003d07a8: ldr pc, [r3, #0x34]
003d07ac: cmp r0, #0
003d07b0: bne #0x3d07c4
003d07b4: ldr r3, [r6, #4]
003d07b8: ldr r2, [r3, #0x528]
003d07bc: tst r2, #1
003d07c0: beq #0x3d07e0
003d07c4: ldr r3, [r4, r5]
003d07c8: ldr r2, [sp, #0xbc]
003d07cc: ldr r3, [r3]
003d07d0: cmp r2, r3
003d07d4: bne #0x3d0b50
003d07d8: add sp, sp, #0xc4
003d07dc: pop {r4, r5, r6, r7, r8, sb, sl, fp, pc}
003d07e0: mov r0, r3
003d07e4: ldr ip, [r3]
003d07e8: add r1, sp, #0x64
003d07ec: add r2, sp, #0x60
003d07f0: add r3, sp, #0x5c
003d07f4: mov lr, pc
003d07f8: ldr pc, [ip, #0x128]
003d07fc: cmp r0, #0
003d0800: beq #0x3d0910
003d0804: ldr r0, [r6, #4]
003d0808: add r0, r0, #0x4f0
003d080c: add r0, r0, #0xc
003d0810: bl #0x3c02d0
003d0814: subs sl, r0, #0
003d0818: beq #0x3d0924
003d081c: ldrb r7, [r6, #0x79]
003d0820: cmp r7, #0
003d0824: bne #0x3d07c4
003d0828: ldr fp, [pc, #0x32c]
003d082c: add r8, sp, #0xa4
003d0830: add sl, sp, #8
003d0834: ldr sb, [r4, fp]
003d0838: mov r0, sb
003d083c: bl #0x337888
003d0840: ldr r1, [pc, #0x318]
003d0844: add r2, sp, #0x70
003d0848: mov r0, r8
003d084c: add r1, pc, r1
003d0850: bl #0x3140ec
003d0854: mov r1, r8
003d0858: mov r0, sb
003d085c: bl #0x337a88
003d0860: mov r0, r8
003d0864: bl #0x318254
003d0868: mov ip, #1
003d086c: ldr r1, [r6, #4]
003d0870: mov r3, r7
003d0874: mov r2, ip
003d0878: mov r0, sl
003d087c: str ip, [sp]
003d0880: bl #0x4a2730
003d0884: ldr r3, [r6, #4]
003d0888: ldrb r1, [r3, #0x1b5]
003d088c: cmp r1, #0
003d0890: bne #0x3d099c
003d0894: ldr r3, [r6, #0x40]
003d0898: cmp r3, #0
003d089c: beq #0x3d08b0
003d08a0: mov r0, r6
003d08a4: bl #0x3d67f4
003d08a8: cmp r0, #0
003d08ac: bne #0x3d0ab4
003d08b0: mov r0, sl
003d08b4: bl #0x3d015c
003d08b8: ldr r0, [sp, #0x60]
003d08bc: bl #0x30e964
003d08c0: movw r2, #0xfdb
003d08c4: mov r1, r0
003d08c8: movt r2, #0x40c9
003d08cc: mov r0, sl
003d08d0: bl #0x3d0020
003d08d4: ldr r3, [sp, #8]
003d08d8: ldr r2, [sp, #0x18]
003d08dc: cmp r2, r3
003d08e0: beq #0x3d0904
003d08e4: ldr r1, [r3]
003d08e8: mov r0, r6
003d08ec: mov r2, #0
003d08f0: bl #0x3d6890
003d08f4: ldr r3, [sp, #8]
003d08f8: ldr r0, [r6, #4]
003d08fc: ldr r1, [r3]
003d0900: bl #0x393d48
003d0904: mov r0, sl
003d0908: bl #0x38d18c
003d090c: b #0x3d07c4
003d0910: mov r0, r6
003d0914: mov r1, r7
003d0918: mov r2, r8
003d091c: bl #0x3d01ac
003d0920: b #0x3d07c4
003d0924: ldr r3, [pc, #0x230]
003d0928: add sb, sp, #0x74
003d092c: ldr fp, [r4, r3]
003d0930: mov r0, fp
003d0934: bl #0x337888
003d0938: ldr r1, [pc, #0x224]
003d093c: add r2, sp, #0x68
003d0940: mov r0, sb
003d0944: add r1, pc, r1
003d0948: bl #0x3140ec
003d094c: mov r1, sb
003d0950: mov r0, fp
003d0954: bl #0x337a88
003d0958: mov r0, sb
003d095c: bl #0x318254
003d0960: cmp r7, #0
003d0964: strb sl, [r6, #0x78]
003d0968: beq #0x3d09f4
003d096c: mov r1, r7
003d0970: ldr r0, [r6, #4]
003d0974: bl #0x393d48
003d0978: cmp r8, #0
003d097c: bne #0x3d07c4
003d0980: ldr r0, [r6, #4]
003d0984: mov r1, r8
003d0988: mov r2, r8
003d098c: add r0, r0, #0x4f0
003d0990: add r0, r0, #0xc
003d0994: bl #0x3c6488
003d0998: b #0x3d07c4
003d099c: ldr r3, [pc, #0x1c4]
003d09a0: ldr r1, [pc, #0x1c4]
003d09a4: ldr r2, [pc, #0x1c4]
003d09a8: ldr r3, [r4, r3]
003d09ac: add r1, pc, r1
003d09b0: add r2, pc, r2
003d09b4: ldr r0, [r3, #0x2c]
003d09b8: bl #0x4c4bdc
003d09bc: mov r8, r0
003d09c0: ldr r0, [sp, #0x60]
003d09c4: bl #0x30e964
003d09c8: mov r7, r0
003d09cc: asr r0, r8, #1
003d09d0: bl #0x30e964
003d09d4: movw r1, #0xfa35
003d09d8: movt r1, #0x3c8e
003d09dc: bl #0x30ed6c
003d09e0: mov r1, r7
003d09e4: mov r2, r0
003d09e8: mov r0, sl
003d09ec: bl #0x3d0020
003d09f0: b #0x3d08d4
003d09f4: mov ip, #1
003d09f8: add sl, sp, #8
003d09fc: ldr r1, [r6, #4]
003d0a00: mov r3, r7
003d0a04: mov r2, ip
003d0a08: mov r0, sl
003d0a0c: str ip, [sp]
003d0a10: bl #0x4a2730
003d0a14: ldr r3, [r6, #4]
003d0a18: ldrb r3, [r3, #0x1b5]
003d0a1c: cmp r3, #0
003d0a20: beq #0x3d0b28
003d0a24: ldr r3, [pc, #0x13c]
003d0a28: ldr r1, [pc, #0x144]
003d0a2c: ldr r2, [pc, #0x144]
003d0a30: ldr r3, [r4, r3]
003d0a34: add r1, pc, r1
003d0a38: add r2, pc, r2
003d0a3c: ldr r0, [r3, #0x2c]
003d0a40: bl #0x4c4bdc
003d0a44: mov sb, r0
003d0a48: ldr r0, [sp, #0x60]
003d0a4c: bl #0x30e964
003d0a50: mov r7, r0
003d0a54: asr r0, sb, #1
003d0a58: bl #0x30e964
003d0a5c: movw r1, #0xfa35
003d0a60: movt r1, #0x3c8e
003d0a64: bl #0x30ed6c
003d0a68: mov r1, r7
003d0a6c: mov r2, r0
003d0a70: mov r0, sl
003d0a74: bl #0x3d0020
003d0a78: ldr r3, [sp, #8]
003d0a7c: ldr r2, [sp, #0x18]
003d0a80: cmp r2, r3
003d0a84: beq #0x3d0aa8
003d0a88: ldr r1, [r3]
003d0a8c: mov r0, r6
003d0a90: mov r2, #0
003d0a94: bl #0x3d6890
003d0a98: ldr r3, [sp, #8]
003d0a9c: ldr r0, [r6, #4]
003d0aa0: ldr r1, [r3]
003d0aa4: bl #0x393d48
003d0aa8: mov r0, sl
003d0aac: bl #0x38d18c
003d0ab0: b #0x3d0978
003d0ab4: ldr r3, [r6, #0x40]
003d0ab8: mov r0, r3
003d0abc: ldr r3, [r3]
003d0ac0: mov lr, pc
003d0ac4: ldr pc, [r3, #0x34]
003d0ac8: cmp r0, #0
003d0acc: bne #0x3d08b0
003d0ad0: ldr r3, [r6, #4]
003d0ad4: mov r0, r3
003d0ad8: ldr r3, [r3]
003d0adc: mov lr, pc
003d0ae0: ldr pc, [r3, #0x28]
003d0ae4: cmp r0, #0
003d0ae8: beq #0x3d08d4
003d0aec: ldr r8, [r4, fp]
003d0af0: add r7, sp, #0x8c
003d0af4: mov r0, r8
003d0af8: bl #0x337888
003d0afc: ldr r1, [pc, #0x78]
003d0b00: add r2, sp, #0x6c
003d0b04: mov r0, r7
003d0b08: add r1, pc, r1
003d0b0c: bl #0x3140ec
003d0b10: mov r0, r8
003d0b14: mov r1, r7
003d0b18: bl #0x337a88
003d0b1c: mov r0, r7
003d0b20: bl #0x318254
003d0b24: b #0x3d08d4
003d0b28: mov r0, sl
003d0b2c: bl #0x3d015c
003d0b30: ldr r0, [sp, #0x60]
003d0b34: bl #0x30e964
003d0b38: movw r2, #0xfdb
003d0b3c: mov r1, r0
003d0b40: movt r2, #0x40c9
003d0b44: mov r0, sl
003d0b48: bl #0x3d0020
003d0b4c: b #0x3d0a78
003d0b50: bl #0x30e310
003d0b54: subseq r4, ip, r4, lsl r3
003d0b58: andeq r4, r0, ip, lsr #1
003d0b5c: andeq r0, r0, r4, lsl #17
003d0b60: subeq r4, pc, r4, asr #24
003d0b64: subeq r4, pc, ip, asr #22
003d0b68: strdeq r3, r4, [r0], -r4
003d0b6c: subeq r0, pc, r4, lsr #27
003d0b70: strdeq r4, r5, [pc], #-0xa8
003d0b74: subeq r0, pc, ip, lsl sp
003d0b78: subeq r4, pc, r0, ror sl
003d0b7c: strheq r4, [pc], #-0x98

# _ZN6CharAI17_HandleProjectileEP10ProjectilePv
003cc280: push {r4, r5, r6, r7, r8, lr}
003cc284: ldr r6, [pc, #0x198]
003cc288: subs r7, r0, #0
003cc28c: sub sp, sp, #0x40
003cc290: add r6, pc, r6
003cc294: beq #0x3cc3b4
003cc298: ldr r5, [r7, #0x3cc]
003cc29c: ldr r4, [r7, #0x380]
003cc2a0: cmp r5, #0
003cc2a4: moveq r8, r5
003cc2a8: beq #0x3cc2c8
003cc2ac: add r8, sp, #0x34
003cc2b0: mov r0, r8
003cc2b4: mov r1, r5
003cc2b8: bl #0x33dd2c
003cc2bc: mov r0, r8
003cc2c0: bl #0x33ff54
003cc2c4: mov r8, r0
003cc2c8: cmp r4, #0
003cc2cc: beq #0x3cc360
003cc2d0: ldr r3, [r4, #0x3c8]
003cc2d4: add r0, r4, #0x3c8
003cc2d8: mov r1, r5
003cc2dc: mov lr, pc
003cc2e0: ldr pc, [r3, #0xac]
003cc2e4: cmp r5, #0
003cc2e8: beq #0x3cc358
003cc2ec: cmp r8, #0
003cc2f0: beq #0x3cc33c
003cc2f4: ldrb ip, [r7, #0x37c]
003cc2f8: add r5, sp, #0xc
003cc2fc: mov r3, #0
003cc300: mov r0, r5
003cc304: mov r1, r4
003cc308: mov r2, r8
003cc30c: str ip, [sp]
003cc310: bl #0x3b3368
003cc314: mov r0, r5
003cc318: mov r1, r4
003cc31c: mov r2, r8
003cc320: mov r3, #0
003cc324: bl #0x3b10b4
003cc328: ldrb r0, [sp, #0x24]
003cc32c: ands r0, r0, #3
003cc330: movne r0, #1
003cc334: add sp, sp, #0x40
003cc338: pop {r4, r5, r6, r7, r8, pc}
003cc33c: mov r1, r4
003cc340: ldr r3, [r5]
003cc344: mov r0, r5
003cc348: mov lr, pc
003cc34c: ldr pc, [r3, #0x90]
003cc350: cmp r0, #8
003cc354: beq #0x3cc408
003cc358: mov r0, #0
003cc35c: b #0x3cc334
003cc360: ldr r3, [pc, #0xc0]
003cc364: ldr r3, [r6, r3]
003cc368: ldr r3, [r3]
003cc36c: cmp r3, #2
003cc370: streq r4, [r4]
003cc374: beq #0x3cc2d0
003cc378: cmp r3, #1
003cc37c: bne #0x3cc2d0
003cc380: ldr r0, [pc, #0xa4]
003cc384: ldr r1, [pc, #0xa4]
003cc388: ldr r2, [pc, #0xa4]
003cc38c: ldr r0, [r6, r0]
003cc390: ldr r3, [pc, #0xa0]
003cc394: mov ip, #0xf4
003cc398: add r1, pc, r1
003cc39c: add r2, pc, r2
003cc3a0: add r3, pc, r3
003cc3a4: add r0, r0, #0xa8
003cc3a8: str ip, [sp]
003cc3ac: bl #0x30e004
003cc3b0: b #0x3cc2d0
003cc3b4: ldr r3, [pc, #0x6c]
003cc3b8: ldr r3, [r6, r3]
003cc3bc: ldr r3, [r3]
003cc3c0: cmp r3, #2
003cc3c4: streq r7, [r7]
003cc3c8: beq #0x3cc298
003cc3cc: cmp r3, #1
003cc3d0: bne #0x3cc298
003cc3d4: ldr r0, [pc, #0x50]
003cc3d8: ldr r1, [pc, #0x5c]
003cc3dc: ldr r2, [pc, #0x5c]
003cc3e0: ldr r0, [r6, r0]
003cc3e4: ldr r3, [pc, #0x58]
003cc3e8: mov ip, #0xee
003cc3ec: add r1, pc, r1
003cc3f0: add r2, pc, r2
003cc3f4: add r3, pc, r3
003cc3f8: add r0, r0, #0xa8
003cc3fc: str ip, [sp]
003cc400: bl #0x30e004
003cc404: b #0x3cc298
003cc408: mov r0, r5
003cc40c: mov r1, r7
003cc410: ldr r3, [r5]
003cc414: mov lr, pc
003cc418: ldr pc, [r3, #0x98]
003cc41c: mov r0, r8
003cc420: b #0x3cc334
003cc424: subseq r8, ip, r0, lsl #16
003cc428: andeq r3, r0, r0, asr #19
003cc42c: andeq r1, r0, r0, asr #19
003cc430: subeq r2, pc, r0, asr #32
003cc434: subeq r8, pc, ip, lsl #29
003cc438: subeq r8, pc, r8, lsl lr
003cc43c: subeq r1, pc, ip, ror #31
003cc440: subeq ip, pc, r8, asr sp
003cc444: subeq r8, pc, r4, asr #27

# _ZN17CharAISkillScript15SpawnProjectileEjb
003da510: ldr r3, [pc, #0x60]
003da514: mov ip, r0
003da518: ldr r0, [pc, #0x5c]
003da51c: push {r4, r5, lr}
003da520: add r3, pc, r3
003da524: ldr r0, [r3, r0]
003da528: mov r4, r2
003da52c: sub sp, sp, #0x14
003da530: ldr r2, [r0]
003da534: cmp r2, r1
003da538: movls r0, #0
003da53c: bls #0x3da570
003da540: ldr lr, [pc, #0x38]
003da544: ldr r5, [pc, #0x38]
003da548: ldr r2, [pc, #0x38]
003da54c: ldr lr, [r3, lr]
003da550: ldr r5, [r3, r5]
003da554: ldr r0, [r3, r2]
003da558: ldr r2, [ip, #4]
003da55c: mov r3, #0
003da560: stm sp, {r5, lr}
003da564: str ip, [sp, #8]
003da568: str r4, [sp, #0xc]
003da56c: bl #0x3e701c
003da570: add sp, sp, #0x14
003da574: pop {r4, r5, pc}
003da578: subseq sl, fp, r0, ror r5
003da57c: andeq r0, r0, r0, ror sb
003da580: andeq r3, r0, r0, asr r1
003da584: andeq r2, r0, r4, asr #21
003da588: andeq r0, r0, ip, asr #16

# _ZN17CharAISkillScript15SpawnProjectileEjf
003da494: ldr r3, [pc, #0x60]
003da498: mov ip, r0
003da49c: ldr r0, [pc, #0x5c]
003da4a0: push {r4, r5, lr}
003da4a4: add r3, pc, r3
003da4a8: ldr r0, [r3, r0]
003da4ac: mov r4, r2
003da4b0: sub sp, sp, #0x14
003da4b4: ldr r2, [r0]
003da4b8: cmp r2, r1
003da4bc: movls r0, #0
003da4c0: bls #0x3da4f4
003da4c4: ldr lr, [pc, #0x38]
003da4c8: ldr r5, [pc, #0x38]
003da4cc: ldr r2, [pc, #0x38]
003da4d0: ldr lr, [r3, lr]
003da4d4: ldr r5, [r3, r5]
003da4d8: ldr r0, [r3, r2]
003da4dc: ldr r2, [ip, #4]
003da4e0: mov r3, #0
003da4e4: stm sp, {r5, lr}
003da4e8: str ip, [sp, #8]
003da4ec: str r4, [sp, #0xc]
003da4f0: bl #0x3e6edc
003da4f4: add sp, sp, #0x14
003da4f8: pop {r4, r5, pc}
003da4fc: subseq sl, fp, ip, ror #11
003da500: andeq r0, r0, r0, ror sb
003da504: andeq r3, r0, r0, asr r1
003da508: andeq r2, r0, r4, asr #21
003da50c: andeq r0, r0, ip, asr #16

# _ZN17CharAISkillScript14_ProjectileHitEP10ProjectilePv
003dae7c: push {r4, r5, r6, r7, r8, sl, lr}
003dae80: ldr r4, [pc, #0x15c]
003dae84: ldr r8, [pc, #0x15c]
003dae88: sub sp, sp, #0x3c
003dae8c: add r4, pc, r4
003dae90: ldr r3, [r4, r8]
003dae94: mov sl, r0
003dae98: add r5, sp, #0xc
003dae9c: ldr r3, [r3]
003daea0: mov r0, sp
003daea4: mov r7, r1
003daea8: str r3, [sp, #0x34]
003daeac: bl #0x3192b4
003daeb0: mov r0, r5
003daeb4: bl #0x31b434
003daeb8: ldr r3, [r7, #4]
003daebc: mov r6, sp
003daec0: ldr r0, [r3, #0x3e4]
003daec4: cmp r0, #0
003daec8: beq #0x3dafd8
003daecc: ldr r1, [pc, #0x118]
003daed0: mov r3, r5
003daed4: add r2, r7, #0xc
003daed8: add r1, pc, r1
003daedc: bl #0x37c390
003daee0: ldr r3, [sp, #0x14]
003daee4: cmp r3, #0
003daee8: beq #0x3daf20
003daeec: mov r7, #0
003daef0: mov r0, r5
003daef4: bl #0x31b398
003daef8: mov r0, sp
003daefc: bl #0x319228
003daf00: ldr r3, [r4, r8]
003daf04: ldr r2, [sp, #0x34]
003daf08: mov r0, r7
003daf0c: ldr r3, [r3]
003daf10: cmp r2, r3
003daf14: bne #0x3dafe0
003daf18: add sp, sp, #0x3c
003daf1c: pop {r4, r5, r6, r7, r8, sl, pc}
003daf20: mov r0, sp
003daf24: ldr r1, [sl, #0x3cc]
003daf28: bl #0x386f28
003daf2c: mov r0, sp
003daf30: mov r1, sl
003daf34: bl #0x31a46c
003daf38: ldr r0, [sp, #0x30]
003daf3c: ldm r0, {r1, r2}
003daf40: cmp r1, r2
003daf44: beq #0x3daf50
003daf48: add r3, sp, #8
003daf4c: bl #0x31c3cc
003daf50: ldr r3, [r7, #4]
003daf54: ldr r1, [pc, #0x94]
003daf58: mov r2, sp
003daf5c: ldr r0, [r3, #0x3e4]
003daf60: add r1, pc, r1
003daf64: mov r3, r5
003daf68: bl #0x37c390
003daf6c: ldr r7, [sp, #0x14]
003daf70: cmp r7, #0
003daf74: bne #0x3daeec
003daf78: ldr r2, [sp, #0x30]
003daf7c: ldr r3, [r2]
003daf80: ldr r2, [r2, #4]
003daf84: rsb r3, r3, r2
003daf88: asr r3, r3, #4
003daf8c: add r2, r3, r3, lsl #3
003daf90: add r2, r2, r2, lsl #6
003daf94: add r2, r3, r2, lsl #3
003daf98: add r2, r2, r2, lsl #15
003daf9c: add r3, r3, r2, lsl #3
003dafa0: cmp r3, #0
003dafa4: beq #0x3daeec
003dafa8: mov r0, r5
003dafac: mov r1, r7
003dafb0: bl #0x3da43c
003dafb4: ldr r3, [r0, #4]
003dafb8: cmp r3, #1
003dafbc: bne #0x3daeec
003dafc0: mov r1, r7
003dafc4: mov r0, r5
003dafc8: bl #0x3da43c
003dafcc: bl #0x31bc80
003dafd0: cmp r0, #0
003dafd4: bne #0x3daeec
003dafd8: mov r7, #1
003dafdc: b #0x3daef0
003dafe0: bl #0x30e310
003dafe4: subseq sb, fp, r4, lsl #24
003dafe8: andeq r4, r0, ip, lsr #1
003dafec: subeq sl, lr, r8, ror sb
003daff0: subeq sl, lr, r8, ror #18

# _ZN17CharAISkillScript16_ProjectileCheckEP10ProjectilePv
003daff4: push {r4, r5, r6, r7, r8, sl, lr}
003daff8: ldr r4, [pc, #0x15c]
003daffc: ldr r8, [pc, #0x15c]
003db000: sub sp, sp, #0x3c
003db004: add r4, pc, r4
003db008: ldr r3, [r4, r8]
003db00c: mov sl, r0
003db010: add r5, sp, #0xc
003db014: ldr r3, [r3]
003db018: mov r0, sp
003db01c: mov r7, r1
003db020: str r3, [sp, #0x34]
003db024: bl #0x3192b4
003db028: mov r0, r5
003db02c: bl #0x31b434
003db030: ldr r3, [r7, #4]
003db034: mov r6, sp
003db038: ldr r0, [r3, #0x3e4]
003db03c: cmp r0, #0
003db040: beq #0x3db150
003db044: ldr r1, [pc, #0x118]
003db048: mov r3, r5
003db04c: add r2, r7, #0xc
003db050: add r1, pc, r1
003db054: bl #0x37c390
003db058: ldr r3, [sp, #0x14]
003db05c: cmp r3, #0
003db060: beq #0x3db098
003db064: mov r7, #0
003db068: mov r0, r5
003db06c: bl #0x31b398
003db070: mov r0, sp
003db074: bl #0x319228
003db078: ldr r3, [r4, r8]
003db07c: ldr r2, [sp, #0x34]
003db080: mov r0, r7
003db084: ldr r3, [r3]
003db088: cmp r2, r3
003db08c: bne #0x3db158
003db090: add sp, sp, #0x3c
003db094: pop {r4, r5, r6, r7, r8, sl, pc}
003db098: mov r0, sp
003db09c: ldr r1, [sl, #0x3cc]
003db0a0: bl #0x386f28
003db0a4: mov r0, sp
003db0a8: mov r1, sl
003db0ac: bl #0x31a46c
003db0b0: ldr r0, [sp, #0x30]
003db0b4: ldm r0, {r1, r2}
003db0b8: cmp r1, r2
003db0bc: beq #0x3db0c8
003db0c0: add r3, sp, #8
003db0c4: bl #0x31c3cc
003db0c8: ldr r3, [r7, #4]
003db0cc: ldr r1, [pc, #0x94]
003db0d0: mov r2, sp
003db0d4: ldr r0, [r3, #0x3e4]
003db0d8: add r1, pc, r1
003db0dc: mov r3, r5
003db0e0: bl #0x37c390
003db0e4: ldr r7, [sp, #0x14]
003db0e8: cmp r7, #0
003db0ec: bne #0x3db064
003db0f0: ldr r2, [sp, #0x30]
003db0f4: ldr r3, [r2]
003db0f8: ldr r2, [r2, #4]
003db0fc: rsb r3, r3, r2
003db100: asr r3, r3, #4
003db104: add r2, r3, r3, lsl #3
003db108: add r2, r2, r2, lsl #6
003db10c: add r2, r3, r2, lsl #3
003db110: add r2, r2, r2, lsl #15
003db114: add r3, r3, r2, lsl #3
003db118: cmp r3, #0
003db11c: beq #0x3db064
003db120: mov r0, r5
003db124: mov r1, r7
003db128: bl #0x3da43c
003db12c: ldr r3, [r0, #4]
003db130: cmp r3, #1
003db134: bne #0x3db064
003db138: mov r1, r7
003db13c: mov r0, r5
003db140: bl #0x3da43c
003db144: bl #0x31bc80
003db148: cmp r0, #0
003db14c: bne #0x3db064
003db150: mov r7, #1
003db154: b #0x3db068
003db158: bl #0x30e310
003db15c: subseq sb, fp, ip, lsl #21
003db160: andeq r4, r0, ip, lsr #1
003db164: subeq sl, lr, r0, lsl #16
003db168: subeq sl, lr, r0, lsl #16

# _ZN17ProjectileManager5SpawnEiP10GameObjectS1_PFiP10ProjectilePvES6_S4_b
003e701c: push {r4, r5, r6, r7, r8, lr}
003e7020: ldr r4, [pc, #0x114]
003e7024: sub sp, sp, #0x18
003e7028: subs r6, r1, #0
003e702c: add r4, pc, r4
003e7030: mov r7, r2
003e7034: ldrb r8, [sp, #0x3c]
003e7038: bge #0x3e704c
003e703c: mov r5, #0
003e7040: mov r0, r5
003e7044: add sp, sp, #0x18
003e7048: pop {r4, r5, r6, r7, r8, pc}
003e704c: ldr r2, [pc, #0xec]
003e7050: ldr r2, [r4, r2]
003e7054: ldr r2, [r2]
003e7058: cmp r6, r2
003e705c: bge #0x3e703c
003e7060: ldr r2, [pc, #0xdc]
003e7064: mov ip, #0x48
003e7068: mov r1, #1
003e706c: ldr r2, [r4, r2]
003e7070: ldr r2, [r2]
003e7074: mla r2, ip, r6, r2
003e7078: ldrb r2, [r2, #0x1c]
003e707c: str r3, [sp, #0x14]
003e7080: bl #0x3e693c
003e7084: subs r5, r0, #0
003e7088: ldr r3, [sp, #0x14]
003e708c: beq #0x3e70e8
003e7090: ldr r2, [r5]
003e7094: mov r1, #1
003e7098: str r3, [sp, #0x14]
003e709c: mov lr, pc
003e70a0: ldr pc, [r2, #0x40]
003e70a4: ldr r0, [sp, #0x30]
003e70a8: ldr ip, [r5]
003e70ac: ldr r3, [sp, #0x14]
003e70b0: str r0, [sp]
003e70b4: ldr r0, [sp, #0x34]
003e70b8: mov r1, r6
003e70bc: mov r2, r7
003e70c0: str r0, [sp, #4]
003e70c4: ldr r0, [sp, #0x38]
003e70c8: str r8, [sp, #0xc]
003e70cc: str r0, [sp, #8]
003e70d0: mov r0, r5
003e70d4: mov lr, pc
003e70d8: ldr pc, [ip, #0xc8]
003e70dc: mov r3, #1
003e70e0: strb r3, [r5, #0x85]
003e70e4: b #0x3e7040
003e70e8: ldr r3, [pc, #0x58]
003e70ec: ldr r3, [r4, r3]
003e70f0: ldr r3, [r3]
003e70f4: cmp r3, #2
003e70f8: streq r5, [r5]
003e70fc: beq #0x3e7040
003e7100: cmp r3, #1
003e7104: bne #0x3e7040
003e7108: ldr r0, [pc, #0x3c]
003e710c: ldr r1, [pc, #0x3c]
003e7110: ldr r2, [pc, #0x3c]
003e7114: ldr r0, [r4, r0]
003e7118: ldr r3, [pc, #0x38]
003e711c: mov ip, #0xf3
003e7120: add r1, pc, r1
003e7124: add r2, pc, r2
003e7128: add r3, pc, r3
003e712c: add r0, r0, #0xa8
003e7130: str ip, [sp]
003e7134: bl #0x30e004
003e7138: b #0x3e7040
003e713c: subseq sp, sl, r4, ror #20
003e7140: andeq r0, r0, r0, ror sb
003e7144: andeq r2, r0, r0, asr #6
003e7148: andeq r3, r0, r0, asr #19
003e714c: andeq r1, r0, r0, asr #19
003e7150: strheq r7, [sp], #-0x28
003e7154: subeq r2, lr, r4, lsr #32
003e7158: strdeq lr, pc, [sp], #-0xe8

# _ZN10ProjectileC1EN10ObjectBase6GO_IDSE
003e5e40: push {r4, r5, r6, lr}
003e5e44: ldr r5, [pc, #0x88]
003e5e48: mov r4, r0
003e5e4c: bl #0x38c398
003e5e50: ldr r1, [pc, #0x80]
003e5e54: add r5, pc, r5
003e5e58: mov r2, #0
003e5e5c: ldr r1, [r5, r1]
003e5e60: mov r3, #0
003e5e64: str r2, [r4, #0x3c8]
003e5e68: add r0, r1, #0xf0
003e5e6c: add ip, r1, #8
003e5e70: add r1, r1, #0xe4
003e5e74: str r1, [r4, #4]
003e5e78: mvn r1, #0
003e5e7c: str r1, [r4, #0x374]
003e5e80: mov r1, #1
003e5e84: str r0, [r4, #0x24]
003e5e88: str ip, [r4]
003e5e8c: strb r3, [r4, #0x3d1]
003e5e90: strb r1, [r4, #0x85]
003e5e94: str r3, [r4, #0x378]
003e5e98: str r3, [r4, #0x380]
003e5e9c: str r3, [r4, #0x384]
003e5ea0: str r2, [r4, #0x388]
003e5ea4: str r2, [r4, #0x38c]
003e5ea8: str r2, [r4, #0x390]
003e5eac: str r2, [r4, #0x394]
003e5eb0: str r2, [r4, #0x398]
003e5eb4: str r2, [r4, #0x39c]
003e5eb8: str r3, [r4, #0x3a4]
003e5ebc: str r3, [r4, #0x3b8]
003e5ec0: str r2, [r4, #0x3c4]
003e5ec4: str r3, [r4, #0x3cc]
003e5ec8: strb r3, [r4, #0x3d0]
003e5ecc: mov r0, r4
003e5ed0: pop {r4, r5, r6, pc}
003e5ed4: subseq lr, sl, ip, lsr ip
003e5ed8: andeq r3, r0, r4, lsr #10

# _ZN10Projectile7SetInfoEiP10GameObjectS1_PFiPS_PvES5_S3_b
003e58cc: push {r4, r5, r6, r7, r8, sb, sl, fp, lr}
003e58d0: sub sp, sp, #0x5c
003e58d4: ldr r5, [pc, #0x47c]
003e58d8: mov r8, r3
003e58dc: ldrb r3, [sp, #0x8c]
003e58e0: subs r7, r1, #0
003e58e4: add r5, pc, r5
003e58e8: mov r4, r0
003e58ec: mov r6, r2
003e58f0: str r3, [sp, #0x24]
003e58f4: blt #0x3e5b9c
003e58f8: ldr r3, [pc, #0x45c]
003e58fc: ldr r3, [r5, r3]
003e5900: ldr r3, [r3]
003e5904: cmp r7, r3
003e5908: bge #0x3e5b9c
003e590c: cmp r6, #0
003e5910: beq #0x3e5d04
003e5914: ldr r3, [pc, #0x444]
003e5918: mov r2, #0x48
003e591c: mov fp, #0
003e5920: ldr r3, [r5, r3]
003e5924: add sl, sp, #0x4c
003e5928: mov sb, #0
003e592c: ldr r3, [r3]
003e5930: str r7, [r4, #0x374]
003e5934: mov r0, r6
003e5938: mla r7, r2, r7, r3
003e593c: mov r1, sl
003e5940: ldrb r3, [r7, #0x1d]
003e5944: str r8, [r4, #0x384]
003e5948: ldr r2, [sp, #0x80]
003e594c: strb r3, [r4, #0x37c]
003e5950: str r2, [r4, #0x3b8]
003e5954: ldr r3, [sp, #0x84]
003e5958: str r3, [r4, #0x3bc]
003e595c: ldr r3, [sp, #0x88]
003e5960: str r6, [r4, #0x380]
003e5964: strb fp, [r4, #0x3d0]
003e5968: str r3, [r4, #0x3c0]
003e596c: strb fp, [r4, #0x3d1]
003e5970: str sb, [sp, #0x4c]
003e5974: str sb, [sp, #0x50]
003e5978: str sb, [sp, #0x54]
003e597c: bl #0x393ae4
003e5980: ldr r0, [r4, #0x380]
003e5984: bl #0x3935dc
003e5988: ldr r3, [r0]
003e598c: mov r1, sb
003e5990: str r3, [r4, #0x388]
003e5994: ldr r3, [r0, #4]
003e5998: str r3, [r4, #0x38c]
003e599c: ldr r3, [r0, #8]
003e59a0: str fp, [r4, #0x3a4]
003e59a4: str r3, [r4, #0x3a0]
003e59a8: str r3, [r4, #0x390]
003e59ac: ldr r6, [r7, #0x20]
003e59b0: mov r0, r6
003e59b4: bl #0x30e4b4
003e59b8: cmp r0, fp
003e59bc: moveq r0, #0xbf000000
003e59c0: addeq r0, r0, #0x800000
003e59c4: beq #0x3e59d4
003e59c8: mov r0, r6
003e59cc: mov r1, r6
003e59d0: bl #0x30ed6c
003e59d4: ldr r3, [r4, #0x380]
003e59d8: str r0, [r4, #0x3a8]
003e59dc: ldr r0, [r3, #0x2d8]
003e59e0: cmp r0, #0
003e59e4: beq #0x3e5a28
003e59e8: ldr r1, [pc, #0x374]
003e59ec: add r1, pc, r1
003e59f0: bl #0x470a18
003e59f4: cmp r0, #0
003e59f8: mov r1, r0
003e59fc: str r0, [r4, #0x3a4]
003e5a00: beq #0x3e5a28
003e5a04: add r0, sp, #0x40
003e5a08: bl #0x597180
003e5a0c: ldr r3, [sp, #0x48]
003e5a10: ldr r1, [sp, #0x40]
003e5a14: ldr r2, [sp, #0x44]
003e5a18: str r3, [r4, #0x3a0]
003e5a1c: str r1, [r4, #0x388]
003e5a20: str r2, [r4, #0x38c]
003e5a24: str r3, [r4, #0x390]
003e5a28: ldr r3, [r7, #0x40]
003e5a2c: str r3, [r4, #0x3ac]
003e5a30: ldr r3, [r7, #0x44]
003e5a34: str r3, [r4, #0x3b0]
003e5a38: ldr r3, [r7, #0x3c]
003e5a3c: str r3, [r4, #0x3b4]
003e5a40: ldr r1, [r7, #0x28]
003e5a44: cmp r1, #0
003e5a48: blt #0x3e5c84
003e5a4c: ldr r3, [pc, #0x314]
003e5a50: mov lr, #0xc
003e5a54: mov r2, #0
003e5a58: ldr ip, [r5, r3]
003e5a5c: mov r0, r4
003e5a60: mov r3, r2
003e5a64: ldr ip, [ip]
003e5a68: mla r1, lr, r1, ip
003e5a6c: ldr r1, [r1, #8]
003e5a70: bl #0x394d34
003e5a74: ldr r3, [pc, #0x2f0]
003e5a78: mov r7, #0
003e5a7c: mov r1, r7
003e5a80: ldr r3, [r5, r3]
003e5a84: mov r0, #0x28
003e5a88: mov r6, #1
003e5a8c: ldr sb, [r3, #0x44]
003e5a90: bl #0x310570
003e5a94: mov ip, #0x20
003e5a98: mov r1, sb
003e5a9c: mov r3, r7
003e5aa0: mov r2, r4
003e5aa4: str ip, [sp, #0x10]
003e5aa8: movw ip, #0x51f
003e5aac: str ip, [sp, #0x14]
003e5ab0: mov r8, r0
003e5ab4: str r6, [sp]
003e5ab8: str r6, [sp, #4]
003e5abc: str r6, [sp, #8]
003e5ac0: str r7, [sp, #0xc]
003e5ac4: str r7, [sp, #0x18]
003e5ac8: bl #0x46f2f0
003e5acc: ldr r3, [pc, #0x29c]
003e5ad0: mov r1, r8
003e5ad4: mov r2, r7
003e5ad8: ldr r3, [r5, r3]
003e5adc: mov r0, r4
003e5ae0: add r3, r3, #8
003e5ae4: str r3, [r8]
003e5ae8: bl #0x394bf8
003e5aec: mov r0, r4
003e5af0: mov r2, r6
003e5af4: add r1, r4, #0x388
003e5af8: bl #0x393db4
003e5afc: ldr r1, [r4, #0x380]
003e5b00: mov r0, r4
003e5b04: add r1, r1, #0x16c
003e5b08: bl #0x3938a0
003e5b0c: ldr r0, [r4, #0x384]
003e5b10: cmp r0, r7
003e5b14: beq #0x3e5bf4
003e5b18: bl #0x3935dc
003e5b1c: mov r1, r0
003e5b20: mov r0, r4
003e5b24: bl #0x393600
003e5b28: ldr r3, [r4, #0x2d8]
003e5b2c: cmp r3, #0
003e5b30: beq #0x3e5b78
003e5b34: ldr r3, [r3, #0x38]
003e5b38: mov r5, #0
003e5b3c: mov r2, #1
003e5b40: ldr ip, [r3]
003e5b44: mov r1, r5
003e5b48: mov r0, r3
003e5b4c: str r5, [sp]
003e5b50: mov r3, r5
003e5b54: mov lr, pc
003e5b58: ldr pc, [ip, #0x1c]
003e5b5c: ldr r0, [r4, #0x2d8]
003e5b60: bl #0x38ba74
003e5b64: ldr r2, [r4, #0x3b4]
003e5b68: mvn r3, #0x298
003e5b6c: sub r3, r3, #1
003e5b70: cmp r2, r3
003e5b74: beq #0x3e5ce0
003e5b78: add r4, r4, #0x1c8
003e5b7c: mov r0, r4
003e5b80: mov r1, #1
003e5b84: bl #0x5241f4
003e5b88: mov r0, r4
003e5b8c: mov r1, #1
003e5b90: bl #0x524218
003e5b94: add sp, sp, #0x5c
003e5b98: pop {r4, r5, r6, r7, r8, sb, sl, fp, pc}
003e5b9c: ldr r3, [pc, #0x1d0]
003e5ba0: ldr r3, [r5, r3]
003e5ba4: ldr r3, [r3]
003e5ba8: cmp r3, #2
003e5bac: moveq r3, #0
003e5bb0: streq r3, [r3]
003e5bb4: beq #0x3e590c
003e5bb8: cmp r3, #1
003e5bbc: bne #0x3e590c
003e5bc0: ldr r0, [pc, #0x1b0]
003e5bc4: ldr r1, [pc, #0x1b0]
003e5bc8: ldr r2, [pc, #0x1b0]
003e5bcc: ldr r0, [r5, r0]
003e5bd0: ldr r3, [pc, #0x1ac]
003e5bd4: mov ip, #0x4e
003e5bd8: add r1, pc, r1
003e5bdc: add r2, pc, r2
003e5be0: add r3, pc, r3
003e5be4: add r0, r0, #0xa8
003e5be8: str ip, [sp]
003e5bec: bl #0x30e004
003e5bf0: b #0x3e590c
003e5bf4: ldr r1, [r4, #0x3a4]
003e5bf8: cmp r1, #0
003e5bfc: beq #0x3e5c0c
003e5c00: ldr r3, [sp, #0x24]
003e5c04: cmp r3, #0
003e5c08: bne #0x3e5c94
003e5c0c: ldr r0, [r4, #0x380]
003e5c10: bl #0x3935dc
003e5c14: mov r1, #0x44000000
003e5c18: mov r5, r0
003e5c1c: add r1, r1, #0x7a0000
003e5c20: ldr r0, [sp, #0x50]
003e5c24: bl #0x30ed6c
003e5c28: ldr r1, [r5, #4]
003e5c2c: bl #0x30eba4
003e5c30: mov r1, #0x44000000
003e5c34: mov r7, r0
003e5c38: add r1, r1, #0x7a0000
003e5c3c: ldr r0, [sp, #0x54]
003e5c40: bl #0x30ed6c
003e5c44: ldr r1, [r5, #8]
003e5c48: bl #0x30eba4
003e5c4c: mov r1, #0x44000000
003e5c50: mov r6, r0
003e5c54: add r1, r1, #0x7a0000
003e5c58: ldr r0, [sp, #0x4c]
003e5c5c: bl #0x30ed6c
003e5c60: ldr r1, [r5]
003e5c64: bl #0x30eba4
003e5c68: add r1, sp, #0x28
003e5c6c: str r0, [sp, #0x28]
003e5c70: mov r0, r4
003e5c74: str r7, [sp, #0x2c]
003e5c78: str r6, [sp, #0x30]
003e5c7c: bl #0x393600
003e5c80: b #0x3e5b28
003e5c84: mov r0, r4
003e5c88: mov r1, #0
003e5c8c: bl #0x394338
003e5c90: b #0x3e5a74
003e5c94: add r0, sp, #0x34
003e5c98: bl #0x597180
003e5c9c: ldr r0, [r4, #0x380]
003e5ca0: bl #0x3935dc
003e5ca4: ldr r1, [r0, #4]
003e5ca8: mov r5, r0
003e5cac: ldr r0, [sp, #0x38]
003e5cb0: bl #0x30e3ac
003e5cb4: ldr r1, [r5]
003e5cb8: mov r6, r0
003e5cbc: ldr r0, [sp, #0x34]
003e5cc0: bl #0x30e3ac
003e5cc4: mov r3, #0
003e5cc8: str r0, [sp, #0x4c]
003e5ccc: mov r0, sl
003e5cd0: str r6, [sp, #0x50]
003e5cd4: str r3, [sp, #0x54]
003e5cd8: bl #0x34d0b0
003e5cdc: b #0x3e5c0c
003e5ce0: ldr r3, [r4, #0x2d8]
003e5ce4: mov r1, r5
003e5ce8: ldr r3, [r3, #0x38]
003e5cec: mov r0, r3
003e5cf0: ldr r3, [r3]
003e5cf4: mov lr, pc
003e5cf8: ldr pc, [r3, #0x18]
003e5cfc: str r0, [r4, #0x3b4]
003e5d00: b #0x3e5b78
003e5d04: ldr r3, [pc, #0x68]
003e5d08: ldr r3, [r5, r3]
003e5d0c: ldr r3, [r3]
003e5d10: cmp r3, #2
003e5d14: streq r6, [r6]
003e5d18: beq #0x3e5914
003e5d1c: cmp r3, #1
003e5d20: bne #0x3e5914
003e5d24: ldr r0, [pc, #0x4c]
003e5d28: ldr r1, [pc, #0x58]
003e5d2c: ldr r2, [pc, #0x58]
003e5d30: ldr r0, [r5, r0]
003e5d34: ldr r3, [pc, #0x54]
003e5d38: mov ip, #0x4f
003e5d3c: add r1, pc, r1
003e5d40: add r2, pc, r2
003e5d44: add r3, pc, r3
003e5d48: add r0, r0, #0xa8
003e5d4c: str ip, [sp]
003e5d50: bl #0x30e004
003e5d54: b #0x3e5914
003e5d58: subseq pc, sl, ip, lsr #3
003e5d5c: andeq r0, r0, r0, ror sb
003e5d60: andeq r2, r0, r0, asr #6
003e5d64: subeq r0, lr, ip, lsr #11
003e5d68: andeq r1, r0, r0, ror #19
003e5d6c: strdeq r3, r4, [r0], -r4
003e5d70: strheq r2, [r0], -ip
003e5d74: andeq r3, r0, r0, asr #19
003e5d78: andeq r1, r0, r0, asr #19
003e5d7c: subeq r8, sp, r0, lsl #16
003e5d80: subeq r0, lr, r4, ror r3
003e5d84: subeq r0, lr, r8, ror #7
003e5d88: umaaleq r8, sp, ip, r6
003e5d8c: strheq sp, [sp], #-8
003e5d90: subeq r0, lr, r4, lsl #5

# _ZN10Projectile6UpdateEv
003e51b0: push {r4, r5, r6, r7, r8, sl, lr}
003e51b4: ldrb r3, [r0, #0x3d1]
003e51b8: ldr r5, [pc, #0x3e4]
003e51bc: sub sp, sp, #0x34
003e51c0: cmp r3, #0
003e51c4: mov r4, r0
003e51c8: add r5, pc, r5
003e51cc: beq #0x3e523c
003e51d0: ldr r3, [r0, #0x3bc]
003e51d4: cmp r3, #0
003e51d8: moveq r0, r3
003e51dc: beq #0x3e51e8
003e51e0: ldr r1, [r4, #0x3c0]
003e51e4: blx r3
003e51e8: ldr r1, [r4, #0x3cc]
003e51ec: cmp r1, #0
003e51f0: beq #0x3e5208
003e51f4: cmp r0, #0
003e51f8: bne #0x3e5228
003e51fc: mov r0, r4
003e5200: add r2, r4, #0x3c4
003e5204: bl #0x3e4eec
003e5208: mov r2, #0
003e520c: mov r3, #1
003e5210: strb r3, [r4, #0x3d0]
003e5214: strb r2, [r4, #0x3d1]
003e5218: mov r1, r4
003e521c: ldr r0, [r4, #0x378]
003e5220: bl #0x3e61b4
003e5224: b #0x3e5270
003e5228: cmp r0, #1
003e522c: bne #0x3e523c
003e5230: mov r3, #0
003e5234: strb r3, [r4, #0x3d1]
003e5238: strb r3, [r4, #0x3d0]
003e523c: ldr r3, [r4, #0x384]
003e5240: cmp r3, #0
003e5244: beq #0x3e5264
003e5248: mov r0, r3
003e524c: ldr r3, [r3]
003e5250: mov lr, pc
003e5254: ldr pc, [r3, #0x34]
003e5258: cmp r0, #0
003e525c: movne r3, #0
003e5260: strne r3, [r4, #0x384]
003e5264: ldrb r3, [r4, #0x3d0]
003e5268: cmp r3, #0
003e526c: beq #0x3e5278
003e5270: add sp, sp, #0x34
003e5274: pop {r4, r5, r6, r7, r8, sl, pc}
003e5278: mov r0, r4
003e527c: bl #0x3935dc
003e5280: ldr r2, [r0]
003e5284: ldr r3, [r4, #0x374]
003e5288: str r2, [r4, #0x394]
003e528c: ldr r1, [r0, #4]
003e5290: ldr r2, [pc, #0x310]
003e5294: str r1, [r4, #0x398]
003e5298: ldr r1, [r0, #8]
003e529c: ldr r2, [r5, r2]
003e52a0: str r1, [r4, #0x39c]
003e52a4: ldr r2, [r2]
003e52a8: mov r1, #0x48
003e52ac: mla r3, r1, r3, r2
003e52b0: ldrb r3, [r3, #0x35]
003e52b4: cmp r3, #0
003e52b8: beq #0x3e5400
003e52bc: ldr r0, [r4, #0x384]
003e52c0: cmp r0, #0
003e52c4: beq #0x3e5400
003e52c8: bl #0x3935dc
003e52cc: mov r1, r0
003e52d0: mov r0, r4
003e52d4: bl #0x393600
003e52d8: mov r0, r4
003e52dc: bl #0x38cbe8
003e52e0: ldr r3, [pc, #0x2c4]
003e52e4: ldr r7, [r4, #0x3ac]
003e52e8: ldr r8, [r4, #0x3b0]
003e52ec: ldr r6, [r5, r3]
003e52f0: mov r0, r6
003e52f4: bl #0x31f66c
003e52f8: bl #0x30e2e0
003e52fc: mov r1, r0
003e5300: mov r0, r8
003e5304: bl #0x30ed6c
003e5308: mov r1, #0xc4000000
003e530c: add r1, r1, #0x7a0000
003e5310: bl #0x30ec94
003e5314: mov r1, r0
003e5318: mov r0, r7
003e531c: bl #0x30eba4
003e5320: str r0, [r4, #0x3ac]
003e5324: mov r0, r6
003e5328: ldr r6, [r4, #0x3b4]
003e532c: bl #0x31f66c
003e5330: rsb r0, r0, r6
003e5334: cmp r0, #0
003e5338: str r0, [r4, #0x3b4]
003e533c: ble #0x3e5564
003e5340: ldr r0, [r4, #0x3ac]
003e5344: mov r1, #0
003e5348: bl #0x30e9ac
003e534c: cmp r0, #0
003e5350: bne #0x3e5564
003e5354: ldr r0, [r4, #0x3a8]
003e5358: mov r1, #0
003e535c: bl #0x30e4b4
003e5360: cmp r0, #0
003e5364: bne #0x3e54d0
003e5368: ldr r7, [pc, #0x240]
003e536c: mov ip, #0
003e5370: add lr, sp, #0x28
003e5374: add r6, r4, #0x160
003e5378: str lr, [sp, #4]
003e537c: ldr r0, [r5, r7]
003e5380: mov lr, #1
003e5384: mov r3, ip
003e5388: mov r1, r6
003e538c: add r2, sp, #0x2c
003e5390: str lr, [sp, #8]
003e5394: str ip, [sp]
003e5398: bl #0x525508
003e539c: cmp r0, #0
003e53a0: beq #0x3e5574
003e53a4: ldr r1, [sp, #0x28]
003e53a8: cmp r1, #0
003e53ac: beq #0x3e5574
003e53b0: add r0, r4, #0x1c8
003e53b4: bl #0x524230
003e53b8: cmp r0, #0
003e53bc: bne #0x3e53d0
003e53c0: ldr r3, [sp, #0x28]
003e53c4: ldr r3, [r3, #0x24]
003e53c8: tst r3, #0x2000000
003e53cc: beq #0x3e53f0
003e53d0: ldr r3, [r4, #0x3a4]
003e53d4: cmp r3, #0
003e53d8: beq #0x3e5270
003e53dc: ldr r0, [r4, #0x3a0]
003e53e0: ldr r1, [sp, #0x2c]
003e53e4: bl #0x30e9ac
003e53e8: cmp r0, #0
003e53ec: beq #0x3e5270
003e53f0: mov r0, r4
003e53f4: mov r1, #2
003e53f8: bl #0x3e5078
003e53fc: b #0x3e5270
003e5400: mov r0, r4
003e5404: bl #0x3935dc
003e5408: ldr r1, [r0, #4]
003e540c: mov r6, r0
003e5410: ldr r0, [r4, #0x1ac]
003e5414: bl #0x30e3ac
003e5418: ldr r1, [r6]
003e541c: mov r7, r0
003e5420: ldr r0, [r4, #0x1a8]
003e5424: bl #0x30e3ac
003e5428: mov r3, #0
003e542c: str r0, [sp, #0x1c]
003e5430: add r0, sp, #0x1c
003e5434: str r3, [sp, #0x24]
003e5438: str r7, [sp, #0x20]
003e543c: bl #0x34d0b0
003e5440: mov r1, #0x44000000
003e5444: ldr r0, [sp, #0x1c]
003e5448: add r1, r1, #0x7a0000
003e544c: bl #0x30ed6c
003e5450: mov r1, #0x44000000
003e5454: str r0, [sp, #0x1c]
003e5458: add r1, r1, #0x7a0000
003e545c: ldr r0, [sp, #0x20]
003e5460: bl #0x30ed6c
003e5464: mov r1, #0x44000000
003e5468: str r0, [sp, #0x20]
003e546c: add r1, r1, #0x7a0000
003e5470: ldr r0, [sp, #0x24]
003e5474: bl #0x30ed6c
003e5478: str r0, [sp, #0x24]
003e547c: mov r0, r4
003e5480: bl #0x3935dc
003e5484: ldr r1, [r0, #4]
003e5488: mov r6, r0
003e548c: ldr r0, [sp, #0x20]
003e5490: bl #0x30eba4
003e5494: ldr r1, [r6, #8]
003e5498: mov r8, r0
003e549c: ldr r0, [sp, #0x24]
003e54a0: bl #0x30eba4
003e54a4: ldr r1, [r6]
003e54a8: mov r7, r0
003e54ac: ldr r0, [sp, #0x1c]
003e54b0: bl #0x30eba4
003e54b4: add r1, sp, #0x10
003e54b8: str r0, [sp, #0x10]
003e54bc: mov r0, r4
003e54c0: str r8, [sp, #0x14]
003e54c4: str r7, [sp, #0x18]
003e54c8: bl #0x393600
003e54cc: b #0x3e52d8
003e54d0: mov r0, r4
003e54d4: bl #0x3935dc
003e54d8: ldr r1, [r4, #0x388]
003e54dc: mov r6, r0
003e54e0: ldr r0, [r0]
003e54e4: bl #0x30e3ac
003e54e8: ldr r1, [r4, #0x38c]
003e54ec: mov sl, r0
003e54f0: ldr r0, [r6, #4]
003e54f4: bl #0x30e3ac
003e54f8: ldr r1, [r4, #0x390]
003e54fc: mov r8, r0
003e5500: ldr r0, [r6, #8]
003e5504: bl #0x30e3ac
003e5508: mov r1, sl
003e550c: mov r7, r0
003e5510: mov r0, sl
003e5514: bl #0x30ed6c
003e5518: mov r1, r8
003e551c: mov r6, r0
003e5520: mov r0, r8
003e5524: bl #0x30ed6c
003e5528: mov r1, r0
003e552c: mov r0, r6
003e5530: bl #0x30eba4
003e5534: mov r1, r7
003e5538: mov r6, r0
003e553c: mov r0, r7
003e5540: bl #0x30ed6c
003e5544: mov r1, r0
003e5548: mov r0, r6
003e554c: bl #0x30eba4
003e5550: mov r1, r0
003e5554: ldr r0, [r4, #0x3a8]
003e5558: bl #0x30e9ac
003e555c: cmp r0, #0
003e5560: beq #0x3e5368
003e5564: mov r0, r4
003e5568: mov r1, #1
003e556c: bl #0x3e5078
003e5570: b #0x3e5270
003e5574: mov r1, r6
003e5578: ldr r0, [r5, r7]
003e557c: bl #0x525188
003e5580: subs r1, r0, #0
003e5584: beq #0x3e5598
003e5588: ldr r3, [r1, #0x24]
003e558c: tst r3, #1
003e5590: beq #0x3e5270
003e5594: b #0x3e53f0
003e5598: mov r0, r4
003e559c: bl #0x3e5078
003e55a0: b #0x3e5270
003e55a4: subseq pc, sl, r8, asr #17
003e55a8: andeq r2, r0, r0, asr #6
003e55ac: strdeq r3, r4, [r0], -r4
003e55b0: andeq r1, r0, r4, lsl #4

# _ZN10Projectile11OnCollisionEP10GameObjectRK7Point2DIfE
003e55b4: push {r4, r5, r6, r7, r8, sl, lr}
003e55b8: mov r4, r0
003e55bc: ldrb r0, [r0, #0x3d0]
003e55c0: ldr r3, [pc, #0x170]
003e55c4: sub sp, sp, #0x1c
003e55c8: cmp r0, #0
003e55cc: add r3, pc, r3
003e55d0: mov r6, r2
003e55d4: mov r5, r1
003e55d8: bne #0x3e56a4
003e55dc: ldrb r2, [r4, #0x3d1]
003e55e0: cmp r2, #0
003e55e4: bne #0x3e56a4
003e55e8: ldr r2, [pc, #0x14c]
003e55ec: cmp r1, #0
003e55f0: ldr sl, [r4, #0x374]
003e55f4: ldr r3, [r3, r2]
003e55f8: ldr r8, [r3]
003e55fc: beq #0x3e56a4
003e5600: ldr r3, [r4, #0x380]
003e5604: cmp r3, r1
003e5608: beq #0x3e56a4
003e560c: add r7, sp, #0xc
003e5610: mov r0, r7
003e5614: bl #0x33dd2c
003e5618: mov r0, r7
003e561c: bl #0x33ff54
003e5620: cmp r0, #0
003e5624: beq #0x3e56f8
003e5628: mov r3, #0x48
003e562c: mla r8, r3, sl, r8
003e5630: ldrb r3, [r8, #4]
003e5634: cmp r3, #0
003e5638: bne #0x3e5698
003e563c: ldrb r3, [r8, #0x10]
003e5640: cmp r3, #0
003e5644: beq #0x3e56c0
003e5648: str r5, [r4, #0x3cc]
003e564c: ldr r2, [r6]
003e5650: ldr r3, [r4, #0x3b8]
003e5654: str r2, [r4, #0x3c4]
003e5658: ldr r2, [r6, #4]
003e565c: cmp r3, #0
003e5660: str r2, [r4, #0x3c8]
003e5664: beq #0x3e568c
003e5668: mov r0, r4
003e566c: ldr r1, [r4, #0x3c0]
003e5670: blx r3
003e5674: cmp r0, #2
003e5678: beq #0x3e5708
003e567c: cmp r0, #3
003e5680: beq #0x3e56b0
003e5684: cmp r0, #1
003e5688: beq #0x3e56a4
003e568c: mov r0, #1
003e5690: strb r0, [r4, #0x3d1]
003e5694: b #0x3e56a8
003e5698: ldr r3, [r4, #0x384]
003e569c: cmp r3, r5
003e56a0: beq #0x3e563c
003e56a4: mov r0, #0
003e56a8: add sp, sp, #0x1c
003e56ac: pop {r4, r5, r6, r7, r8, sl, pc}
003e56b0: mov r0, r4
003e56b4: mov r1, #1
003e56b8: bl #0x3e5078
003e56bc: b #0x3e568c
003e56c0: ldr r1, [r4, #0x380]
003e56c4: mov r0, sp
003e56c8: bl #0x33dd2c
003e56cc: mov r0, sp
003e56d0: bl #0x33ff54
003e56d4: cmp r0, #0
003e56d8: mov r7, sp
003e56dc: beq #0x3e5648
003e56e0: add r0, r0, #0x3c8
003e56e4: mov r1, r5
003e56e8: bl #0x3d574c
003e56ec: cmp r0, #0
003e56f0: beq #0x3e56a4
003e56f4: b #0x3e5648
003e56f8: ldr r3, [r4, #0x384]
003e56fc: cmp r3, #0
003e5700: bne #0x3e56a4
003e5704: b #0x3e5648
003e5708: ldr r3, [r4, #0x3bc]
003e570c: cmp r3, #0
003e5710: beq #0x3e5720
003e5714: mov r0, r4
003e5718: ldr r1, [r4, #0x3c0]
003e571c: blx r3
003e5720: mov r0, r4
003e5724: ldr r1, [r4, #0x3cc]
003e5728: add r2, r4, #0x3c4
003e572c: bl #0x3e4eec
003e5730: mov r0, #0
003e5734: b #0x3e56a8
003e5738: subseq pc, sl, r4, asr #9
003e573c: andeq r2, r0, r0, asr #6

# _ZN10Projectile8OnExpireENS_10ImpactTypeE
003e5078: ldr r3, [pc, #0x124]
003e507c: ldr r2, [pc, #0x124]
003e5080: push {r4, r5, lr}
003e5084: add r3, pc, r3
003e5088: ldr r2, [r3, r2]
003e508c: mov r4, r0
003e5090: ldr r0, [r0, #0x374]
003e5094: ldr r2, [r2]
003e5098: mov r5, r1
003e509c: mov r1, #0x48
003e50a0: mla r2, r1, r0, r2
003e50a4: sub sp, sp, #0x3c
003e50a8: ldrb r2, [r2, #0x34]
003e50ac: cmp r2, #0
003e50b0: beq #0x3e511c
003e50b4: ldr ip, [r4, #0x1d8]
003e50b8: ldr lr, [r4, #0x1d4]
003e50bc: mov r2, #0
003e50c0: cmp ip, #0
003e50c4: str r2, [sp, #0x28]
003e50c8: str r2, [sp, #0x34]
003e50cc: str r2, [sp, #0x20]
003e50d0: str r2, [sp, #0x24]
003e50d4: str ip, [sp, #0x30]
003e50d8: str lr, [sp, #0x2c]
003e50dc: beq #0x3e514c
003e50e0: mov r0, ip
003e50e4: add r1, r4, #0x394
003e50e8: add r2, sp, #0x34
003e50ec: add r3, sp, #0x20
003e50f0: bl #0x51badc
003e50f4: ldr r3, [r4, #0x398]
003e50f8: ldr ip, [r4, #0x394]
003e50fc: mov r0, r4
003e5100: str r3, [sp, #0x18]
003e5104: ldr r3, [sp, #0x34]
003e5108: add r1, sp, #0x14
003e510c: mov r2, #1
003e5110: str ip, [sp, #0x14]
003e5114: str r3, [sp, #0x1c]
003e5118: bl #0x393db4
003e511c: mov r3, #0
003e5120: str r3, [r4, #0x3cc]
003e5124: mov r3, #1
003e5128: strb r3, [r4, #0x3d1]
003e512c: mov r0, r4
003e5130: bl #0x3935dc
003e5134: mov r1, r5
003e5138: mov r2, r0
003e513c: mov r0, r4
003e5140: bl #0x3e4db0
003e5144: add sp, sp, #0x3c
003e5148: pop {r4, r5, pc}
003e514c: cmp lr, #0
003e5150: beq #0x3e5178
003e5154: mov r0, lr
003e5158: add r1, r4, #0x394
003e515c: add lr, sp, #0x30
003e5160: add r2, sp, #0x34
003e5164: add r3, sp, #0x20
003e5168: str lr, [sp]
003e516c: str ip, [sp, #4]
003e5170: bl #0x520f98
003e5174: b #0x3e50f4
003e5178: ldr r2, [pc, #0x2c]
003e517c: add ip, sp, #0x2c
003e5180: str ip, [sp]
003e5184: ldr r0, [r3, r2]
003e5188: add ip, sp, #0x30
003e518c: add r1, r4, #0x394
003e5190: add r2, sp, #0x34
003e5194: add r3, sp, #0x20
003e5198: stmib sp, {ip, lr}
003e519c: bl #0x525508
003e51a0: b #0x3e50f4
003e51a4: subseq pc, sl, ip, lsl #20
003e51a8: andeq r2, r0, r0, asr #6
003e51ac: andeq r1, r0, r4, lsl #4
