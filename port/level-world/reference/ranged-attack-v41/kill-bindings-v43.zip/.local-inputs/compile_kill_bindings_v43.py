from pathlib import Path
s=Path('.local-inputs/compile_renderer_kill_live_v21.py').read_text()
s=s.replace("s=src.read_text();s=", "s=src.read_text();s='#include \"character_kill_production_v23.hpp\"\\n#include \"world_loot_gameplay_v23.hpp\"\\n#include \"character_progression_world_v23.hpp\"\\n#include \"retained_character_kill_borrow_v42.hpp\"\\n'+s;s=")
s=s.replace("temp=root/", "key='#include \"renderer_player_target_frame_v2.inc\"';assert key in s;s=s.replace(key,key+'\\n#include \"renderer_character_kill_bindings_v43.inc\"')\ntemp=root/")
s=s.replace('model_renderer_kill_live_v21.cpp','model_renderer_kill_bindings_v43.cpp').replace('renderer_kill_live_v21_','renderer_kill_bindings_v43_')
exec(compile(s,__file__,'exec'))
