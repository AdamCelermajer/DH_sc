from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];unix='/mnt/c/Users/adamc/Desktop/workspace/DH_sc'
snapshot=r/'.local-inputs/character-menu-native-v1-host/snapshot';deps={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.iterdir() if p.suffix in ('.so','.a')};rows=[]
sources=['port/level-world/combat_ctrl_kill_owner_v1.cpp','port/level-world/character_kill.cpp','port/level-world/tests/combat_ctrl_kill_owner_v1_host.cpp']
libs=['-L.local-inputs/character-menu-native-v1-host/snapshot','-ldh2_level_world','-ldh2_game_data','-ldh2_engine_ui','-ldh2_script_runtime','-ldh2_engine_skinning','-ldh2_engine_animation','-ldh2_scene_materials','-ldh2_zip_asset_pack_v1','-lz']
for opt in ('O1','O2'):
 exe='.local-inputs/kill_order_v43_'+opt
 for args in (['g++','-std=c++17','-'+opt,'-fsanitize=address,undefined','-fno-omit-frame-pointer',*sources,*libs,'-o',exe],['env','LD_LIBRARY_PATH='+unix+'/.local-inputs/character-menu-native-v1-host/snapshot',exe]):
  p=subprocess.run(['wsl','-d','Ubuntu','--cd',unix,'--exec',*args],capture_output=True,text=True);rows.append({'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(p.stdout,p.stderr);assert p.returncode==0
(r/'port/level-world/reports/kill-order-v43-host.json').write_text(json.dumps({'rows':rows,'dependencies':deps,'historical_dependency_source_attribution':False,'loot_xp_quest_callbacks':'explicit fixtures, not production acceptance'},indent=2)+'\n')
