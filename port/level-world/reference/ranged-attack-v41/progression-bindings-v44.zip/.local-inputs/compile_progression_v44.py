import json,shlex,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];src=r/'port/android-native/app/src/main/cpp/model_renderer.cpp'
s='#include "character_progression_world_v23.hpp"\n#include "character_kill_level_events_v23.hpp"\n#include "player_xp_text_v1.hpp"\n#include "player_save_write_owner_v1.hpp"\n'+src.read_text()
key='#include "renderer_combat_text_v1.inc"';assert key in s
s=s.replace(key,key+'\n#include "renderer_character_progression_bindings_v44.inc"')
temp=r/'.local-inputs/model_renderer_progression_v44.cpp';temp.write_text(s)
for abi in ('arm64-v8a','x86_64'):
 db=json.loads((r/f'port/android-native/app/.cxx/Debug/5a1n3w3m/{abi}/compile_commands.json').read_text());entry=next(e for e in db if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
 args=entry.get('arguments')or[x.strip('"')for x in shlex.split(entry['command'],posix=False)];flags=[];i=1
 while i<len(args):
  a=args[i]
  if a in ('-I','-D','-isystem'):flags.extend([a,args[i+1]]);i+=2;continue
  if a.startswith(('--target=','--sysroot=','-I','-D')):flags.append(a)
  i+=1
 p=subprocess.run([args[0],*flags,'-I'+str(src.parent),'-std=c++17','-Werror','-Wno-unused-function','-fsyntax-only',str(temp)],capture_output=True,text=True,timeout=120)
 (r/f'.local-inputs/renderer_progression_v44_{abi}.log').write_text(p.stdout+p.stderr);print(abi,p.returncode,p.stderr[:5000]);assert p.returncode==0
