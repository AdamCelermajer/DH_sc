from pathlib import Path
p=Path(__file__).with_name('compile_authored_fx_v4.py');s=p.read_text();a=s.index('files=[');b=s.index('\nfor abi',a)
s=s[:a]+"files=['port/level-world/character_loot_live_v22.cpp','port/level-world/character_loot_creation_bindings_v22.cpp']"+s[b:]
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
