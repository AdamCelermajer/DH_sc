from pathlib import Path
p=Path(__file__).with_name('compile_renderer_kill_live_v21.py');s=p.read_text()
s=s.replace('character_kill_live_v21.hpp','character_loot_live_v22.hpp').replace('character_kill_loot_connection_v10.hpp','character_loot_live_v22.hpp')
s=s.replace('renderer_character_kill_live_v21.inc','renderer_character_loot_live_v22.inc').replace('model_renderer_kill_live_v21.cpp','model_renderer_loot_live_v22.cpp').replace('renderer_kill_live_v21_','renderer_loot_live_v22_')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
