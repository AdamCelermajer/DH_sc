import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
remote='/data/local/tmp/dh2-loot-v22-cache'
subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote],check=True,timeout=40)
for name in ['loot_table_pyarray.bin','loot_table_pyarraynames.bin','loot_table_pystructnames.bin']:
 subprocess.run([adb,'-s','emulator-5554','push',str(root/'port/android-native/app/src/main/assets/data'/name),remote+'/'+name],check=True,timeout=40)
sources=['port/level-world/tests/character_loot_live_v22_native.cpp','port/level-world/character_loot_live_v22.cpp','port/level-world/character_loot_creation_bindings_v22.cpp','port/level-world/point3d_normalize_v2.cpp']
subprocess.run([sys.executable,str(root/'.local-inputs/root_android_linked_owner_test.py'),'character-loot-live-v22',*sources,'--',remote],check=True,timeout=120)
