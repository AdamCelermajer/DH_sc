#pragma once
#include "level_savegame_owner_v1.hpp"
#include "../game-data/player_profile_index_v1.hpp"
namespace dh2::level {
struct LevelSavegameCacheServicesV1 {
 void* context{};
 // Actual FileManager open/read ownership. found=false is a genuine miss.
 bool (*read_file)(void*,const std::string&,bool& found,std::vector<std::uint8_t>&,std::string&){};
 bool (*load_objects)(void*,data::Bytes,LevelSavegameFieldsV1&,std::string&){};
};
// Source Savegame C1/cache/register/load subset. File jobs/saveAll stay an
// explicit whole service; this owner never invents a writable empty profile.
class LevelSavegameCacheV1 {
 LevelSavegameCacheServicesV1 services_; data::PlayerProfileIndexV1 index_;
 std::string filename_; bool attempted_{},ready_{},has_file_{};
 std::array<LevelSavegameFieldsV1*,2> sections_{};
public:
 explicit LevelSavegameCacheV1(LevelSavegameCacheServicesV1 s):services_(s){}
 bool construct(const std::string&,bool,std::string&);
 bool register_section(const char*,LevelSavegameSectionV1,LevelSavegameFieldsV1&,std::string&);
 bool load_section(const char*,LevelSavegameSectionV1,LevelSavegameFieldsV1&,std::string&);
 bool ready()const noexcept{return ready_;}
 bool has_cached_file()const noexcept{return has_file_;}
 const std::string& filename()const noexcept{return filename_;}
 data::PlayerProfileIndexV1::Borrow profile()const{return index_.borrow();}
};
}
