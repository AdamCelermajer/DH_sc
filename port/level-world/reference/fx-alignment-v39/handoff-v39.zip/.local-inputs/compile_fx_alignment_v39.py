from pathlib import Path
p=Path(__file__).with_name('compile_target_close_v38.py')
s=p.read_text().replace("('character_close_range_v38.cpp','character_world_attack_geometry_v1.cpp')","('authored_fx_alignment_v39.cpp',)").replace('target-close-v38-strict.json','fx-alignment-v39-strict.json')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
