from pathlib import Path
p=Path(__file__).with_name('compile_target_close_v38.py');s=p.read_text().replace("('character_close_range_v38.cpp','character_world_attack_geometry_v1.cpp')","('character_world_clear_aggro_v40.cpp',)").replace('target-close-v38-strict.json','target-cleanup-v40-strict.json')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
p=Path(__file__).with_name('compile_renderer_kill_live_v21.py');s=p.read_text()
s=s.replace("s=src.read_text();s='#include \"character_kill_live_v21.hpp\"\\n#include \"character_kill_loot_connection_v10.hpp\"\\n'+s", "s=src.read_text();s='#include \\\"character_world_clear_aggro_v40.hpp\\\"\\n'+s")
s=s.replace("key='#include \"renderer_npc_death_v2.inc\"';assert key in s;s=s.replace(key,key+'\\n#include \"renderer_character_kill_live_v21.inc\"')", "key='#include \\\"renderer_player_target_frame_v2.inc\\\"';assert key in s;s=s.replace(key,key+'\\n#include \\\"renderer_target_cleanup_v40.inc\\\"')")
s=s.replace('model_renderer_kill_live_v21.cpp','model_renderer_target_cleanup_v40.cpp').replace('renderer_kill_live_v21_','renderer_target_cleanup_v40_')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
