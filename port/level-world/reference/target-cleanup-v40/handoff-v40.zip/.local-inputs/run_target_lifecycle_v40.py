from pathlib import Path
p=Path('port/level-world/tools/run_clear_aggro_v40_host.py').resolve();s=p.read_text()
s=s.replace("'port/level-world/tests/character_world_clear_aggro_v40.cpp'","'port/level-world/tests/target_lifecycle_contrasts_v40.cpp'")
s=s.replace("'port/game-data/aggro.cpp'","'port/game-data/aggro.cpp','port/level-world/character_target_update.cpp','port/level-world/character_target_events.cpp'")
s=s.replace('world-clear-aggro-v40','target-lifecycle-v40')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
