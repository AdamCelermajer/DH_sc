import json,shlex,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
receipt=[]
for abi in ('arm64-v8a','x86_64'):
 rows=json.loads((root/'port/android-native/app/.cxx/Debug/5a1n3w3m'/abi/'compile_commands.json').read_text());row=next(r for r in rows if r['file'].replace('\\','/').endswith('/model_renderer.cpp'))
 for source in ('character_close_range_v38.cpp','character_world_attack_geometry_v1.cpp'):
  args=shlex.split(row['command'].replace('\\','/'));out=[];skip=False
  for arg in args:
   if skip:skip=False;continue
   if arg=='-o':skip=True;continue
   if arg=='-c':continue
   if arg.endswith('/model_renderer.cpp'):arg=str(root/'port/level-world'/source).replace('\\','/')
   out.append(arg)
  out+=['-fsyntax-only','-Wall','-Wextra','-Werror']
  run=subprocess.run(out,cwd=row['directory'],capture_output=True,text=True);receipt.append({'abi':abi,'source':source,'exit':run.returncode,'stderr':run.stderr});print(abi,source,run.returncode,run.stderr);assert run.returncode==0
(root/'port/level-world/reports/target-close-v38-strict.json').write_text(json.dumps(receipt,indent=2)+'\n')
