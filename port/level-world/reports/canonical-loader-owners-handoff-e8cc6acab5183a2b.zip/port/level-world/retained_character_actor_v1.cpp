#include "retained_character_actor_v1.hpp"
namespace dh2::character {
RetainedCharacterActorV1::RetainedCharacterActorV1(std::uintptr_t id,std::shared_ptr<void> pin):world_pin_(std::move(pin)),identity_(id){
 // Whole ObjectBase C1 33f15c: key0, cacheSELF, frameUINTMAX, room-1.
 handle_={0,UINT32_MAX,id};
}
RetainedCharacterActorV1::~RetainedCharacterActorV1(){close();}
void RetainedCharacterActorV1::close()noexcept{
 session.reset();injury.reset();state_changed.reset();machine.reset();
 animation.reset();controller.reset();diagnostics.reset();object.reset();
}
bool RetainedCharacterActorV1::set_name(void* p,const char* name,std::string& e){auto& a=*static_cast<RetainedCharacterActorV1*>(p);if(!name||a.script_attempted_){e="SetName requires pre-session canonical receiver";return false;}a.source_name_=name;return true;}
bool RetainedCharacterActorV1::set_archetype(void* p,const char* name,std::string& e){auto& a=*static_cast<RetainedCharacterActorV1*>(p);if(!name||a.script_attempted_){e="archetype requires pre-session canonical receiver";return false;}a.source_archetype_=name;return true;}
bool RetainedCharacterActorV1::as_character(void* p,std::uintptr_t& out,std::string&){out=static_cast<RetainedCharacterActorV1*>(p)->identity_;return true;}
world::CanonicalObjectBorrowV1 RetainedCharacterActorV1::canonical(std::shared_ptr<void> lease){
 return {identity_,std::move(lease),&handle_,&type_f4_,across_rooms_written_?&across_rooms87_:nullptr,&room64_,this,set_name,set_archetype,as_character};
}
bool RetainedCharacterActorV1::construct_graph(std::shared_ptr<ScriptCharacterObject> same,std::shared_ptr<const CharacterAnimationResources> resources,WorldNpcStateServicesV1 services){
 if(graph_attempted_||!identity_||!world_pin_||!same||same->identity!=identity_||!same->properties||!same->life||!resources){error_="required same registered Character graph/World/resource lifetime";return false;}
 graph_attempted_=true;object=std::move(same);
 animation=CharacterAnimationInstance::create(std::move(resources),error_);if(!animation)return false;
 controller=std::make_unique<CharacterWorldNpcControllerV1>(identity_);
 // Facts/body/predicate pointers are the retained fields, never temporaries.
 services.facts=&facts;services.bodies=&bodies;services.predicates=&predicates;
 machine=std::make_unique<CharacterWorldNpcStateOwnerV1>(identity_,services);
 ai_owner={identity_,controller->identity(),reinterpret_cast<std::uintptr_t>(&machine->native_fsm()),reinterpret_cast<std::uintptr_t>(object->properties.get()),0,0,0,0};
 ai_events={object->target.identity,&ai_owner,character_idle_ai_keys(),0,character_idle_external_keys(),0,0,0,0,0,0};
 state_changed=std::make_unique<CharacterWorldNpcStateChangedV1>(*machine,ai_events);
 return true;
}
bool RetainedCharacterActorV1::construct_script(CharacterGameDesign::Borrow&& design,CharacterScriptSessionInput input){
 if(script_attempted_||!object||!machine||!controller||!animation||source_name_.empty()||object->name!=source_name_){error_="required canonical Add name and retained graph before MonsterSession";return false;}
 script_attempted_=true;input.identity=identity_;input.name=source_name_;input.properties=object->properties;input.combat=object->life;input.position=object->position;input.source_is_character=1;input.state_machine=&machine->native_fsm();
 session=CharacterScriptSession::create(std::move(design),input,error_);if(!session)return false;
 if(!session->start()){error_=session->error();return false;}
 ScriptSessionView active{};if(!session->owner().active(active)){error_="required actual started MonsterSession active owner";return false;}
 ai_events.active=active.identity;return true;
}
}
