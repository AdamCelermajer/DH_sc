#include "../retained_character_actor_v1.hpp"
#include <cassert>
#include <iostream>
using namespace dh2::character;
int main(){
 auto pin=std::make_shared<int>(7);std::weak_ptr<int> weak=pin;
 auto actor=std::make_shared<RetainedCharacterActorV1>(0x100000123ull,pin);
 pin.reset();assert(!weak.expired());
 auto borrow=actor->canonical(actor);assert(borrow.identity==0x100000123ull);
 assert(borrow.shared_handle==&actor->shared_handle());
 assert(borrow.shared_handle->key==0&&borrow.shared_handle->cached==borrow.identity&&borrow.shared_handle->frame==UINT32_MAX);
 assert(*borrow.type_f4==0&&*borrow.room64==-1&&borrow.across_rooms87==nullptr);
 std::string error;assert(borrow.set_name(borrow.context,"CryptMonster",error));
 assert(borrow.set_archetype(borrow.context,"Goblin",error));
 assert(actor->source_name()=="CryptMonster"&&actor->source_archetype()=="Goblin");
 std::uintptr_t converted{};assert(borrow.as_character(borrow.context,converted,error)&&converted==borrow.identity);
 actor->publish_across_rooms(0);borrow=actor->canonical(actor);
 assert(borrow.across_rooms87&&*borrow.across_rooms87==0);
 *borrow.shared_handle={19,23,borrow.identity};assert(actor->shared_handle().key==19);
 assert(!actor->construct_graph({}, {}, {}));assert(!actor->error().empty());
 assert(!actor->object&&!actor->machine&&!actor->session);
 actor->close();actor->close();assert(!weak.expired());
 borrow.lease.reset();actor.reset();assert(weak.expired());
 std::cout<<"retained Character constructor/borrow/lifetime checks passed\n";
}
