#pragma once
#include "canonical_object_manager_v1.hpp"
#include "character_script_objects.hpp"
#include "character_world_npc_initialization_v1.hpp"
#include "character_animation_instance.hpp"
#include "character_animation_ai.hpp"
#include "actor_runtime.hpp"
#include "npc_injury_runtime_v1.hpp"
#include <array>
namespace dh2::character {
// Native retained ownership extracted from the renderer. No second properties,
// HP, target, FSM or timers: object is the same registry-published script object.
// This constructs the ownership graph, not a claim of complete InitPost.
class RetainedCharacterActorV1 {
 std::shared_ptr<void> world_pin_; // Must outlive every callback/VM resource.
 std::uintptr_t identity_{};
 const std::uint32_t type_f4_{0}; // Original Character factory GO_ID 0.
 target_providers::Handle16 handle_{};
 std::int32_t room64_{-1};
 std::uint8_t across_rooms87_{};bool across_rooms_written_{};
 std::string source_name_,source_archetype_,error_;
 bool graph_attempted_{},script_attempted_{};
 static bool set_name(void*,const char*,std::string&);
 static bool set_archetype(void*,const char*,std::string&);
 static bool as_character(void*,std::uintptr_t&,std::string&);
public:
 std::shared_ptr<ScriptCharacterObject> object;
 std::unique_ptr<CharacterWorldNpcStateOwnerV1> machine;
 Facts facts{};StateOwnerBehaviorPredicate8 predicates{};Services bodies{};
 std::unique_ptr<StateOwnerDebugDiagnostics> diagnostics;
 std::unique_ptr<CharacterWorldNpcControllerV1> controller;
 AIEventOwner48 ai_owner{};AIEventState64 ai_events{};
 std::unique_ptr<CharacterWorldNpcStateChangedV1> state_changed;
 std::unique_ptr<CharacterAnimationInstance> animation;
 actor::RuntimeState runtime{};AnimationAIState96 animation_ai{};
 std::uint32_t scene_clock{},application_dt{},source_animation_events{};
 float injury_gate{-1.f};bool visual_initialized{};
 std::uint8_t source_bounds_flat{0};
 std::array<float,16> bounds_root_matrix{};bool bounds_root_ready{},source_bounds_ready{};
 std::array<float,6> rendered_bounds{};bool rendered_bounds_ready{};
 std::array<float,4> rendered_screen_bounds{};bool rendered_screen_bounds_ready{};
 skills::SkillAttackNativeServicesV6 injury_debug{};
 std::unique_ptr<NpcInjuryRuntimeV1> injury;
 std::unique_ptr<CharacterScriptSession> session;
 RetainedCharacterActorV1(std::uintptr_t,std::shared_ptr<void> world_pin);
 virtual ~RetainedCharacterActorV1();
 RetainedCharacterActorV1(const RetainedCharacterActorV1&)=delete;
 RetainedCharacterActorV1& operator=(const RetainedCharacterActorV1&)=delete;
 // Derived callback transport must call close() in its destructor body, before
 // derived context disappears. Idempotent; World lease remains pinned.
 void close() noexcept;
 world::CanonicalObjectBorrowV1 canonical(std::shared_ptr<void> receiver_lease);
 target_providers::Handle16& shared_handle() noexcept{return handle_;}
 const std::string& source_name()const noexcept{return source_name_;}
 const std::string& source_archetype()const noexcept{return source_archetype_;}
 void publish_across_rooms(std::uint8_t value)noexcept{across_rooms87_=value;across_rooms_written_=true;}
 // After registered PropertyMap initialization and canonical Add: adopt SAME
 // object, create actual CPU animation, one controller and one state graph.
 // Caller supplies whole source callbacks; failure retains its mutation prefix
 // and cannot be retried on the same receiver.
 bool construct_graph(std::shared_ptr<ScriptCharacterObject>,
  std::shared_ptr<const CharacterAnimationResources>,WorldNpcStateServicesV1);
 // Host/Level/target/object providers remain caller-owned and pinned above.
 // Identity/properties/life/position/FSM are forced to the same retained graph.
 bool construct_script(CharacterGameDesign::Borrow&&,CharacterScriptSessionInput);
 const std::string& error()const noexcept{return error_;}
};
}
