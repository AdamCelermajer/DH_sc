from pathlib import Path
import sys,subprocess
r=Path(__file__).resolve().parents[1]
s=subprocess.run([sys.executable,str(r/'.local-inputs/audit_reload_components.py'),'3f82d8','386630','32ccc4'],check=True,capture_output=True,text=True).stdout
p=r/'port/level-world/reference/gameplay-camera-picking-v20';(p/'frame-original-source.asm').write_text(s)
lines=s.splitlines();interesting=set()
for i,line in enumerate(lines):
 if '#0x128]' in line or '#0x12c]' in line or 'Camera' in line or 'Scene' in line or 'glitch' in line or '; _ZN5Level' in line:
  interesting.update(range(max(0,i-5),min(len(lines),i+9)))
print('\n'.join(lines[i] for i in sorted(interesting)))
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
import struct,json
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 e=ELFFile(f);syms=list(e.get_section_by_name('.symtab').iter_symbols());names={s['st_value']:s.name for s in syms if s['st_size']}
 def word(a):
  for seg in e.iter_segments():
   if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=a<a+4<=seg['p_vaddr']+seg['p_filesz']:
    f.seek(seg['p_offset']+a-seg['p_vaddr']);return struct.unpack('<I',f.read(4))[0]
 rows=[]
 for sym in syms:
  if sym.name.startswith('_ZTV') and any(t in sym.name for t in ['CCameraSceneNode','CColladaCameraSceneNode','CameraLevel']):
   address_point=8 if 'CameraLevel' in sym.name else 0x1c
   for off in [0x10,0xb8,0x38]:
    if off+address_point+4<=sym['st_size']:
     a=word(sym['st_value']+address_point+off);rows.append({'vtable':sym.name,'address_point':hex(address_point),'slot':hex(off),'callee':hex(a),'symbol':names.get(a)})
 print(json.dumps(rows,indent=2));(p/'frame-vtable-receipt.json').write_text(json.dumps(rows,indent=2))
