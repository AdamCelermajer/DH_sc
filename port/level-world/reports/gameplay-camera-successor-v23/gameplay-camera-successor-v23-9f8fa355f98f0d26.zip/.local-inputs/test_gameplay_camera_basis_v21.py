from pathlib import Path
import os,sys,subprocess,struct,json,hashlib,math,random
r=Path(__file__).resolve().parents[1]
prefix=(r/'.local-inputs/test_gameplay_camera_picking_v20.py').read_text().split("lib=r/")[0]
exec(compile(prefix,'camera_math_import_services','exec'))
class BasisCpu(MathCpu):
 def external(self,uc,address,size,_):
  name=self.imports.get(address)
  if name in ('tanf','acosf'):
   v=floating(uc.reg_read(UC_ARM64_REG_S0) if self.arm64 else self.reg(0));out=bits(math.tan(v) if name=='tanf' else math.acos(v));uc.reg_write(UC_ARM64_REG_S0,out) if self.arm64 else self.put(0,out);self.import_calls[name]=self.import_calls.get(name,0)+1;uc.reg_write(self.pc,uc.reg_read(self.lr))
  else:return super().external(uc,address,size,_)
lib=r/'.local-inputs/libgameplay-camera-basis-v21.so'
subprocess.run([r'C:\Users\adamc\AppData\Local\Android\Sdk\ndk\29.0.14206865\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe','--target=aarch64-linux-android24','-std=c++17','-O2','-ffp-contract=off','-shared','-fPIC',str(r/'port/level-world/gameplay_camera_basis_v21.cpp'),'-o',str(lib)],check=True,env=dict(os.environ,TEMP=str(r/'.local-inputs'),TMP=str(r/'.local-inputs')))
old=BasisCpu(r/'.local-inputs/libDungeonHunter2.so',False,{'functions':[]});new=BasisCpu(lib,True,{'functions':[]});old.invoke(0x312e00,[])
base=old.data+0x1000;node=base+0x1000;vtable=base+0x2000;matrix=base+0x3000;out=base+0x4000;getmatrix=old.stop+0x100;getfov=old.stop+0x104
old.pointer(base+8,node);old.pointer(node,vtable);old.pointer(vtable+0x38,getmatrix);old.pointer(vtable+0x128,getfov)
fovs=[];eye=0;calls=[];trace=[]
def hook(uc,address,size,_):
 if address<0x300000:
  raise RuntimeError(('unexpected source branch',hex(address),trace))
 trace.append(hex(address));del trace[:-30]
 if address==getmatrix:old.put(0,matrix);calls.append('matrix')
 elif address==getfov:old.put(0,bits(fovs.pop(0)));calls.append('fov')
 elif address==0x597180:uc.mem_write(old.reg(0),struct.pack('<3f',0,0,eye));calls.append('position')
 else:return
 # Imported/virtual fixtures return ARM code addresses; the Thumb flag is
 # never manufactured by these source receiver methods.
 uc.reg_write(old.pc,uc.reg_read(old.lr))
old.uc.hook_add(UC_HOOK_CODE,hook);rng=random.Random(0x40f4dc);cases=0
for i in range(160):
 direction=[rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,-.1)] if i>=32 else [0.,0.,-1.] if i<16 else [.00001,.00001,-1.]
 eye=rng.uniform(1500,4000);height=rng.uniform(-500,500);first=rng.uniform(.05,.5);second=first if i%2 else rng.uniform(.05,.5)
 m=[0.]*16;m[4:7]=direction;old.uc.mem_write(matrix,struct.pack('<16f',*m));old.uc.mem_write(out,b'\xa5'*12);fovs=[first,second];calls=[]
 try:ret=old.invoke(0x40f4dc,[base,out,bits(height)])
 except Exception:
  print('original failure',i,hex(old.uc.reg_read(old.pc)),calls,trace);raise
 expected=bytes(old.uc.mem_read(out,12))
 no=new.data+0x1000;ni=no+0x100;new.uc.mem_write(ni,struct.pack('<10f',*direction,eye,height,first,second,0,0,1));new.invoke('dh2_camera_center_offset_v21',[no,ni]);actual=bytes(new.uc.mem_read(no,12));assert actual==expected,(i,struct.unpack('<3f',expected),struct.unpack('<3f',actual));assert ret==1;assert calls==(['matrix'] if i<32 else ['matrix','position','fov','fov']);cases+=1
capture=subprocess.run([sys.executable,str(r/'.local-inputs/audit_reload_components.py'),'40f4dc','40e8a8','40e928','313058','312f40','34d0b0','312e00'],check=True,capture_output=True,text=True)
p=r/'port/level-world/reference/gameplay-camera-basis-v21';p.mkdir(exist_ok=True);(p/'original-source.asm').write_text(capture.stdout)
report={'status':'PASS','cases':cases,'mismatches':0,'scope':'Whole original CameraBase.GetCenterOffset vs ARM64 source arithmetic, including exact virtual read order and early horizontal threshold; actual Point3D global initializer executed. Virtual actual matrix/position/repeated FOV boundaries declared fixtures; no live camera acceptance.','original_sha256':hashlib.sha256((r/'.local-inputs/libDungeonHunter2.so').read_bytes()).hexdigest(),'native_sha256':hashlib.sha256(lib.read_bytes()).hexdigest()}
(p/'original-receipt.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
