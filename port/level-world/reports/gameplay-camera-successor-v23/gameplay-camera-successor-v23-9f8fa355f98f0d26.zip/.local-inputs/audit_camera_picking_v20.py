from pathlib import Path
import sys,subprocess,json
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
r=Path(__file__).resolve().parents[1]
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 e=ELFFile(f);rows=[{'name':s.name,'address':hex(s['st_value']),'size':s['st_size']} for s in e.get_section_by_name('.symtab').iter_symbols() if s['st_size'] and any(t in s.name for t in ['getRayFromScreenCoordinates','getScreenCoordinatesFrom3DPosition','CameraBase','getIntersectionWithLine','getViewFrustum','ViewFrustum','viewFrustum','recalculateViewArea','recalculateViewMatrix','_ZN5Level6Update','_ZN7GSLevel6Update','_ZN11Application6Update'])]
p=r/'port/level-world/reference/gameplay-camera-picking-v20';p.mkdir(exist_ok=True)
(p/'symbols.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
sys.path.insert(0,str(r/'port/engine-ui/tests'))
from gfnt_differential import Cpu
c=Cpu(r/'.local-inputs/libDungeonHunter2.so',False,{'functions':[]})
print({hex(x):c.imports.get(x) for x in [0x30e1c0,0x30df8c,0x30e4b4,0x30df2c,0x30e124,0x30e3dc]})
for x in [0x30ecb8,0x30e1c0,0x30df8c,0x30e4b4,0x30df2c,0x30e124,0x30e3dc]:
 try:c.invoke(x,[0,0,0,0])
 except Exception as ex:print(hex(x),str(ex))
