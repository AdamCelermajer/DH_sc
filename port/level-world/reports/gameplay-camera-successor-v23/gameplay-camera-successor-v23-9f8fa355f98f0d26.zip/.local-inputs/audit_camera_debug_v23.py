from pathlib import Path
import struct,json,sys
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
r=Path(__file__).resolve().parents[1]
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 e=ELFFile(f)
 def read(a,n):
  for seg in e.iter_segments():
   if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=a<a+n<=seg['p_vaddr']+seg['p_filesz']:
    f.seek(seg['p_offset']+a-seg['p_vaddr']);return f.read(n)
 delta=struct.unpack('<i',read(0x47667c,4))[0];address=0x476620+delta
 report={'call':'AnimSet.AddAnim Debug.load then GetSwitch, return ignored','string_address':hex(address),'name':read(address,23).decode('ascii'),'source_literal_word':'0x47667c','source_add_pc':'0x476618+8'}
 print(json.dumps(report,indent=2));p=r/'port/level-world/reference/gameplay-camera-picking-v20';(p/'debug-after-add-v23.json').write_text(json.dumps(report,indent=2))
