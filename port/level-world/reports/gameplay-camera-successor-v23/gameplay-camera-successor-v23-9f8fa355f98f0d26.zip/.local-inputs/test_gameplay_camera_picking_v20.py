from pathlib import Path
import os,sys,subprocess,struct,json,hashlib,math,random
r=Path(__file__).resolve().parents[1]
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages');sys.path.insert(0,str(r/'port/engine-ui/tests'))
from gfnt_differential import Cpu,bits,floating
from unicorn.arm64_const import UC_ARM64_REG_S0,UC_ARM64_REG_D0
from unicorn import UC_HOOK_CODE
class MathCpu(Cpu):
 def double(self,i=0):return struct.unpack('<d',struct.pack('<II',self.reg(i),self.reg(i+1)))[0]
 def putdouble(self,v):
  a,b=struct.unpack('<II',struct.pack('<d',v));self.put(0,a);self.put(1,b)
 def external(self,uc,address,size,_):
  name=self.imports.get(address)
  if name in ('__aeabi_fadd','__aeabi_fsub'):
   a,b=floating(self.reg(0)),floating(self.reg(1));self.put(0,bits(a+b if name.endswith('add') else a-b))
  elif name in ('__aeabi_fcmpeq','__aeabi_fcmpge','__aeabi_fcmplt'):
   a,b=floating(self.reg(0)),floating(self.reg(1));self.put(0,int(a==b if name.endswith('eq') else a>=b if name.endswith('ge') else a<b))
  elif name=='__aeabi_f2d':self.putdouble(floating(self.reg(0)))
  elif name=='__aeabi_d2f':self.put(0,bits(self.double()))
  elif name=='__aeabi_dmul':self.putdouble(self.double()*self.double(2))
  elif name=='__aeabi_ddiv':self.putdouble(self.double()/self.double(2))
  elif name=='__aeabi_dcmplt':self.put(0,int(self.double()<self.double(2)))
  elif name=='floorf':
   v=floating(uc.reg_read(UC_ARM64_REG_S0) if self.arm64 else self.reg(0));out=bits(math.floor(v));uc.reg_write(UC_ARM64_REG_S0,out) if self.arm64 else self.put(0,out)
  elif name in ('sqrt','sqrtf'):
   v=struct.unpack('<d',struct.pack('<Q',uc.reg_read(UC_ARM64_REG_D0)))[0] if self.arm64 and name=='sqrt' else floating(uc.reg_read(UC_ARM64_REG_S0)) if self.arm64 else self.double() if name=='sqrt' else floating(self.reg(0))
   out=math.sqrt(v)
   if self.arm64:uc.reg_write(UC_ARM64_REG_D0,struct.unpack('<Q',struct.pack('<d',out))[0]) if name=='sqrt' else uc.reg_write(UC_ARM64_REG_S0,bits(out))
   elif name=='sqrt':self.putdouble(out)
   else:self.put(0,bits(out))
  else:return super().external(uc,address,size,_)
  self.import_calls[name]=self.import_calls.get(name,0)+1;uc.reg_write(self.pc,uc.reg_read(self.lr))
lib=r/'.local-inputs/libgameplay-camera-picking-v20.so'
subprocess.run([r'C:\Users\adamc\AppData\Local\Android\Sdk\ndk\29.0.14206865\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe','--target=aarch64-linux-android24','-std=c++17','-O2','-ffp-contract=off','-shared','-fPIC',str(r/'port/level-world/gameplay_camera_picking_v20.cpp'),'-o',str(lib)],check=True,env=dict(os.environ,TEMP=str(r/'.local-inputs'),TMP=str(r/'.local-inputs')))
old=MathCpu(r/'.local-inputs/libDungeonHunter2.so',False,{'functions':[]});new=MathCpu(lib,True,{'functions':[]});rng=random.Random(0x6c59c0);cases=0
def compare(addr,name,inputs,outbytes=12):
 global cases
 outputs=[]
 for cpu,symbol in [(old,addr),(new,name)]:
  ps=[cpu.data+0x1000+i*0x1000 for i in range(len(inputs)+1)]
  for p,data in zip(ps,inputs):cpu.uc.mem_write(p,data)
  cpu.uc.mem_write(ps[-1],b'\xa5'*outbytes)
  ret=cpu.invoke(symbol,[*ps[:-1],ps[-1]])
  outputs.append((ret,bytes(cpu.uc.mem_read(ps[-1],outbytes))))
 assert outputs[0]==outputs[1],(hex(addr),cases,outputs)
 cases+=1
for i in range(128):
 plane=[rng.uniform(-1,1) for _ in range(3)]+[rng.uniform(-200,200)]
 a=[rng.uniform(-400,400) for _ in range(3)];b=[rng.uniform(-400,400) for _ in range(3)]
 compare(0x34033c,'dh2_camera_plane_line_v20',[struct.pack('<4f',*plane),struct.pack('<3f',*a),struct.pack('<3f',*b)])
 compare(0x40f0b4,'dh2_camera_limited_plane_v20',[struct.pack('<4f',*plane),struct.pack('<3f',*a),struct.pack('<3f',*b)])
for i in range(128):
 inputs=[]
 for n in range(3):
  v=[rng.uniform(-1,1) for _ in range(3)];l=math.sqrt(sum(x*x for x in v));inputs.append(struct.pack('<4f',*[x/l for x in v],rng.uniform(-400,400)))
 compare(0x3415d8,'dh2_camera_three_planes_v20',inputs)
# Whole CollisionManager ray: virtual getFrustum/isOrthographic and actual
# configured driver rectangle are named boundaries; original all plane and
# interpolation instructions run, including actual NULL-camera active lookup.
cm=old.data+0x110000;sm=cm+0x1000;driver=cm+0x2000;rect=cm+0x3000;camera=cm+0x4000;vt=cm+0x5000;frustum=cm+0x6000
get_frustum=old.stop+0x100;get_ortho=old.stop+0x104
old.pointer(cm+8,sm);old.pointer(cm+12,driver);old.pointer(driver+0xcc,rect+4);old.pointer(rect,rect+0x100);old.pointer(sm+0xe4,camera);old.pointer(camera,vt);old.pointer(vt+0x144,get_frustum);old.pointer(vt+0x150,get_ortho)
ortho=0;project_matrix=old.data+0x150000;view_matrix=project_matrix+0x100;driver_vt=project_matrix+0x200;context=project_matrix+0x300;get_matrix=old.stop+0x108;quantize_only=False
get_projection=old.stop+0x10c;get_view=old.stop+0x110
old.pointer(0x99f72c+0x10,context);old.pointer(context+0x10,driver);old.pointer(driver,driver_vt);old.pointer(driver_vt+0x70,get_matrix);old.pointer(vt+0xf8,get_projection);old.pointer(vt+0xfc,get_view)
def hook(uc,address,size,_):
 if address==get_frustum:old.put(0,frustum)
 elif address==get_ortho:old.put(0,ortho)
 elif address==0x5823d4:pass # Bounding box not read by any picking body.
 elif address==get_matrix:old.put(0,project_matrix if old.reg(1)==2 else view_matrix)
 elif address==get_projection:old.put(0,project_matrix)
 elif address==get_view:old.put(0,view_matrix)
 elif address==0x40f2f0 and quantize_only:
  q=bytes(uc.mem_read(old.reg(0),8));uc.mem_write(old.reg(1),q);old.put(0,1)
 else:return
 uc.reg_write(old.pc,uc.reg_read(old.lr))
old.uc.hook_add(UC_HOOK_CODE,hook)
for i in range(64):
 # Valid perspective engine matrix, tilted view. Both CPUs use original
 # extraction outputs; extraction itself is compared before ray execution.
 aspect=1.7777778;near=600.;far=10000.;t=1/math.tan(.429630011*.5)
 m=[t/aspect,0,0,0,0,t,0,0,0,0,far/(far-near),1,0,0,-near*far/(far-near),0]
 matrix=old.data+0x120000;old.uc.mem_write(matrix,struct.pack('<16f',*m));old.uc.mem_write(frustum,struct.pack('<3f',0,0,0)+b'\xa5'*96);old.invoke(0x5826c0,[frustum,matrix]);planes=bytes(old.uc.mem_read(frustum+12,96))
 np=new.data+0x120000;nm=new.data+0x121000;new.uc.mem_write(nm,struct.pack('<16f',*m));new.invoke('dh2_camera_frustum_planes_v20',[np,nm]);assert bytes(new.uc.mem_read(np,96))==planes;cases+=1
 width,height=[(960,540),(1280,720),(1920,1080),(320,480)][i%4];x,y=rng.randrange(-200,width+200),rng.randrange(-200,height+200);ortho=i%2
 old.uc.mem_write(rect+0x114,struct.pack('<4i',0,0,width,height));pixel=old.data+0x122000;out=old.data+0x123000;old.uc.mem_write(pixel,struct.pack('<2i',x,y));old.invoke(0x6c59c0,[out,cm,pixel,0 if i%3==0 else camera]);expected=bytes(old.uc.mem_read(out,24))
 addresses=[new.data+0x130000+n*0x1000 for n in range(5)];new.uc.mem_write(addresses[1],struct.pack('<3f',0,0,0));new.uc.mem_write(addresses[2],planes);new.uc.mem_write(addresses[3],struct.pack('<2i',x,y));new.uc.mem_write(addresses[4],struct.pack('<2i',width,height));new.invoke('dh2_camera_ray_v20',addresses+[ortho]);actual=bytes(new.uc.mem_read(addresses[0],24));assert actual==expected,('ray',i,struct.unpack('<6f',expected),struct.unpack('<6f',actual),x,y,width,height);cases+=1
for i in range(128):
 p=[rng.uniform(-4000,4000) for _ in range(3)];projection=[rng.uniform(-2,2) for _ in range(16)];view=[rng.uniform(-2,2) for _ in range(16)]
 old.uc.mem_write(project_matrix,struct.pack('<16f',*projection));old.uc.mem_write(view_matrix,struct.pack('<16f',*view));op=old.data+0x160000;oo=op+0x100;old.uc.mem_write(op,struct.pack('<3f',*p));old.invoke(0x40f714,[op,oo]);expected=bytes(old.uc.mem_read(oo,8))
 ns=[new.data+0x160000+n*0x1000 for n in range(4)];new.uc.mem_write(ns[1],struct.pack('<3f',*p));new.uc.mem_write(ns[2],struct.pack('<16f',*projection));new.uc.mem_write(ns[3],struct.pack('<16f',*view));new.invoke('dh2_camera_screen_coord_v20',ns);actual=bytes(new.uc.mem_read(ns[0],8));assert actual==expected,('screen',i);cases+=1
 quantize_only=True
 width,height=[(960,540),(1280,720),(1920,1080),(320,480)][i%4];q=[rng.uniform(-2,2),rng.uniform(-2,2)];old.uc.mem_write(rect+0x10c,struct.pack('<2i',width,height));old.uc.mem_write(op,struct.pack('<2f',*q));old.invoke(0x40f394,[op,oo,bits(0)]);expected=bytes(old.uc.mem_read(oo,8));new.uc.mem_write(ns[1],struct.pack('<2f',*q));new.uc.mem_write(ns[2],struct.pack('<2i',width,height));new.invoke('dh2_camera_screen_pixel_v20',ns[:3]);assert bytes(new.uc.mem_read(ns[0],8))==expected,('quantize',i);quantize_only=False;cases+=1
 old.uc.mem_write(op,struct.pack('<3f',*p));old.uc.mem_write(rect+0x114,struct.pack('<4i',13,27,width+13+(i%2),height+27+(i%2)));old.invoke(0x6c57d8,[oo,cm,op,camera]);expected=bytes(old.uc.mem_read(oo,8));new.uc.mem_write(ns[1],struct.pack('<3f',*p));new.uc.mem_write(ns[2],struct.pack('<16f',*projection));new.uc.mem_write(ns[3],struct.pack('<16f',*view));sz=ns[-1]+0x100;new.uc.mem_write(sz,struct.pack('<2i',width+(i%2),height+(i%2)));new.invoke('dh2_camera_project_pixel_v20',ns+[sz]);actual=bytes(new.uc.mem_read(ns[0],8));assert actual==expected,('projectpixel',i,expected.hex(),actual.hex());cases+=1
capture=subprocess.run([sys.executable,str(r/'.local-inputs/audit_reload_components.py'),'40f394','40f2f0','40f714','6c59c0','5826c0','3415d8','341260','34033c','40f0b4','40e8a8','40e928'],check=True,capture_output=True,text=True)
p=r/'port/level-world/reference/gameplay-camera-picking-v20';p.mkdir(exist_ok=True)
(p/'original-source.asm').write_text(capture.stdout)
report={'status':'PASS','cases':cases,'mismatches':0,'scope':'Original plane/limited-line/three-plane, normalized frustum extraction, whole CollisionManager ray, CameraBase normalized screen and viewport quantization vs optimized ARM64. Actual virtual frustum/orthographic and driver matrix/viewport endpoints declared fixtures; bounding-box side effect excluded; imported softfloat/sqrt modeled. Not live picking acceptance.','original_sha256':hashlib.sha256((r/'.local-inputs/libDungeonHunter2.so').read_bytes()).hexdigest(),'native_sha256':hashlib.sha256(lib.read_bytes()).hexdigest()}
(p/'original-receipt.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
