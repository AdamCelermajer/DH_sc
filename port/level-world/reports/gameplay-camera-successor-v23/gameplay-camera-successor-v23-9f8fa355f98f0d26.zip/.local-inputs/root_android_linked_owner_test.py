import hashlib,json,re,shlex,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ADB=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
name=sys.argv[1];assert re.fullmatch('[a-z0-9-]+',name)
tail=sys.argv[2:];separator=tail.index('--') if '--' in tail else len(tail)
sources=[ROOT/p for p in tail[:separator]];runtime_args=tail[separator+1:]
assert all(re.fullmatch('[a-zA-Z0-9_./-]+',a) for a in runtime_args)
apk=ROOT/'port/android-native/app/build/outputs/apk/debug/app-debug.apk'
apk_hash=hashlib.sha256(apk.read_bytes()).hexdigest()
out=ROOT/'port/level-world/reports/android-native-owner-tests'/name;out.mkdir(parents=True,exist_ok=True)
libs=out/'linked-libs';libs.mkdir(exist_ok=True)
with zipfile.ZipFile(apk) as z:
 entries=[n for n in z.namelist() if n.startswith('lib/x86_64/') and n.endswith('.so')]
 for n in entries:(libs/Path(n).name).write_bytes(z.read(n))
db=ROOT/'port/android-native/app/.cxx/Debug/5a1n3w3m/x86_64/compile_commands.json'
entry=next(e for e in json.loads(db.read_text()) if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
args=entry.get('arguments') or [s.strip('"') for s in shlex.split(entry['command'],posix=False)]
flags=[s for s in args[1:] if s.startswith(('--target=','--sysroot=','-I','-isystem'))]
for i,s in enumerate(args):
 if s=='-isystem':flags.append(args[i+1])
hashes=[{'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]
binary=out/(name+'.bin')
cmd=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-ffunction-sections','-fdata-sections','-static-libstdc++',*[str(p) for p in sources],'-L'+str(libs),'-Wl,--start-group',*['-l:'+p.name for p in sorted(libs.glob('*.so'))],'-Wl,--end-group','-Wl,--gc-sections','-Wl,-rpath-link,'+str(libs),'-o',str(binary)]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(r.stdout+r.stderr,encoding='utf8')
if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
assert all(h['sha256']==hashlib.sha256(p.read_bytes()).hexdigest() for h,p in zip(hashes,sources))
remote='/data/local/tmp/dh2-linked-'+name
def adb(*args):return subprocess.run([ADB,'-s','emulator-5554',*args],capture_output=True,text=True,check=True,timeout=40)
adb('shell','mkdir','-p',remote)
for p in [*sorted(libs.glob('*.so')),binary]:adb('push',str(p),remote+'/'+p.name)
adb('shell','chmod','700',remote+'/'+binary.name)
run=subprocess.run([ADB,'-s','emulator-5554','shell','LD_LIBRARY_PATH='+remote+' '+remote+'/'+binary.name,*runtime_args],capture_output=True,text=True,timeout=45)
receipt={'status':'PASS' if not run.returncode else 'FAIL','scope':'actual APK-linked native object owners, same base/property storage with declared external service fixtures; not full live level acceptance','apk_sha256':apk_hash,'sources':hashes,'libraries':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(libs.glob('*.so'))],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compile':cmd,'stdout':run.stdout,'stderr':run.stderr,'exit_code':run.returncode}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({'status':receipt['status'],'apk_sha256':apk_hash,'stdout':run.stdout,'stderr':run.stderr,'receipt':str(out/'receipt.json')},indent=2));raise SystemExit(run.returncode)
