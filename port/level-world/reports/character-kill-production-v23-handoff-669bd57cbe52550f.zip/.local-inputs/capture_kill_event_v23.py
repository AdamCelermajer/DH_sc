from pathlib import Path
import sys,json,hashlib,struct
sys.path.insert(0,r'C:/Users/adamc/AppData/Local/uv/cache/archive-v0/jc8RoeQ1US_9Gkmi/Lib/site-packages')
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
r=Path(__file__).resolve().parent.parent;out=r/'port/level-world/reference/character-kill-event-v23';out.mkdir(exist_ok=True)
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 e=ELFFile(f);segs=[s for s in e.iter_segments() if s['p_type']=='PT_LOAD'];symbols=list(e.get_section_by_name('.symtab').iter_symbols());dis=Cs(CS_ARCH_ARM,CS_MODE_ARM)
 def read(a,n):
  for s in segs:
   if s['p_vaddr']<=a<a+n<=s['p_vaddr']+s['p_filesz']:return s.data()[a-s['p_vaddr']:a-s['p_vaddr']+n]
 rows=[];tables=[]
 for s in symbols:
  a=int(s['st_value']);n=int(s['st_size'])
  if s['st_info']['type']=='STT_FUNC' and ('OnKilled' in s.name or 'OnKill' in s.name or 'TargetDied' in s.name or 'TargetDead' in s.name or any(k in s.name for k in ['QE_KillEnemies','QE_ClearEnemies','QE_KillEnemyTemplate','QE_ClearEnemyTemplate','QE_Base'])):
   b=read(a,n);rows.append({'name':s.name,'address':hex(a),'bytes':n,'sha256':hashlib.sha256(b).hexdigest(),'instructions':[f'{i.address:08x} {i.mnemonic} {i.op_str}' for i in dis.disasm(b,a)]})
  if s.name in ['_ZTV11AISExternal','_ZTV15AISPlayerIPhone','_ZTV9AISPlayer','_ZTV10AISDefault','_ZTV10AISMonster','_ZTV8AISFaery','_ZTV6CharAI'] or (s.name.startswith('_ZTV') and any(k in s.name for k in ['QE_KillEnemies','QE_ClearEnemies','QE_KillEnemyTemplate','QE_ClearEnemyTemplate','QE_Base'])):
   entries=list(struct.unpack('<'+'I'*(n//4),read(a,n)));tables.append({'name':s.name,'address':hex(a),'entries':[{ 'slot':hex(i*4-8),'method':hex(v),'symbols':[x.name for x in symbols if v and x['st_value']==v]} for i,v in enumerate(entries)]})
 (out/'source-functions.json').write_text(json.dumps(rows,indent=2));(out/'source-vtables.json').write_text(json.dumps(tables,indent=2));print(json.dumps([{k:v for k,v in x.items() if k!='instructions'} for x in rows],indent=2));print(json.dumps([{'name':x['name'],'b0':[a for a in x['entries'] if a['slot']=='0xb0']} for x in tables],indent=2))
