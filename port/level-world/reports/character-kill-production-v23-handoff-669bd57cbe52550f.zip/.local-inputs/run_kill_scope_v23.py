from pathlib import Path
import sys,subprocess,json,hashlib
r=Path(__file__).resolve().parent.parent;adb=r'C:/Users/adamc/AppData/Local/Android/Sdk/platform-tools/adb.exe';p=r/'port/android-native/app/src/main/assets/data/scripts/ai/_commons.luac';remote='/data/local/tmp/dh2-kill-scope-v23-commons.luac'
subprocess.run([adb,'-s','emulator-5554','push',str(p),remote],check=True)
(r/'port/level-world/reference/character-kill-event-v23/native-commons.json').write_text(json.dumps({'source':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
sources=['tests/character_kill_contributor_event_v23.cpp','character_ais_kill_vm_v23.cpp','character_kill_contributor_event_v23.cpp']
raise SystemExit(subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'character-kill-contributor-v23',*['port/level-world/'+s for s in sources],'--',remote],cwd=r).returncode)
