from pathlib import Path
r=Path(__file__).resolve().parent.parent
s=(r/'port/level-world/tests/character_script_owner.cpp').read_text()
s=s.replace('character_script_owner.hpp','character_script_owner_v2.hpp').replace('ScriptOwnerServices','ScriptOwnerServicesV2').replace('std::unique_ptr<ScriptOwner>','std::unique_ptr<ScriptOwnerV2>').replace('new ScriptOwner(','new ScriptOwnerV2(').replace('ScriptOwner&','ScriptOwnerV2&')
(r/'port/level-world/tests/character_script_owner_v23_fixture.inc').write_text('// Generated reuse of original owner fixture over real ScriptOwnerV2.\n'+s)
