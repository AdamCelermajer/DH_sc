from pathlib import Path
import sys,json,struct,hashlib
sys.path.insert(0,r'C:/Users/adamc/AppData/Local/uv/cache/archive-v0/jc8RoeQ1US_9Gkmi/Lib/site-packages')
r=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(r/'port/game-data/tests'))
from aggro_differential import Cpu
from unicorn import UC_HOOK_CODE
c=Cpu(r/'.local-inputs/libDungeonHunter2.so',False,{'functions':[]});receiver=c.data+0x1000;killed=c.data+0x4000;records=[];calls=[]
def word(a):return struct.unpack('<I',c.uc.mem_read(a,4))[0]
def text(a):
 b=bytearray()
 while c.uc.mem_read(a,1)!=b'\0':b+=c.uc.mem_read(a,1);a+=1
 return b.decode()
def hook(uc,a,size,user):
 if a in [0x3192b4,0x319228]:calls.append(['args_ctor' if a==0x3192b4 else 'args_dtor']);uc.reg_write(c.pc,uc.reg_read(c.lr))
 elif a==0x386f28:calls.append(['GameObject',c.reg(1)]);uc.reg_write(c.pc,uc.reg_read(c.lr))
 elif a==0x37c41c:calls.append(['CallScript',c.reg(0),text(c.reg(1))]);uc.reg_write(c.pc,uc.reg_read(c.lr))
c.uc.hook_add(UC_HOOK_CODE,hook)
for flags in [0,1,0x400,0xffffffff]:
 calls.clear();c.uc.mem_write(receiver,bytes(0xc0));c.pointer(receiver+0xb8,flags);c.invoke(0x3ddb10,[receiver,killed]);assert bool(calls)==bool(flags&0x400)
 if calls:assert calls==[['args_ctor'],['GameObject',killed],['CallScript',receiver,'OnKill'],['args_dtor']]
 records.append({'flags':flags,'calls':list(calls)})
# Actual IEvent getEventID field4, inherited by all four QE vtables.
gettype=[]
for value in [0,1,0x7fffffff,0xffffffff]:c.pointer(receiver+4,value);assert c.invoke(0x31d8dc,[receiver])==value;gettype.append(value)
report={'status':'PASS','original_sha256':hashlib.sha256((r/'.local-inputs/libDungeonHunter2.so').read_bytes()).hexdigest(),'AISPlayer_OnKill_cases':records,'IEvent_getEventID_cases':gettype,'scope':'Whole OnKill3ddb10 gate/order and exact literal OnKill; argument-list/object/CallScript services observed. Default bx-lr executes. Whole inherited IEvent31d8dc field4 getter executes.'}
(r/'port/level-world/reference/character-kill-event-v23/callback-original.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
