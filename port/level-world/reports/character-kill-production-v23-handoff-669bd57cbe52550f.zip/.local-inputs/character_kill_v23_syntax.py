from pathlib import Path
r=Path(__file__).resolve().parent.parent
s=(r/'.local-inputs/generic_lua_script_v13_syntax.py').read_text()
s=s.replace("sources=['port/level-world/generic_lua_script_owner_v13.cpp','port/level-world/tests/generic_lua_script_owner_v13.cpp']","sources=['port/level-world/character_ais_kill_vm_v23.cpp','port/level-world/character_kill_contributor_event_v23.cpp','port/level-world/character_kill_level_events_v23.cpp','port/level-world/character_kill_production_v23.cpp']")
s=s.replace('generic-lua-script-v13-arm64-syntax.json','character-kill-v23-arm64-syntax.json').replace('generic Lua owner/test only','Kill V23 native providers only')
exec(compile(s,str(__file__),'exec'))
