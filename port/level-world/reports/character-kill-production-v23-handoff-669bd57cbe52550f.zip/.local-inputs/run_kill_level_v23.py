from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent.parent
subprocess.run([sys.executable,str(r/'.local-inputs/root_level_bindings_inputs_v4.py')],check=True)
sources=['port/level-world/tests/character_kill_level_events_v23.cpp','port/level-world/character_kill_level_events_v23.cpp','port/level-loader/level_constructor_bindings_v4.cpp','port/level-loader/level_constructor_v3.cpp','port/level-loader/canonical_level_context_v1.cpp','port/level-world/event_manager_owner_v12.cpp','port/level-world/generic_lua_script_owner_v13.cpp','port/level-world/level_savegame_owner_v1.cpp','port/level-world/level_savegame_cache_v1.cpp','port/level-world/level_savegame_runtime_v1.cpp']
base='/data/local/tmp/dh2-level-c1-v4-original'
raise SystemExit(subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'character-kill-level-events-v23',*sources,'--',base+'/design.bin',base+'/scripts',base+'/missing-save-files'],cwd=r).returncode)
