import sys,json
from pathlib import Path
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
out=Path('port/level-world/reference/character-menu-faery-connection-v8');out.mkdir(parents=True,exist_ok=True)
addresses={0x3aa1b4,0x3cebf0,0x3a3054,0x3a3094,0x3a307c,0x3ae99c,0x3a54d4,0x394d34,0x3c99a0,0x3f0898,0x43eeb0}
with open('.local-inputs/libDungeonHunter2.so','rb') as f:
 e=ELFFile(f);symbols={}
 for sec in e.iter_sections():
  if sec.header['sh_type'] in ('SHT_DYNSYM','SHT_SYMTAB'):
   for s in sec.iter_symbols():
    if s['st_size'] and s['st_value'] in addresses:symbols[s['st_value']]=(s.name,s['st_size'])
 md=Cs(CS_ARCH_ARM,CS_MODE_ARM);lines=[]
 for address,(name,size) in sorted(symbols.items()):
  seg=next(s for s in e.iter_segments() if s['p_vaddr']<=address and address+size<=s['p_vaddr']+s['p_filesz'])
  f.seek(seg['p_offset']+address-seg['p_vaddr']);data=f.read(size)
  lines.append(f'# {name} {address:x} {size}')
  for i in md.disasm(data,address):lines.append(f'{i.address:08x} {i.mnemonic} {i.op_str}')
 (out/'original-functions.asm').write_text('\n'.join(lines)+'\n')
 (out/'symbols.json').write_text(json.dumps({hex(a):{'name':n,'size':s} for a,(n,s) in symbols.items()},indent=2))
for l in lines:
 if '#0x420]' in l or '#0x420' in l:print(l)
start=next(i for i,l in enumerate(lines) if l.startswith('# ') and ' 3cebf0 ' in l)
stop=next((i for i in range(start+1,len(lines)) if lines[i].startswith('# ')),len(lines))
print('\n'.join(lines[start:stop]))
for address in (0x3a3054,):
 start=next(i for i,l in enumerate(lines) if l.startswith('# ') and f' {address:x} ' in l)
 print('\n'.join(lines[start:start+12]))
