import json,shlex,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cpp=root/'port/android-native/app/src/main/cpp'
source=(cpp/'model_renderer.cpp').read_text()
source='#include "character_menu_faery_connection_v8.hpp"\n#include "level_faery_placement_v8.hpp"\n'+source
source=source.replace('#include "renderer_character_mutations_v4.inc"','#include "renderer_character_mutations_v4.inc"\n#include "renderer_character_faery_v8.inc"')
temporary=root/'.local-inputs/model_renderer_faery_v8_syntax.cpp';temporary.write_text(source)
for abi in ['arm64-v8a','x86_64']:
 path=root/'port/android-native/app/.cxx/Debug/5a1n3w3m'/abi/'compile_commands.json'
 entries=json.loads(path.read_text());entry=next(e for e in entries if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
 args=entry.get('arguments') or [s.strip('"') for s in shlex.split(entry['command'],posix=False)]
 command=[args[0],'-I'+str(cpp)]
 skip=False
 for a in args[1:]:
  if skip:skip=False;continue
  if a=='-o':skip=True;continue
  if a in ['-c',str(cpp/'model_renderer.cpp')] or a.replace('\\','/').endswith('/model_renderer.cpp'):continue
  command.append(a)
 command+=['-fsyntax-only',str(temporary)]
 result=subprocess.run(command,capture_output=True,text=True,timeout=60)
 (root/'.local-inputs'/f'renderer-faery-v8-{abi}.log').write_text(result.stdout+result.stderr)
 print(abi,result.returncode,result.stderr[:2500])
 if result.returncode:raise SystemExit(result.returncode)
