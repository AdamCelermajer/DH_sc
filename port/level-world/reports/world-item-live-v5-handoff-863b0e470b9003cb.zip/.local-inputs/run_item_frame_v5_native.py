from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent.parent
receipt=json.loads((root/'port/level-world/reports/android-native-owner-tests/item-generic-frame-v4/receipt.json').read_text())
sources=[s['path'].replace('\\','/') for s in receipt['sources']]
sources[0]='port/level-world/tests/world_item_frame_v5.cpp';sources+=['port/level-world/world_item_frame_v5.cpp','port/level-world/gameobject_online_update_v5.cpp']
# Existing isolated original Crypt fixture files are owned test inputs.
old=receipt['compile'];print('Fixture inputs inherited from original Item-frame proof')
remote='/data/local/tmp/dh2-item-live-v5'
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote+'/crypt'],check=True,capture_output=True)
for name in ['crypt.bdae','crypt.dwld']:
 path=root/'port/android-native/app/src/main/assets/worlds'/('crypt01.dwld' if name=='crypt.dwld' else name)
 subprocess.run([adb,'-s','emulator-5554','push',str(path),remote+'/crypt/'+name],check=True,capture_output=True)
subprocess.run([sys.executable,str(root/'.local-inputs/root_android_linked_owner_test.py'),'world-item-frame-v5',*sources,'--',remote+'/loot',remote+'/audiovisual',remote+'/visual',remote+'/crypt/crypt.bdae',remote+'/crypt/crypt.dwld'],cwd=root,check=True)
