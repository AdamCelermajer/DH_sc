from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent.parent
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
remote='/data/local/tmp/dh2-item-live-v5'
paths=[('.local-inputs/player-loot-v7/cache','loot',['loot_table_pyarray.bin','loot_table_pyarraynames.bin','loot_table_pystructnames.bin']),('.local-inputs/loot-world-v8/cache','audiovisual',['loot_audiovisual_pyarray.bin','loot_audiovisual_pyarraynames.bin','loot_audiovisual_pystructnames.bin']),('.local-inputs/item-visual-cache-v2','visual',['itemdrops.bdae'])]
for local,directory,names in paths:
 subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote+'/'+directory],check=True,capture_output=True)
 for name in names:subprocess.run([adb,'-s','emulator-5554','push',str(root/local/name),remote+'/'+directory+'/'+name],check=True,capture_output=True)
receipt=json.loads((root/'port/level-world/reports/android-native-owner-tests/world-item-pool-graph-v3/receipt.json').read_text())
sources=[s['path'].replace('\\','/') for s in receipt['sources']][1:]
sources.insert(0,'port/level-world/tests/world_item_live_owner_v5.cpp')
sources+=['port/level-world/world_item_live_owner_v5.cpp','port/level-world/world_item_pf_connection_v4.cpp']
subprocess.run([sys.executable,str(root/'.local-inputs/root_android_linked_owner_test.py'),'world-item-live-v5',*sources,'--',*[remote+'/'+directory for _,directory,_ in paths]],cwd=root,check=True)
