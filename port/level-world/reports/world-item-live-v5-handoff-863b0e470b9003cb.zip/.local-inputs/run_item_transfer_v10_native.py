from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent.parent
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
remote='/data/local/tmp/dh2-item-live-v5/loot'
subprocess.run([adb,'-s','emulator-5554','shell','mkdir','-p',remote],check=True,capture_output=True)
for name in ['loot_table_pyarray.bin','loot_table_pyarraynames.bin','loot_table_pystructnames.bin']:
 subprocess.run([adb,'-s','emulator-5554','push',str(root/'.local-inputs/player-loot-v7/cache'/name),remote+'/'+name],check=True,capture_output=True)
subprocess.run([sys.executable,str(root/'.local-inputs/root_android_linked_owner_test.py'),'loot-inventory-transfer-v10','port/game-data/tests/loot_inventory_transfer_v10.cpp','port/game-data/loot_inventory_transfer_v10.cpp','port/game-data/loot_temporary_inventory_v8.cpp','--',remote],cwd=root,check=True)
