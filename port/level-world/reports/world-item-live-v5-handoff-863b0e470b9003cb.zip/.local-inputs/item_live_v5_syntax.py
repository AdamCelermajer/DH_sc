from pathlib import Path
import json,shlex,subprocess
root=Path(__file__).resolve().parent.parent
db=root/'port/android-native/app/.cxx/Debug/5a1n3w3m/arm64-v8a/compile_commands.json'
entry=next(e for e in json.loads(db.read_text()) if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
args=entry.get('arguments') or [s.strip('"') for s in shlex.split(entry['command'],posix=False)]
flags=[s for s in args[1:] if s.startswith(('--target=','--sysroot=','-I','-isystem'))]
for i,s in enumerate(args):
 if s=='-isystem':flags.append(args[i+1])
sources=['port/level-world/world_item_live_owner_v5.cpp','port/level-world/world_item_frame_v5.cpp','port/level-world/world_item_pickup_inventory_v10.cpp','port/game-data/loot_inventory_transfer_v10.cpp','port/level-world/player_equipment_render_owner_v1.cpp']
sources+=['port/level-world/world_item_loot_creation_v10.cpp','port/level-world/character_kill_loot_connection_v10.cpp','port/level-world/loot_pickup_quest_tail_v10.cpp','port/level-world/gameobject_online_update_v5.cpp']
r=subprocess.run([args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsyntax-only',*sources],cwd=root,capture_output=True,text=True)
print(r.stdout+r.stderr);raise SystemExit(r.returncode)
