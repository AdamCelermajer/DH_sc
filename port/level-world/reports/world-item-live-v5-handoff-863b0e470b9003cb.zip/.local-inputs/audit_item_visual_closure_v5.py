from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
root=Path(__file__).resolve().parent.parent
results=[]
for name in ['world-item-live-v5','world-item-frame-v5']:
 out=root/'port/level-world/reports/android-native-owner-tests'/name
 receipt=json.loads((out/'receipt.json').read_text());binary=out/(name+'.bin')
 with binary.open('rb') as f:
  elf=ELFFile(f);symbols=list(elf.get_section_by_name('.dynsym').iter_symbols());defined=[s.name for s in symbols if 'RetainedGameObjectVisualV1' in s.name and s['st_shndx']!='SHN_UNDEF']
  undefined=[s.name for s in symbols if 'RetainedGameObjectVisualV1' in s.name and s['st_shndx']=='SHN_UNDEF']
 with (out/'linked-libs/libdh2_level_world.so').open('rb') as f:
  elf=ELFFile(f);tags=[(t.entry.d_tag,t.entry.get('d_val')) for t in elf.get_section_by_name('.dynamic').iter_tags() if t.entry.d_tag in ('DT_SYMBOLIC','DT_FLAGS')]
 coherent_inline=all(any(s['path'].replace('\\','/').endswith('/'+p) for s in receipt['sources']) for p in ['retained_gameobject_visual_v1.cpp','retained_gameobject_visual_asset_connection_v2.cpp','world_item_visual_v2.cpp'])
 assert coherent_inline and not undefined and defined and not any(k=='DT_SYMBOLIC' or (k=='DT_FLAGS' and v&2) for k,v in tags),(name,undefined,tags)
 results.append({'fixture':name,'inline_same_owner_tus':True,'defined_current_visual_exports':defined,'undefined_visual_exports':undefined,'old_library_symbolic_tags':tags,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'visual_header_sha256':hashlib.sha256((root/'port/level-world/retained_gameobject_visual_v1.hpp').read_bytes()).hexdigest(),'header_written_before_binary':(root/'port/level-world/retained_gameobject_visual_v1.hpp').stat().st_mtime<=binary.stat().st_mtime})
p=root/'port/level-world/reports/item-visual-inline-closure-v5.json';p.write_text(json.dumps(results,indent=2)+'\n');print(json.dumps([{'fixture':x['fixture'],'defined_exports':len(x['defined_current_visual_exports']),'undefined_exports':len(x['undefined_visual_exports']),'header_before_binary':x['header_written_before_binary']} for x in results]))
