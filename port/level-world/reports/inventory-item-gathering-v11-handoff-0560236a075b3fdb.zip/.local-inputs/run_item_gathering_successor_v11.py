from pathlib import Path
import subprocess,json,sys
r=Path(__file__).resolve().parent.parent
helper=r/'.local-inputs/root_android_linked_owner_test.py'
def run(name,sources,args):
 subprocess.run([sys.executable,str(helper),name,*sources,'--',*args],cwd=r,check=True)
old=json.loads((r/'port/level-world/reports/android-native-owner-tests/world-item-frame-v5/receipt.json').read_text())
sources=[x['path'].replace('\\','/') for x in old['sources']]
sources[0]='port/level-world/tests/world_item_update_interact_v11.cpp'
sources+=['port/level-world/character_loot_interact_v8.cpp']
run('world-item-update-interact-v11',sources,['/data/local/tmp/dh2-item-live-v5/loot','/data/local/tmp/dh2-item-live-v5/audiovisual','/data/local/tmp/dh2-item-live-v5/visual','/data/local/tmp/dh2-item-live-v5/crypt/crypt.bdae','/data/local/tmp/dh2-item-live-v5/crypt/crypt.dwld'])
run('inventory-gathering-same-owner-v11',['port/game-data/tests/inventory_gathering_same_owner_v11.cpp','port/game-data/fresh_inventory_owned_v4.cpp','port/game-data/inventory_gathering_ids_v11.cpp','port/game-data/loot_inventory_transfer_v10.cpp','port/game-data/loot_temporary_inventory_v8.cpp','port/level-world/loot_pickup_quest_tail_v10.cpp'],['/data/local/tmp/dh2-item-live-v5/loot'])
