from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).resolve().parent.parent
db=r/'port/android-native/app/.cxx/Debug/5a1n3w3m/arm64-v8a/compile_commands.json'
entry=next(e for e in json.loads(db.read_text()) if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
args=entry.get('arguments') or [s.strip('"') for s in shlex.split(entry['command'],posix=False)]
flags=[s for s in args[1:] if s.startswith(('--target=','--sysroot=','-I','-isystem'))]
for i,s in enumerate(args):
 if s=='-isystem':flags.append(args[i+1])
sources=['port/game-data/inventory_gathering_ids_v11.cpp','port/game-data/game_object_dictionary_v11.cpp','port/game-data/fresh_inventory_owned_v4.cpp','port/level-world/player_equipment_render_owner_v1.cpp','port/level-world/world_item_object_owner_v1.cpp','port/level-world/objective_gathering_registration_v11.cpp','port/level-world/openable_container_data_connection_v11.cpp']
p=subprocess.run([args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsyntax-only',*sources],cwd=r,capture_output=True,text=True)
report={'status':'PASS' if p.returncode==0 else 'FAIL','scope':'strict ARM64 syntax, all changed source owners','sources':sources,'stdout':p.stdout,'stderr':p.stderr}
(r/'port/level-world/reports/inventory-gathering-v11-arm64-syntax.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2));raise SystemExit(p.returncode)
