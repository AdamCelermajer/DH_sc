from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent.parent
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
def command(args):subprocess.run(args,check=True,capture_output=True)
fixture='/data/local/tmp/dh2-inventory-gathering-v11-fixtures.bin'
command([adb,'-s','emulator-5554','push',str(r/'port/level-world/reference/inventory-gathering-v11/fixtures.bin'),fixture])
subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'inventory-gathering-ids-v11','port/game-data/tests/inventory_gathering_ids_v11.cpp','port/game-data/inventory_gathering_ids_v11.cpp','--',fixture],cwd=r,check=True)
cache=r/'port/level-loader/vendor/connected-owners-1b96f4edb021619d/reference/openable-container-v1/cache';remote='/data/local/tmp/dh2-openable-data-v11';command([adb,'-s','emulator-5554','shell','mkdir','-p',remote])
for name in ['game_objects_dictionary_pyarray.bin','game_objects_dictionary_pyarraynames.bin']:command([adb,'-s','emulator-5554','push',str(cache/name),remote+'/'+name])
subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'openable-container-data-v11','port/level-world/tests/openable_container_data_connection_v11.cpp','port/level-world/openable_container_data_connection_v11.cpp','port/game-data/game_object_dictionary_v11.cpp','port/level-world/canonical_gameobject_base_owner_v1.cpp','port/level-world/openable_container_owner_v1.cpp','--',remote],cwd=r,check=True)
