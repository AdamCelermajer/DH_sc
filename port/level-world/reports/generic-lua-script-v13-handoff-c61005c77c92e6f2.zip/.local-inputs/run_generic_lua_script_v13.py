from pathlib import Path
import subprocess,sys,hashlib,json
r=Path(__file__).resolve().parent.parent
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe';remote='/data/local/tmp/dh2-generic-lua-v13'
def adbcall(args):subprocess.run([adb,'-s','emulator-5554',*args],check=True,capture_output=True)
adbcall(['shell','mkdir','-p',remote]);records=[]
for p,name in [(r/'port/level-world/reference/character-game-design/real-cache-inputs.bin','design.bin')]+[(r/'.local-inputs/character-script-assets-v1/bootstrap-cache/data/scripts/level'/n,n) for n in ['combat_formulas.luac','death_scripts.luac']]:
 adbcall(['push',str(p),remote+'/'+name]);records.append({'path':str(p.relative_to(r)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(r/'port/level-world/reference/lua-script-v13/native-cache-inputs.json').write_text(json.dumps(records,indent=2))
subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'generic-lua-script-owner-v13','port/level-world/tests/generic_lua_script_owner_v13.cpp','port/level-world/generic_lua_script_owner_v13.cpp','--',remote+'/design.bin',remote],cwd=r,check=True)
