from pathlib import Path
import json,shlex,subprocess,hashlib
r=Path(__file__).resolve().parent.parent
db=r/'port/android-native/app/.cxx/Debug/5a1n3w3m/arm64-v8a/compile_commands.json'
entry=next(e for e in json.loads(db.read_text()) if e['file'].replace('\\','/').endswith('/model_renderer.cpp'))
args=entry.get('arguments') or [s.strip('"') for s in shlex.split(entry['command'],posix=False)]
flags=[s for s in args[1:] if s.startswith(('--target=','--sysroot=','-I','-isystem'))]
for i,s in enumerate(args):
 if s=='-isystem':flags.append(args[i+1])
sources=['port/level-world/generic_lua_script_owner_v13.cpp','port/level-world/tests/generic_lua_script_owner_v13.cpp']
p=subprocess.run([args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsyntax-only',*sources],cwd=r,capture_output=True,text=True)
report={'status':'PASS' if not p.returncode else 'FAIL','scope':'strict ARM64 syntax generic Lua owner/test only','sources':[{'path':n,'sha256':hashlib.sha256((r/n).read_bytes()).hexdigest()} for n in sources],'stdout':p.stdout,'stderr':p.stderr}
(r/'port/level-world/reports/generic-lua-script-v13-arm64-syntax.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));raise SystemExit(p.returncode)
