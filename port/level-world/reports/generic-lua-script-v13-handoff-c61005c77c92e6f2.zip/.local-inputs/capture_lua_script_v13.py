from pathlib import Path
import sys,json
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
r=Path(__file__).resolve().parent.parent;p=r/'port/level-world/reference/lua-script-v13';p.mkdir(exist_ok=True)
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 elf=ELFFile(f);symbols={};segs=[s for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
 for sec in ['.dynsym','.symtab']:
  for s in elf.get_section_by_name(sec).iter_symbols():
   if 'LuaScript' in s.name or 'LuaManager' in s.name or 'N3sfc6script3lua' in s.name:
    symbols[(s.name,int(s['st_value']))]={'name':s.name,'address':int(s['st_value']),'size':int(s['st_size']),'type':s['st_info']['type']}
 dis=Cs(CS_ARCH_ARM,CS_MODE_ARM);lines=[]
 for s in symbols.values():
  if s['type']!='STT_FUNC' or not s['size']:continue
  addr=s['address']&~1
  for seg in segs:
   if seg['p_vaddr']<=addr<seg['p_vaddr']+seg['p_filesz']:blob=seg.data()[addr-seg['p_vaddr']:addr-seg['p_vaddr']+s['size']];break
  lines.append('\n'+s['name']+' '+hex(addr)+' '+str(s['size']));lines += [f'{i.address:08x}: {i.mnemonic} {i.op_str}' for i in dis.disasm(blob,addr)]
 (p/'symbols.json').write_text(json.dumps(list(symbols.values()),indent=2));(p/'original.asm').write_text('\n'.join(lines));print(json.dumps(list(symbols.values()),indent=2))
