from pathlib import Path
import json,hashlib,zipfile
r=Path(__file__).resolve().parent.parent
names=['port/level-world/generic_lua_script_owner_v13.hpp','port/level-world/generic_lua_script_owner_v13.cpp','port/level-world/tests/generic_lua_script_owner_v13.cpp','port/level-world/tests/generic_lua_script_v13_original.py','port/level-world/tests/generic_lua_load_v13_original.py','port/level-world/reports/generic-lua-script-v13-handoff.md','port/level-world/reports/generic-lua-script-v13-arm64-syntax.json','port/level-world/reports/android-native-owner-tests/generic-lua-script-owner-v13/receipt.json','.local-inputs/capture_lua_script_v13.py','.local-inputs/run_generic_lua_script_v13.py','.local-inputs/generic_lua_script_v13_syntax.py','.local-inputs/freeze_generic_lua_script_v13.py']
files=[r/n for n in names]+list((r/'port/level-world/reference/lua-script-v13').glob('*'))
expect={row.split('\t')[0]:row.split('\t')[2] for row in (r/'.local-inputs/character-script-assets-v1/expected-script-sha.tsv').read_text().splitlines()}
for n in ['combat_formulas.luac','death_scripts.luac']:
 p=r/'.local-inputs/character-script-assets-v1/bootstrap-cache/data/scripts/level'/n
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expect['data/scripts/level/'+n];files.append(p)
entries=[{'path':p.relative_to(r).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in sorted(files)]
body=json.dumps({'version':13,'scope':'actual generic LuaScript owner/global file-buffer cache with original/native proofs; actual Level/global publication and remaining native game backends external','entries':entries},indent=2).encode();tag=hashlib.sha256(body).hexdigest()[:16]
out=r/'port/level-world/reports'/f'generic-lua-script-v13-handoff-{tag}.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('generic-lua-script-v13-manifest.json',body)
 for p in files:z.write(p,p.relative_to(r).as_posix())
with zipfile.ZipFile(out) as z:
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
receipt={'status':'PASS','path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'entries':len(entries),'individual_hashes_verified':True}
(r/'port/level-world/reports/generic-lua-script-v13-freeze.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
