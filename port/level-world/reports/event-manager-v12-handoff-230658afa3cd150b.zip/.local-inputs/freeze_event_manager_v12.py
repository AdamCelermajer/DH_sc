from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent.parent
names=['port/level-world/event_manager_owner_v12.hpp','port/level-world/event_manager_owner_v12.cpp','port/level-world/tests/event_manager_owner_v12.cpp','port/level-world/tests/event_manager_v12_original.py','port/level-world/reports/event-manager-v12-handoff.md','port/level-world/reports/event-manager-v12-arm64-syntax.json','port/level-world/reports/android-native-owner-tests/event-manager-owner-v12/receipt.json','.local-inputs/capture_event_manager_v12.py','.local-inputs/event_payload_census_v12.py','.local-inputs/run_event_manager_v12.py','.local-inputs/event_manager_v12_syntax.py','.local-inputs/freeze_event_manager_v12.py']
files=[r/n for n in names]+list((r/'port/level-world/reference/event-manager-v12').glob('*'))
entries=[{'path':p.relative_to(r).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in sorted(files)]
body=json.dumps({'version':12,'scope':'whole source EventManager owner and isolated original/native checks; Level/quest receivers external, no recovered enqueue producer','entries':entries},indent=2).encode()
tag=hashlib.sha256(body).hexdigest()[:16];out=r/'port/level-world/reports'/f'event-manager-v12-handoff-{tag}.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('event-manager-v12-manifest.json',body)
 for p in files:z.write(p,p.relative_to(r).as_posix())
with zipfile.ZipFile(out) as z:
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
receipt={'status':'PASS','path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'entries':len(entries),'individual_hashes_verified':True}
(r/'port/level-world/reports/event-manager-v12-freeze.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
