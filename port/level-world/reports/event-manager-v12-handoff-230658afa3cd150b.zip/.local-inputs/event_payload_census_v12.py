from pathlib import Path
import sys,json,struct
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
r=Path(__file__).resolve().parent.parent
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 elf=ELFFile(f);symbols={}
 for name in ['.dynsym','.symtab']:
  for s in elf.get_section_by_name(name).iter_symbols():
   if 'QuestEvent' in s.name or ('QE_' in s.name and 'GetType' in s.name) or ('IEvent' in s.name and s['st_info']['type']=='STT_OBJECT'):
    symbols[s.name]={'name':s.name,'address':int(s['st_value']),'size':int(s['st_size'])}
 segs=[s for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
 def read(addr,n):
  for s in segs:
   if s['p_vaddr']<=addr< s['p_vaddr']+s['p_filesz']:return s.data()[addr-s['p_vaddr']:addr-s['p_vaddr']+n]
  return b''
 dis=Cs(CS_ARCH_ARM,CS_MODE_ARM)
 for s in symbols.values():
  if s['name'].startswith('_ZTV'):s['words']=[hex(x) for x in struct.unpack('<'+'I'*(s['size']//4),read(s['address'],s['size']))]
  elif s['size']:s['instructions']=[f'{i.address:08x} {i.mnemonic} {i.op_str}' for i in dis.disasm(read(s['address'],s['size']),s['address'])]
 rows=list(symbols.values());(r/'port/level-world/reference/event-manager-v12/payload-symbols.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
