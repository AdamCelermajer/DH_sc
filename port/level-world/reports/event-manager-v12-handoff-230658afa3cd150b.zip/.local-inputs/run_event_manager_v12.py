from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent.parent
adb=r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe'
remote='/data/local/tmp/dh2-event-manager-v12-fixtures.bin'
subprocess.run([adb,'-s','emulator-5554','push',str(r/'port/level-world/reference/event-manager-v12/fixtures.bin'),remote],check=True,capture_output=True)
subprocess.run([sys.executable,str(r/'.local-inputs/root_android_linked_owner_test.py'),'event-manager-owner-v12','port/level-world/tests/event_manager_owner_v12.cpp','port/level-world/event_manager_owner_v12.cpp','--',remote],cwd=r,check=True)
