from pathlib import Path
import sys,json
sys.path.insert(0,r'C:\Users\adamc\AppData\Local\uv\cache\archive-v0\jc8RoeQ1US_9Gkmi\Lib\site-packages')
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
r=Path(__file__).resolve().parent.parent
p=r/'port/level-world/reference/event-manager-v12';p.mkdir(exist_ok=True)
with (r/'.local-inputs/libDungeonHunter2.so').open('rb') as f:
 elf=ELFFile(f);symbols=[];segments=[s for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
 for sec in elf.iter_sections():
  if sec.name not in ('.dynsym','.symtab'):continue
  for s in sec.iter_symbols():
   if 'EventManager' in s.name or 'IEvent' in s.name: symbols.append({'name':s.name,'address':int(s['st_value']),'size':int(s['st_size']),'type':s['st_info']['type']})
 symbols=list({(s['name'],s['address']):s for s in symbols}.values())
 dis=Cs(CS_ARCH_ARM,CS_MODE_ARM);lines=[]
 for s in symbols:
  if s['type']!='STT_FUNC' or not s['size']:continue
  addr=s['address']&~1
  for seg in segments:
   if seg['p_vaddr']<=addr<seg['p_vaddr']+seg['p_filesz']:
    blob=seg.data()[addr-seg['p_vaddr']:addr-seg['p_vaddr']+s['size']];break
  lines.append('\n'+s['name']+' '+hex(addr)+' '+str(s['size']))
  lines += [f'{i.address:08x}: {i.mnemonic} {i.op_str}' for i in dis.disasm(blob,addr)]
 (p/'symbols.json').write_text(json.dumps(symbols,indent=2));(p/'original.asm').write_text('\n'.join(lines))
 blocks='\n'.join(lines).split('\n\n')
 (p/'base-original.asm').write_text('\n\n'.join(b for b in blocks if b.startswith(('_ZN12EventManager','_ZNK12EventManager'))))
 print(json.dumps(symbols,indent=2))
