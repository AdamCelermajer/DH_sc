#pragma once
#include <canonical_property_map_v1.hpp>
#include <light_set_name_owner_v3.hpp>
#include <memory>
namespace dh2::world {
// A borrowed ACTUAL renderer light node. Main supplies its retained node owner,
// native identity and storage writer. A source miss is node.identity==0.
struct LightNodeBorrowV53 {std::shared_ptr<void> owner;std::uintptr_t identity{},actual_light_identity{};};
struct LightParameterFieldsV53 {
 std::shared_ptr<void> owner;std::uintptr_t actual_light_identity{};
 std::array<float,4>* ambient4{};std::array<float,4>* diffuse14{};std::array<float,4>* specular24{};
 std::array<float,3>* attenuation34{};float* radius40{};
 std::function<bool(std::string&)> validate_current;
};
struct LightPointInitServicesV53 {
 std::shared_ptr<void> owner;
 // Original LoadScene(dae,"",false,false), choose first actual light node.
 std::function<bool(const std::string&,const char*,bool,bool,LightNodeBorrowV53&,std::string&)> first_scene_light;
 std::function<bool(bool,LightNodeBorrowV53&,std::string&)> construct_light_node;
 std::function<bool(const LightNodeBorrowV53&,std::string&)> attach_root;
 std::function<bool(std::uintptr_t,const LightNodeBorrowV53&,std::string&)> add_automatic;
 // Source SyncData's actual CLight storage/driver writer; not GPU completion.
 std::function<bool(const LightNodeBorrowV53&,LightParameterFieldsV53&,std::string&)> borrow_light_parameters;
 std::function<bool(const char*,bool&,std::string&)> debug_switch;
 std::function<bool(const LightNodeBorrowV53&,std::uint16_t,std::string&)> set_type;
 // Must borrow the existing manager Names owner, not allocate a parallel one.
 std::shared_ptr<LightSetNameOwnerV3> names;
 std::function<bool(std::uintptr_t,const LightNodeBorrowV53&,LightSetNameOwnerV3&,std::string&)> refresh_attachment;
};
// Genuine ObjectBase-derived factory34115c / LightPointC1_40bdd8, GO_ID19.
// Never inherits GameObject geometry/Visual/Character fields.
class CanonicalLightPointV53 final {
 std::shared_ptr<void> pin_;std::uintptr_t identity_;
 target_providers::Handle16 handle_;std::uint32_t type_{19};std::int32_t room_{-1};const char* class_name_{};
 std::string template_;std::map<std::uint32_t,std::uint8_t> bytes_;
 std::map<std::uint32_t,std::int32_t> ints_;std::map<std::uint32_t,float> floats_;
 std::map<std::uint32_t,std::string> strings_;std::map<std::uint32_t,std::array<float,3>> vectors_;
 LightPointInitServicesV53 services_;LightNodeBorrowV53 node_;bool attempted_{},complete_{};std::string error_;
 static bool set_name(void*,const char*,std::string&);static bool set_archetype(void*,const char*,std::string&);
 static bool as_character(void*,std::uintptr_t&,std::string&);static bool across(void*,std::uint8_t&,std::string&);
 static bool read_bool(void*,std::uint32_t,std::uint8_t&,std::string&);
 static bool write_bool(void*,std::uint32_t,std::uint8_t,std::string&);static bool write_int(void*,std::uint32_t,std::int32_t,std::string&);
 static bool write_float(void*,std::uint32_t,float,std::string&);static bool write_string(void*,std::uint32_t,const std::string&,std::string&);
 static bool write_vector(void*,std::uint32_t,const std::array<float,3>&,std::string&);
 bool fail(const std::string&,std::string&);
 bool write_light_parameters(const LightParameterFieldsV53&,std::string&);
public:
 CanonicalLightPointV53(std::shared_ptr<void>,LightPointInitServicesV53);
 CanonicalObjectBorrowV1 canonical(std::shared_ptr<void>);
 CanonicalPropertyActorV1 properties()noexcept;
 bool init_post(std::string&);
 bool sync_data(const LightParameterFieldsV53&,std::string&);
 const std::string* string(std::uint32_t)const noexcept;
 const std::array<float,3>* vector(std::uint32_t)const noexcept;
 const float* floating(std::uint32_t)const noexcept;
 const std::uint8_t* byte(std::uint32_t)const noexcept;
 std::uintptr_t identity()const noexcept{return identity_;}
 const LightNodeBorrowV53& actual_node()const noexcept{return node_;}
 bool init_complete()const noexcept{return complete_;}
 static constexpr bool is_game_object()noexcept{return false;}
};
}
