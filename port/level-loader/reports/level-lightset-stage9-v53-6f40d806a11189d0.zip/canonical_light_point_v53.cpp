#include "canonical_light_point_v53.hpp"
#include <algorithm>
namespace dh2::world {
namespace {
template<class T>T* at(std::map<std::uint32_t,T>& m,std::uint32_t o){auto i=m.find(o);return i==m.end()?nullptr:&i->second;}
template<class T>const T* at(const std::map<std::uint32_t,T>& m,std::uint32_t o){auto i=m.find(o);return i==m.end()?nullptr:&i->second;}
bool needs(const char* n,std::string& e){e="Required actual LightPoint ";e+=n;return false;}
}
CanonicalLightPointV53::CanonicalLightPointV53(std::shared_ptr<void> p,LightPointInitServicesV53 s):pin_(std::move(p)),identity_(reinterpret_cast<std::uintptr_t>(this)),handle_{0,UINT32_MAX,identity_},services_(std::move(s)){
 for(auto o:{0x28u,0x29u,0x60u,0x81u,0x84u,0x86u,0x88u,0x89u,0xf0u,0xf1u,0xf8u,0x10cu,0x118u,0x119u})bytes_[o]=0;
 bytes_[0x85]=1;bytes_[0x8a]=1;
 // Modern deterministic room-local safety, as other ObjectBase receivers:
 // original C1 leaves87 indeterminate; not constructor byte parity for87.
 bytes_[0x87]=0;
 for(auto o:{0xecu,0x108u,0x110u})ints_[o]=-1;
 for(auto o:{0x30u,0x48u,0x68u,0x90u,0xb4u,0xd4u,0x168u,0x180u})strings_[o]={};
 for(auto o:{0x124u,0x134u,0x140u,0x14cu,0x158u,0x1a4u})vectors_[o]={0,0,0};
 // radius130 and automatic164 were NOT initialized by C1. Descriptor defaults
 // produce them; missing property initialization is an explicit failure.
}
bool CanonicalLightPointV53::set_name(void* p,const char* v,std::string& e){if(!v)return needs("name CString",e);static_cast<CanonicalLightPointV53*>(p)->strings_[0x30]=v;e.clear();return true;}
bool CanonicalLightPointV53::set_archetype(void* p,const char* v,std::string& e){if(!v)return needs("archetype CString",e);static_cast<CanonicalLightPointV53*>(p)->strings_[0x48]=v;e.clear();return true;}
bool CanonicalLightPointV53::as_character(void*,std::uintptr_t& o,std::string& e){o=0;e.clear();return true;}
bool CanonicalLightPointV53::across(void* p,std::uint8_t& o,std::string& e){return read_bool(p,0x87,o,e);}
bool CanonicalLightPointV53::read_bool(void* p,std::uint32_t o,std::uint8_t& v,std::string& e){auto* x=at(static_cast<CanonicalLightPointV53*>(p)->bytes_,o);if(!x)return needs("produced byte",e);v=*x;e.clear();return true;}
bool CanonicalLightPointV53::write_bool(void* p,std::uint32_t o,std::uint8_t v,std::string& e){auto& m=static_cast<CanonicalLightPointV53*>(p)->bytes_;if(o!=0x164&&!at(m,o))return needs("declared byte offset",e);m[o]=v;e.clear();return true;}
bool CanonicalLightPointV53::write_int(void* p,std::uint32_t o,std::int32_t v,std::string& e){auto* x=at(static_cast<CanonicalLightPointV53*>(p)->ints_,o);if(!x)return needs("declared int offset",e);*x=v;e.clear();return true;}
bool CanonicalLightPointV53::write_float(void* p,std::uint32_t o,float v,std::string& e){if(o!=0x130)return needs("radius source offset",e);static_cast<CanonicalLightPointV53*>(p)->floats_[o]=v;e.clear();return true;}
bool CanonicalLightPointV53::write_string(void* p,std::uint32_t o,const std::string& v,std::string& e){auto* x=at(static_cast<CanonicalLightPointV53*>(p)->strings_,o);if(!x)return needs("constructed CString offset",e);*x=v;e.clear();return true;}
bool CanonicalLightPointV53::write_vector(void* p,std::uint32_t o,const std::array<float,3>& v,std::string& e){auto* x=at(static_cast<CanonicalLightPointV53*>(p)->vectors_,o);if(!x)return needs("declared Point3D offset",e);*x=v;e.clear();return true;}
CanonicalObjectBorrowV1 CanonicalLightPointV53::canonical(std::shared_ptr<void> p){return {identity_,std::move(p),&handle_,&type_,nullptr,&room_,this,set_name,set_archetype,as_character,&class_name_,across};}
CanonicalPropertyActorV1 CanonicalLightPointV53::properties()noexcept{return {class_name_,&template_,{this,read_bool,write_bool,write_int,write_float,write_string,write_vector}};}
const std::string* CanonicalLightPointV53::string(std::uint32_t o)const noexcept{return at(strings_,o);}
const std::array<float,3>* CanonicalLightPointV53::vector(std::uint32_t o)const noexcept{return at(vectors_,o);}
const float* CanonicalLightPointV53::floating(std::uint32_t o)const noexcept{return at(floats_,o);}
const std::uint8_t* CanonicalLightPointV53::byte(std::uint32_t o)const noexcept{return at(bytes_,o);}
bool CanonicalLightPointV53::fail(const std::string& n,std::string& e){if(error_.empty())error_=n.empty()?"Actual LightPoint service failed":n;e=error_;return false;}
bool CanonicalLightPointV53::init_post(std::string& e){
 if(complete_){e.clear();return true;}if(attempted_)return fail("LightPoint source prefix already attempted; release candidate",e);
 if(!at(floats_,0x130)||!at(bytes_,0x164))return fail("Required actual LightPoint descriptor defaults/overrides",e);
 attempted_=true;bytes_[0x1b0]=0;bytes_[0x1b1]=0;
 for(auto o:{0x140u,0x14cu,0x158u})for(auto& v:vectors_.at(o))v=v/255.f;
 vectors_.at(0x134)[1]=vectors_.at(0x134)[1]/1000.f;vectors_.at(0x134)[2]=vectors_.at(0x134)[2]/1000000.f;
 if(!services_.owner)return fail("Required actual LightPoint renderer owner",e);
 if(!strings_.at(0x168).empty()){
  if(!services_.first_scene_light)return fail("Required actual LightPoint SceneManager.LoadScene",e);
  if(!services_.first_scene_light(strings_.at(0x168),"",false,false,node_,e))return fail(e,e);
 }
 if(!node_.identity){
  if(!services_.construct_light_node)return fail("Required actual LightPoint CLightSceneNode(true)",e);
  if(!services_.construct_light_node(true,node_,e))return fail(e,e);
 }
 if(!node_.identity||!node_.owner||!node_.actual_light_identity)return fail("Required actual retained LightPoint light node",e);
 if(!services_.attach_root)return fail("Required actual LightPoint scene-root attachment",e);
 if(!services_.attach_root(node_,e))return fail(e,e);
 if(bytes_.at(0x164)){
  if(!services_.add_automatic)return fail("Required actual SceneManager automatic-light registry",e);
  if(!services_.add_automatic(identity_,node_,e))return fail(e,e);
 }
 bool write_parameters=true;
 if(!strings_.at(0x168).empty()){
  if(!services_.debug_switch)return fail("Required actual LightPoint TestMultiPlayerLight switch",e);
  if(!services_.debug_switch("TestMultiPlayerLight",write_parameters,e))return fail(e,e);
 }
 if(write_parameters){
  if(!services_.borrow_light_parameters)return fail("Required actual LightPoint CLight parameter storage",e);
  LightParameterFieldsV53 parameters;if(!services_.borrow_light_parameters(node_,parameters,e))return fail(e,e);
  if(parameters.actual_light_identity!=node_.actual_light_identity)return fail("Foreign CLight parameter owner",e);
  if(!write_light_parameters(parameters,e))return fail(e,e);
 }
 if(!services_.set_type)return fail("Required actual LightPoint CLight type58 writer",e);
 if(!services_.set_type(node_,0,e))return fail(e,e);
 if(!services_.names||!services_.refresh_attachment)return fail("Required actual LightPoint RefreshAttachment/shared light-set Names",e);
 if(!services_.refresh_attachment(identity_,node_,*services_.names,e))return fail(e,e);
 complete_=true;e.clear();return true;
}
bool CanonicalLightPointV53::sync_data(const LightParameterFieldsV53& f,std::string& e){
 if(!strings_.at(0x168).empty()){
  if(!services_.owner||!services_.debug_switch)return needs("DebugSwitch TestMultiPlayerLight",e);
  bool override=false;if(!services_.debug_switch("TestMultiPlayerLight",override,e))return false;
  if(!override){e.clear();return true;} // exact source skip, not driver success
 }
 return write_light_parameters(f,e);
}
bool CanonicalLightPointV53::write_light_parameters(const LightParameterFieldsV53& f,std::string& e){
 if(!f.owner||!f.actual_light_identity||!f.ambient4||!f.diffuse14||!f.specular24||!f.attenuation34||!f.radius40||!f.validate_current)return needs("SAME current retained CLight parameter fields",e);
 if(!f.validate_current(e))return false;
 auto* radius=at(floats_,0x130);if(!radius)return needs("produced radius",e);
 if(*radius>0.01f)*f.radius40=*radius; // strict comparison, source preserves near-zero radius
 *f.attenuation34=vectors_.at(0x134);
 for(auto pair:{std::pair<std::array<float,4>*,std::uint32_t>{f.ambient4,0x140},{f.diffuse14,0x14c},{f.specular24,0x158}}){
  const auto& v=vectors_.at(pair.second);*pair.first={v[0],v[1],v[2],1.f};
 }
 if(!f.validate_current(e))return false;e.clear();return true;
}

}
