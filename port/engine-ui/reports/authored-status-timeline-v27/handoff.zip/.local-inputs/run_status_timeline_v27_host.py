from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parents[1];unix='/mnt/c/Users/adamc/Desktop/workspace/DH_sc'
out=root/'port/engine-ui/reports/authored-status-timeline-v27';out.mkdir(parents=True,exist_ok=True)
libs=['.local-inputs/status-host-build/ui','/home/adampalace/dh2-world-build','/home/adampalace/dh2-world-build/game-data','/home/adampalace/dh2-world-build/script-runtime','/home/adampalace/dh2-world-build/engine-skinning','/home/adampalace/dh2-world-build/engine-skinning/engine-animation']
sources=['port/engine-ui/tests/authored_status_timeline_v27.cpp','port/engine-ui/authored_status_timeline_v27.cpp','port/engine-ui/menu_status_messages_v26.cpp','port/engine-ui/menu_status_movie_v26.cpp']
exe='.local-inputs/authored_status_timeline_v27_host'
compile=['g++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-sanitize=vptr','-DTU_CONFIG_LINK_TO_JPEGLIB=0','-DTU_CONFIG_LINK_TO_LIBPNG=0','-DTU_CONFIG_LINK_TO_FREETYPE=0','-DTU_CONFIG_LINK_TO_THREAD=0','-Iport/engine-ui/overlays/edit-text-v1','-Iport/engine-ui','-isystem','port/engine-ui/vendor/gameswf1714',*sources,*['-L'+p for p in libs],'-Wl,--start-group','-ldh2_engine_ui','-ldh2_level_world','-ldh2_game_data','-ldh2_script_runtime','-Wl,--end-group','-lz','-o',exe]
run=['env','LD_LIBRARY_PATH='+':'.join(libs),'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1',exe,'.local-inputs/ui-layout-discovery','port/android-native/app/src/main/assets/original-cache/data','port/android-native/app/src/main/assets/original-cache/data','port/android-native/app/src/main/assets/data/fonts_pycst.bin']
receipts=[]
for command in [compile,run]:
 p=subprocess.run(['wsl.exe','--cd',unix,'--exec',*command],capture_output=True,text=True,timeout=90)
 receipts.append({'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 (out/'host-receipt.json').write_text(json.dumps({'status':'PASS' if p.returncode==0 else 'FAIL','receipts':receipts,'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]},indent=2))
 print(p.returncode,p.stdout,p.stderr[-3500:])
 if p.returncode:raise SystemExit(p.returncode)
