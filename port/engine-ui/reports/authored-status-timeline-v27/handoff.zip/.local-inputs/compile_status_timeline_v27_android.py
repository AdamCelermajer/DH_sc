from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path(__file__).resolve().parents[1]
out=root/'port/engine-ui/reports/authored-status-timeline-v27';out.mkdir(parents=True,exist_ok=True)
results=[]
for abi in ['arm64-v8a','x86_64']:
 db=list((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'));assert len(db)==1
 rows=json.loads(db[0].read_text());row=next(r for r in rows if Path(r['file']).name=='model_renderer.cpp')
 args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
 flags=[]
 for i,s in enumerate(args[1:],1):
  if s=='-isystem':flags.extend([s,args[i+1]])
  elif s.startswith(('--target=','--sysroot=','-I','-D')):flags.append(s)
 flags.extend(['-isystem',str(root/'port/engine-ui/vendor/gameswf1714'),'-DTU_CONFIG_LINK_TO_JPEGLIB=0','-DTU_CONFIG_LINK_TO_LIBPNG=0','-DTU_CONFIG_LINK_TO_FREETYPE=0','-DTU_CONFIG_LINK_TO_THREAD=0'])
 for source in ['port/engine-ui/authored_status_timeline_v27.cpp','port/android-native/app/src/main/cpp/original_ui_session.cpp']:
  obj=out/(Path(source).stem+'-'+abi+'.o')
  cmd=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-c',str(root/source),'-o',str(obj)]
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
  (out/(obj.stem+'.log')).write_text(p.stdout+p.stderr)
  results.append({'abi':abi,'source':source,'sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'exit_code':p.returncode,'command':cmd})
  print(abi,source,p.returncode,p.stderr[:1800])
  (out/'android-compile.json').write_text(json.dumps({'status':'PASS' if all(r['exit_code']==0 for r in results) else 'FAIL','scope':'Strict component and integration source compilation; no APK or live gameplay acceptance','results':results},indent=2))
  if p.returncode:raise SystemExit(p.returncode)
