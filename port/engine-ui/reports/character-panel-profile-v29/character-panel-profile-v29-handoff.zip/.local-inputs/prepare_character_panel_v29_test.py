from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'port/engine-ui/tests/character_menu_connected_v2.cpp').read_text()
source='#include "../../level-world/character_player_skills_v6.hpp"\n#define CharacterPlayerSkillsV3 CharacterPlayerSkillsV6\n'+source
source=source.replace('#include "character_menu_connected_as_host_v2.hpp"','#include "character_menu_connected_as_host_v29.hpp"\n#include "../../level-world/character_menu_faery_connection_v8.hpp"\n#include "../../level-loader/native_gslevel_runtime_v27.hpp"')
needle='CharacterMenuQueriesOwnerV1 queries(qg);ConnectedMenuASHostV2 as(queries,retained,assets+"/original-cache/data/menus");'
replacement='''character::PlayerFaeryAssociationV8 association(identity);
  auto source_globals=std::make_shared<loader::NativeGSLevelGlobalsV27>();
  unsigned visual_calls{},level_reads{};
  character::CharacterMenuFaeryServicesV8 faery;
  faery.owner=retained;faery.difficulty=[&](auto& tier,auto&){tier=unit->difficulty;return true;};
  faery.faery_character=[&](auto id,auto& actor,auto&){check(id==association.character);actor=association.faery420;return true;};
  faery.model_name=[&](auto,const char*&,auto& e){++visual_calls;e="declared missing positive faery visual owner";return false;};
  faery.current_level=[&](auto& id,auto& e){++level_reads;loader::CanonicalCurrentLevelBorrowV1 actual;
   if(!loader::borrow_current_canonical_level_v1(source_globals->borrow(source_globals),actual,e))return false;
   id=actual.identity();return true;
  };
  check(character::bind_character_menu_faery_v8(action_owner,qg,*unit->player,std::move(faery),error),error);
  CharacterMenuQueriesOwnerV1 queries(qg);ConnectedMenuASHostV2 as(queries,retained,assets+"/original-cache/data/menus");
  for(unsigned chosen=0;chosen<5;++chosen){
   auto choose=as.call({CharacterMenuValueV1::numeric(chosen),CharacterMenuValueV1::numeric(0)});
   check(as.dispatch("NativeHUDSetActiveFaery",choose,error),error);
   check(unit->saved->current_faery(unit->difficulty)==int(chosen)&&association.faery420==0&&visual_calls==0&&source_globals->s_level==nullptr,"same Save/update/null source association and GS branch");
  }
  check(level_reads==5,"source current-Level query count with genuine NULL");
  association.faery420=identity+0x700; // Explicit positive visual failure fixture.
  auto failed_choose=as.call({CharacterMenuValueV1::numeric(0),CharacterMenuValueV1::numeric(0)});
  check(!as.dispatch("NativeHUDSetActiveFaery",failed_choose,error)&&error.find("missing positive faery visual")!=std::string::npos,"required positive faery receiver failure");
  check(unit->saved->current_faery(unit->difficulty)==0&&visual_calls==1&&level_reads==5,"source store/update prefix retained before failed visual and outer Level tail");
  association.faery420=0;error.clear();'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
source=source.replace('startup_GPU_and_offline_world_boundary_fixtures','startup_GPU_offline_world_and_positive_faery_visual_boundary_fixtures')
source+='\n#undef CharacterPlayerSkillsV3\n'
(root/'port/engine-ui/tests/character_panel_profile_v29.cpp').write_text(source)
header=(root/'port/engine-ui/tests/character_menu_connected_as_host_v2.hpp').read_text().replace('"NativeHUDGetIsFaeryUnlocked"','"NativeHUDGetIsFaeryUnlocked","NativeHUDSetActiveFaery"')
(root/'port/engine-ui/tests/character_menu_connected_as_host_v29.hpp').write_text(header)
