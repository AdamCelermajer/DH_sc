from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(__file__).resolve().parents[1];unix='/mnt/c/Users/adamc/Desktop/workspace/DH_sc'
out=root/'port/engine-ui/reports/character-panel-profile-v29';out.mkdir(parents=True,exist_ok=True)
sources=['port/engine-ui/tests/character_panel_profile_v29.cpp','port/engine-ui/character_menu_stats_owner_v1.cpp','port/engine-ui/character_menu_actions_owner_v1.cpp','port/engine-ui/character_menu_queries_owner_v1.cpp','port/engine-ui/character_menu_font_palette_v1.cpp','port/engine-ui/character_menu_inventory_order_v1.cpp','port/engine-ui/character_menu_inventory_mutation_v1.cpp','port/engine-ui/character_menu_as_bridge_v1.cpp','port/engine-ui/character_menu_item_actions_v1.cpp','port/engine-ui/character_menu_save_actions_v1.cpp','port/engine-ui/character_menu_faery_actions_v1.cpp','port/level-world/character_menu_faery_connection_v8.cpp','port/level-world/character_player_skills_v6.cpp','port/level-world/character_skill_save_reload_v6.cpp','port/level-loader/canonical_level_context_v1.cpp']
sources += ['port/level-world/character_skills_owner_v6.cpp']
sources += ['port/level-world/character_script_session_v3.cpp']
sources += ['port/level-world/player_equipment_render_owner_v1.cpp']
snapshot='.local-inputs/character-menu-native-v1-host/snapshot'
libs=['.local-inputs/gslevel-v27-script-host','.local-inputs/status-host-build/ui','.local-inputs/profile-v29-skin-host','.local-inputs/profile-v29-skin-host/engine-animation','.local-inputs/profile-v29-skin-host/engine-animation/scene-materials',snapshot]
zip_input='/mnt/c/Users/adamc/Downloads/dungeonhunter2/Dungeon-Hunter-2-HD-v1-0-2-cache.zip'
exe='.local-inputs/character_panel_profile_v29_host'
command=['g++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-fast-math','-ffp-contract=off','-ffunction-sections','-fdata-sections','-isystem','port/engine-ui/vendor/gameswf1714','-DTU_CONFIG_LINK_TO_JPEGLIB=0','-DTU_CONFIG_LINK_TO_LIBPNG=0','-DTU_CONFIG_LINK_TO_FREETYPE=0','-DTU_CONFIG_LINK_TO_THREAD=0','-Iport/level-world','-Iport/game-data','-Iport/script-runtime','-Iport/engine-ui',*sources,*['-L'+p for p in libs],'-Wl,--start-group','-ldh2_level_world','-ldh2_game_data','-ldh2_engine_ui','-ldh2_script_runtime','-ldh2_engine_skinning','-ldh2_engine_animation','-ldh2_scene_materials','-ldh2_zip_asset_pack_v1','-Wl,--end-group','-Wl,--gc-sections','-lz','-o',exe]
run=['env','LD_LIBRARY_PATH='+':'.join(libs),'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1',exe,unix,zip_input]
receipts=[]
setup=[['cmake','-S','port/engine-skinning','-B','.local-inputs/profile-v29-skin-host'],['cmake','--build','.local-inputs/profile-v29-skin-host','--target','dh2_engine_skinning','--parallel','2']]
for args in ([run] if '--run-only' in sys.argv else setup+[command,run]):
 p=subprocess.run(['wsl.exe','--cd',unix,'--exec',*args],capture_output=True,text=True,timeout=180)
 receipts.append({'command':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(p.returncode,p.stdout,p.stderr[-6000:],flush=True)
 (out/'host-receipt.json').write_text(json.dumps({'status':'PASS' if p.returncode==0 else 'FAIL','scope':'Actual three-class profile/Gear/V6/Save/actions through retained AS + source faery graph, source constructor NULL association/current GS cell; positive faery visual failure and startup GPU/offline world/localization endpoints declared fixtures, not live Android acceptance','receipts':receipts,'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]},indent=2)+'\n')
 if p.returncode:raise SystemExit(p.returncode)
