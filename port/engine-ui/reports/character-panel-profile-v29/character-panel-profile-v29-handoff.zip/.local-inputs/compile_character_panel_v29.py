from pathlib import Path
import json,shlex,subprocess
root=Path(__file__).resolve().parents[1]
out=root/'port/engine-ui/reports/character-panel-profile-v29';out.mkdir(parents=True,exist_ok=True)
sources=['port/level-world/character_menu_faery_connection_v8.cpp','port/level-world/level_faery_placement_v8.cpp','port/android-native/app/src/main/cpp/character_panel_session_v1.cpp','port/android-native/app/src/main/cpp/native_app.cpp','port/android-native/app/src/main/cpp/model_renderer.cpp']
results=[]
for abi in ['arm64-v8a','x86_64']:
 database=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'))
 rows=json.loads(database.read_text());fallback=next(r for r in rows if Path(r['file']).name=='model_renderer.cpp')
 for source in sources:
  row=next((r for r in rows if Path(r['file']).name==Path(source).name),fallback)
  args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
  flags=[]
  for i,s in enumerate(args):
   if s in ['-isystem','-I']:flags.extend([s,args[i+1]])
   elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
  obj=out/(Path(source).stem+'-'+abi+'.o')
  command=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-c',str(root/source),'-o',str(obj)]
  p=subprocess.run(command,capture_output=True,text=True,timeout=180)
  (out/(obj.stem+'.log')).write_text(p.stdout+p.stderr)
  results.append({'abi':abi,'source':source,'command':command,'exit_code':p.returncode});print(abi,source,p.returncode,p.stderr[:3000],flush=True)
(out/'compile.json').write_text(json.dumps({'status':'PASS' if all(r['exit_code']==0 for r in results) else 'FAIL','scope':'Strict same-graph character panel/faery source and native integration compilation; not live Android menu acceptance','results':results},indent=2)+'\n')
raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
