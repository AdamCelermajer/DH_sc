from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-v36';out.mkdir(parents=True,exist_ok=True)
db=next((root/'port/android-native/app/.cxx/Debug').glob('*/x86_64/compile_commands.json'))
row=next(r for r in json.loads(db.read_text()) if Path(r['file']).name=='swf_gpu.cpp')
args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
flags=[]
for i,s in enumerate(args):
 if s in ['-isystem','-I']:flags.extend([s,args[i+1]])
 elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
sources=['port/engine-ui/tests/swf_gpu_lazy_v36.cpp','port/android-native/app/src/main/cpp/swf_gpu.cpp','port/android-native/app/src/main/cpp/authored_shader_program.cpp','port/engine-ui/swf_vertex_cache_v36.cpp','port/engine-ui/swf_grid_snap_v1.cpp','port/scene-materials/swf_texture.cpp','port/scene-materials/shader_sources.cpp','port/asset-payloads/sha256.cpp']
binary=out/'swf-gpu-v36.bin'
command=[args[0],*flags,'-I'+str(root/'port/android-native/app/src/main/cpp'),'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-O2','-static-libstdc++',*[str(root/p) for p in sources],'-lEGL','-lGLESv2','-llog','-landroid','-o',str(binary)]
p=subprocess.run(command,capture_output=True,text=True,timeout=120);(out/'compile.log').write_text(p.stdout+p.stderr);print('compile',p.returncode,p.stderr[-5000:],flush=True)
if p.returncode:raise SystemExit(p.returncode)
adb=[r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe','-s','emulator-5554'];remote='/data/local/tmp/dh2-swf-gpu-v36'
def device(*tail):
 q=subprocess.run(adb+list(tail),capture_output=True,text=True,timeout=45)
 if q.returncode:raise RuntimeError(str(tail)+q.stdout+q.stderr)
 return q.stdout
device('shell','mkdir','-p',remote)
pack=root/'port/android-native/app/src/main/assets/shaders/shaders.pak'
device('push',str(binary),remote+'/probe');device('push',str(pack),remote+'/shaders.pak');device('shell','chmod','700',remote+'/probe')
p=subprocess.run(adb+['shell',remote+'/probe',remote+'/shaders.pak'],capture_output=True,text=True,timeout=45)
receipt={'status':'PASS' if p.returncode==0 else 'FAIL','scope':'Isolated EGL pbuffer actual GLES2 pixel fixture, current production SwfGpu/cache + byte/hash verified original shaders, explicit disk asset transport; no app install/start/touch or source timeline modification','stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode,'command':command,'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources],'shader_pack_sha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
(out/'pixel-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'stdout':p.stdout,'stderr':p.stderr}));raise SystemExit(p.returncode)
