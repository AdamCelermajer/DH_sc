from pathlib import Path
import json,hashlib,difflib,zipfile
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-host-v38'
diff=list(difflib.unified_diff((out/'v36/swf_gpu.cpp').read_text().splitlines(),(out/'v37/swf_gpu.cpp').read_text().splitlines(),fromfile='frozen-v36/swf_gpu.cpp',tofile='frozen-v37/swf_gpu.cpp',lineterm=''))
(out/'frozen-source.diff').write_text('\n'.join(diff)+'\n')
sources=['port/android-native/app/src/main/cpp/model_renderer.cpp','port/android-native/app/src/main/cpp/renderer_native_level_c1_v25.inc','port/android-native/app/src/main/cpp/native_app.cpp','port/android-native/app/src/main/cpp/original_ui_session.cpp','port/android-native/app/src/main/cpp/original_cache_assets_v1.cpp','port/asset-payloads/zip_asset_pack_v1.cpp']
evidence=[]
patterns={
'model_renderer.cpp':['std::string load_world','for(unsigned a=0;','for(unsigned b=0;','for(unsigned floor=0;','clear_route_cache','glBufferData','rgba.resize','reset_context()'],
'renderer_native_level_c1_v25.inc':['while(true)','bytes.insert','private_vm_limit','native_gs_launch_v27=false','Required whole original Level'],
'native_app.cpp':['front_launch_report=model_renderer::load_world','original_ui.initialize','front_ui.initialize'],
'original_ui_session.cpp':['AAsset_getLength','required UI input','candidate.resize','render_player','update(sheet'],
'original_cache_assets_v1.cpp':['AAsset_openFileDescriptor64','next->files!=6833','state->pack.read'],
'zip_asset_pack_v1.cpp':['Limit','limit','max_','uncompressed','output.resize']}
for source in sources:
 file=root/source
 if not file.exists():continue
 lines=file.read_text().splitlines();matches=[]
 for i,line in enumerate(lines,1):
  if any(pattern in line for pattern in patterns[file.name]):matches.append({'line':i,'text':line.strip()})
 evidence.append({'path':source,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'matches':matches})
(out/'load-stage-source-evidence.json').write_text(json.dumps({'scope':'read-only source audit; no inferred runtime duration/counts and no production edits','sources':evidence},indent=2)+'\n')
renderer=(root/sources[0]).read_text().splitlines();(out/'world-load-navigation-proof-block.txt').write_text('\n'.join(f'{i+1}: {renderer[i]}' for i in range(2750,min(2853,len(renderer))))+'\n')
for helper in ['prepare_swf_gpu_host_pixels_v38.py','run_swf_gpu_host_pixels_v38.py','swf_gpu_host_pixels_supervisor_v38.py']:
 file=root/'.local-inputs'/helper;compile(file.read_text(),str(file),'exec')
pack=root/'port/android-native/app/src/main/assets/shaders/shaders.pak';digest=hashlib.sha256(pack.read_bytes()).hexdigest()
assert digest=='365a4d3c432454c44208ebb484c7a472a3a4534a0c5c9e77a7a90f3b87b1b5c0'
shader_evidence=[]
with zipfile.ZipFile(pack) as archive:
 for name in ['GameSWFVS.glsl','GameSWFFS.glsl','GameSWFFS_blend.glsl']:
  raw=archive.read(name);shader_evidence.append({'member':name,'sha256':hashlib.sha256(raw).hexdigest(),'source':raw.decode()})
(out/'actual-shader-audit.json').write_text(json.dumps({'pack_path':str(pack),'pack_sha256':digest,'members':shader_evidence,'normal_final_alpha_zero_inference':'Normal fragment multiplies every channel by vColor0; DiffuseColor.a=0 for actual texture formats. Exact final vColor0.a=0 gives fragment alpha0. SRC_ALPHA/ONE_MINUS_SRC_ALPHA RGB and ONE/ONE_MINUS_SRC_ALPHA coverage alpha preserve destination. Only outside masks; non-normal passes retained. Mathematical/source proof, not actual pixels.'},indent=2)+'\n')
print('Frozen GPU diff, exact load-stage source evidence and helper syntax checked; no compilation/GPU/runtime launched')
