"""Linux supervisor for a single explicit host fixture/compiler process group.

No emulator, device, downloads or global process operations. Runtime fixture
adds its own thread-only seccomp and tighter hard AS/CPU/alarm constraints.
"""
from pathlib import Path
import os,sys,json,time,signal,resource,subprocess
job=Path(sys.argv[1]);spec=json.loads(job.read_text());cancel=Path(spec['cancel']);receipt=Path(spec['receipt'])
def hard_limits():
 resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))
def tree(pid):
 result=[];queue=[pid]
 while queue:
  current=queue.pop()
  if current in result:continue
  if len(result)>=32:raise RuntimeError('owned process bound exceeded')
  result.append(current)
  try:queue.extend(map(int,Path(f'/proc/{current}/task/{current}/children').read_text().split()))
  except FileNotFoundError:pass
 return result
start=time.monotonic();peak=0;status='unknown';p=None
try:
 with Path(spec['stdout']).open('wb') as stdout,Path(spec['stderr']).open('wb') as stderr:
  p=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=dict(os.environ,**spec.get('environment',{})),start_new_session=True,preexec_fn=hard_limits,stdout=stdout,stderr=stderr)
  while p.poll() is None:
   rss=0
   for pid in tree(p.pid):
    try:
     for row in Path(f'/proc/{pid}/status').read_text().splitlines():
      if row.startswith('VmRSS:'):rss+=int(row.split()[1])*1024
    except FileNotFoundError:pass
   peak=max(peak,rss)
   if cancel.exists():raise RuntimeError('Windows supervisor cancel/headroom guard')
   if time.monotonic()-start>spec['timeout_seconds']:raise RuntimeError('owned process wall duration bound')
   if rss>spec['aggregate_rss_limit_bytes']:raise RuntimeError('owned process aggregate RSS bound')
   time.sleep(.05)
  status='PASS' if p.returncode==0 else 'FAIL'
except BaseException as e:
 status='GUARD_STOP';error=str(e)
 if p and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
finally:
 receipt.write_text(json.dumps({'status':status,'exit_code':p.returncode if p else None,'peak_owned_rss_bytes':peak,'elapsed_seconds':time.monotonic()-start,'error':locals().get('error'),'hard_inherited_AS_MiB':1536,'hard_inherited_CPU_seconds':60,'own_group_pid':p.pid if p else None,'spec':spec},indent=2)+'\n')
sys.exit(0 if status=='PASS' else 1)
