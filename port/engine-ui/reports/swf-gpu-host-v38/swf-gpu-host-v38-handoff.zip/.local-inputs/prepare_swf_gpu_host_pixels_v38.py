from pathlib import Path
import json,zipfile,hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-host-v38';out.mkdir(parents=True,exist_ok=True)
for version in ['v36','v37']:
 frozen=root/('port/engine-ui/reports/swf-gpu-'+version+'/swf-gpu-'+version+'-handoff.zip')
 with zipfile.ZipFile(frozen) as archive:
  manifest=json.loads(archive.read('handoff-manifest.json'))
  for filename in ['swf_gpu.hpp','swf_gpu.cpp']:
   path='port/android-native/app/src/main/cpp/'+filename;entry=next(r for r in manifest['files'] if r['path']==path);data=archive.read(path)
   assert hashlib.sha256(data).hexdigest()==entry['sha256'];target=out/version/filename;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
sdk=Path(r'C:\Users\adamc\AppData\Local\Android\Sdk');headers=next((sdk/'ndk').glob('*/toolchains/llvm/prebuilt/windows-x86_64/sysroot/usr/include/EGL/egl.h')).parents[1]
shim=out/'headers'
for directory in ['EGL','GLES2','KHR']:shutil.copytree(headers/directory,shim/directory,dirs_exist_ok=True)
(shim/'android').mkdir(exist_ok=True)
(shim/'android/asset_manager.h').write_text('''#pragma once
#include <sys/types.h>
#include <stddef.h>
struct AAssetManager;struct AAsset;
#define AASSET_MODE_BUFFER 3
extern "C" {
AAsset* AAssetManager_open(AAssetManager*,const char*,int);
off64_t AAsset_getLength64(AAsset*);
int AAsset_read(AAsset*,void*,size_t);
void AAsset_close(AAsset*);
}
''')
shutil.copyfile(root/'.local-inputs/swf-gpu-v37-host-headers/android/log.h',shim/'android/log.h')
print('Prepared exact frozen GPU V36/V37 and portable NDK headers; no context/process launched')
