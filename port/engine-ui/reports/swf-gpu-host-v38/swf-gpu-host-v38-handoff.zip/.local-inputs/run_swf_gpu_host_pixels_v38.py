from pathlib import Path
import subprocess,json,hashlib,sys,os,time,argparse
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-host-v38';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'port/android-native/tools'))
from emulator_watchdog_v36 import WindowsAPI
parser=argparse.ArgumentParser();parser.add_argument('--run-bounded',action='store_true');options=parser.parse_args()
def linux(path):
 p=Path(path).as_posix();return '/mnt/'+p[0].lower()+p[2:]
api=WindowsAPI();snapshots=[]
def headroom():
 value=api.system_snapshot();snapshots.append(value)
 if value['commit_limit_bytes']-value['commit_total_bytes']<17*1024**3 or value['physical_available_bytes']<7*1024**3:
  (out/'headroom-refusal.json').write_text(json.dumps({'status':'GUARD_REFUSED_BEFORE_CHILD_START','system':value,'commit_headroom_bytes':value['commit_limit_bytes']-value['commit_total_bytes'],'required_commit_headroom_bytes':17*1024**3,'required_physical_available_bytes':7*1024**3,'no_GL_context_or_emulator_started':True},indent=2)+'\n')
  raise RuntimeError('Host floor refused: require16GiB commit margin+1GiB fixture and6GiB RAM floor+1GiB fixture')
 return value
def execute(label,argv,environment=None,runtime=False):
 headroom();spec={'argv':argv,'cwd':linux(root),'environment':environment or {},'cancel':linux(out/(label+'.cancel')),'receipt':linux(out/(label+'.guard.json')),'stdout':linux(out/(label+'.stdout')),'stderr':linux(out/(label+'.stderr')),'timeout_seconds':25 if runtime else 60,'aggregate_rss_limit_bytes':384*1024**2 if runtime else 768*1024**2}
 cancel=out/(label+'.cancel')
 if cancel.exists():raise RuntimeError('Previous cancel marker exists; inspect prior receipt before rerun: '+str(cancel))
 file=out/(label+'.job.json');file.write_text(json.dumps(spec,indent=2)+'\n')
 command=['wsl.exe','--exec','/usr/bin/python3',linux(root/'.local-inputs/swf_gpu_host_pixels_supervisor_v38.py'),linux(file)]
 p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE);start=time.monotonic()
 try:
  while p.poll() is None:
   headroom()
   if time.monotonic()-start>spec['timeout_seconds']+10:raise RuntimeError('Windows wall backstop')
   time.sleep(.1)
 except BaseException:
  cancel.write_text('stop only owned Linux process group\n');p.wait(timeout=10);raise
 stdout,stderr=p.communicate(timeout=5);record=json.loads((out/(label+'.guard.json')).read_text());record['wsl_stdout']=stdout.decode(errors='replace');record['wsl_stderr']=stderr.decode(errors='replace')
 if record['status']!='PASS':raise RuntimeError(label+': '+str(record)+'\n'+(out/(label+'.stderr')).read_text(errors='replace')[-4000:])
 return record
row=json.loads((root/'port/engine-ui/reports/swf-gpu-v37/compile.json').read_text())['results'][1]
include_flags=['-I'+linux(out/'headers')]
include_flags.extend('-I'+linux(s[2:]) for s in row['command'] if s.startswith('-I') and ':/' in s[2:].replace('\\','/'))
sources=['port/engine-ui/tests/swf_gpu_host_pixels_v38.cpp','port/android-native/app/src/main/cpp/authored_shader_program.cpp','port/engine-ui/swf_vertex_cache_v36.cpp','port/engine-ui/swf_grid_snap_v1.cpp','port/scene-materials/swf_texture.cpp','port/scene-materials/shader_sources.cpp','port/asset-payloads/sha256.cpp']
results=[]
for version in ['v36','v37']:
 binary=out/(version+'.host.bin');command=['g++','-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-O2','-g','-I'+linux(out/version),*include_flags]
 if version=='v37':command.append('-DDH2_SUBMISSION_V37=1')
 command += [*sources,linux(out/version/'swf_gpu.cpp'),'-l:libEGL.so.1','-l:libGL.so.1','-ldl','-pthread','-o',linux(binary)]
 record=execute(version+'-compile',command);results.append({'version':version,'compile_guard':record,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()});print(version,'compile PASS',flush=True)
receipt={'scope':'Actual Mesa surfaceless GLES via shared libGL dispatch; frozen V36 vs frozen V37; separate disk AAsset transport and glGetError counter only; no emulator/ADB/app/downloads','sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources],'results':results,'status':'COMPILE_PASS_RUNTIME_PENDING','headroom_snapshots':snapshots}
if options.run_bounded:
 environment={'EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1','GALLIUM_DRIVER':'llvmpipe','LP_NUM_THREADS':'1','MESA_SHADER_CACHE_DISABLE':'true','MESA_LOADER_DRIVER_OVERRIDE':'llvmpipe','MESA_GLES_VERSION_OVERRIDE':'2.0'}
 pack=root/'port/android-native/app/src/main/assets/shaders/shaders.pak';receipt['shader_pack_sha256']=hashlib.sha256(pack.read_bytes()).hexdigest()
 for row in results:
  version=row['version'];record=execute(version+'-runtime',[linux(out/(version+'.host.bin')),linux(pack)],environment,True);row['runtime_guard']=record;row['stdout']=(out/(version+'-runtime.stdout')).read_text();row['stderr']=(out/(version+'-runtime.stderr')).read_text();print(version,row['stdout'],flush=True)
 def pixels(row):return {line.split()[1]:line.split()[2] for line in row['stdout'].splitlines() if line.startswith('PIXEL ')}
 before=pixels(results[0]);after=pixels(results[1]);receipt['pixel_cases']=len(before);receipt['pixels_identical']=before==after and len(before)>=30;receipt['status']='PIXEL_PARITY_PASS' if receipt['pixels_identical'] else 'PIXEL_PARITY_FAIL'
 if not receipt['pixels_identical']:receipt['mismatches']={key:[value,after.get(key)] for key,value in before.items() if after.get(key)!=value}
receipt['headroom_snapshots']=snapshots
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['status'])
