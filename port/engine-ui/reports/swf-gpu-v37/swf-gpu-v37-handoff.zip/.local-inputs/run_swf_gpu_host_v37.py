from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-v37'
def linux(path):
 p=Path(path).as_posix();return '/mnt/'+p[0].lower()+p[2:]
sources=['port/engine-ui/tests/swf_gpu_submission_contract_v37.cpp','port/android-native/app/src/main/cpp/swf_gpu.cpp','port/engine-ui/swf_vertex_cache_v36.cpp','port/engine-ui/swf_grid_snap_v1.cpp','port/scene-materials/swf_texture.cpp']
commands=json.loads((out/'compile.json').read_text())['results'][1]['command']
includes=['-I'+linux(root/'.local-inputs/swf-gpu-v37-host-headers'),'-I'+linux(root/'port/android-native/app/src/main/cpp')]
includes.extend('-I'+linux(s[2:]) for s in commands if s.startswith('-I') and ':/' in s[2:].replace('\\','/'))
binary='.local-inputs/swf_gpu_submission_contract_v37_test'
command=['wsl.exe','--cd',linux(root),'g++','-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-O2','-g','-fsanitize=address,undefined',*includes,*sources,'-o',binary]
p=subprocess.run(command,capture_output=True,text=True,timeout=120);(out/'host-compile.log').write_text(p.stdout+p.stderr);print('host compile',p.returncode,p.stderr[-5000:],flush=True)
if p.returncode:raise SystemExit(p.returncode)
p=subprocess.run(['wsl.exe','--cd',linux(root),'./'+binary],capture_output=True,text=True,timeout=30)
receipt={'status':'PASS' if p.returncode==0 else 'FAIL','scope':'Host GL call/state contract with explicit mock GL/shader transport; no actual GLES pixels, source AS/menu or FPS claim','stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode,'sanitizers':['address','undefined'],'command':command,'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources],'binary_sha256':hashlib.sha256((root/binary).read_bytes()).hexdigest()}
(out/'host-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'stdout':p.stdout,'stderr':p.stderr}));raise SystemExit(p.returncode)
