from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-v37';out.mkdir(parents=True,exist_ok=True)
sources=['port/engine-ui/swf_vertex_cache_v36.cpp','port/android-native/app/src/main/cpp/swf_gpu.cpp','port/android-native/app/src/main/cpp/original_ui_session.cpp']
results=[]
for abi in ['arm64-v8a','x86_64']:
 database=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'));rows=json.loads(database.read_text());fallback=next(r for r in rows if Path(r['file']).name=='swf_gpu.cpp')
 for source in sources:
  row=next((r for r in rows if Path(r['file']).name==Path(source).name),fallback);args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
  flags=[]
  for i,s in enumerate(args):
   if s in ['-isystem','-I']:flags.extend([s,args[i+1]])
   elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
  obj=out/(Path(source).stem+'-'+abi+'.o');command=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-c',str(root/source),'-o',str(obj)]
  p=subprocess.run(command,capture_output=True,text=True,timeout=180);(out/(obj.stem+'.log')).write_text(p.stdout+p.stderr);results.append({'source':source,'sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'abi':abi,'exit_code':p.returncode,'command':command});print(abi,source,p.returncode,p.stderr[-2500:],flush=True)
(out/'compile.json').write_text(json.dumps({'status':'PASS' if all(r['exit_code']==0 for r in results) else 'FAIL','results':results},indent=2)+'\n');raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
