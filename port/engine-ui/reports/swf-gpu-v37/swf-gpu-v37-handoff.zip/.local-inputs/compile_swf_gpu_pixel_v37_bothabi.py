from pathlib import Path
import json,shlex,subprocess,hashlib,os
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/swf-gpu-v37';out.mkdir(parents=True,exist_ok=True)
sources=['port/engine-ui/tests/swf_gpu_submission_v37.cpp','port/android-native/app/src/main/cpp/swf_gpu.cpp','port/android-native/app/src/main/cpp/authored_shader_program.cpp','port/engine-ui/swf_vertex_cache_v36.cpp','port/engine-ui/swf_grid_snap_v1.cpp','port/scene-materials/swf_texture.cpp','port/scene-materials/shader_sources.cpp','port/asset-payloads/sha256.cpp']
temporary=out/'compiler-temp';temporary.mkdir(exist_ok=True);environment=os.environ.copy();environment['TMP']=environment['TEMP']=str(temporary)
results=[]
for abi in ['arm64-v8a','x86_64']:
 db=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'))
 row=next(r for r in json.loads(db.read_text()) if Path(r['file']).name=='swf_gpu.cpp')
 args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
 flags=[]
 for i,s in enumerate(args):
  if s in ['-isystem','-I']:flags.extend([s,args[i+1]])
  elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
 binary=out/('swf-gpu-v37-'+abi+'.bin')
 command=[args[0],*flags,'-I'+str(root/'port/android-native/app/src/main/cpp'),'-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-O2','-static-libstdc++',*[str(root/p) for p in sources],'-lEGL','-lGLESv2','-llog','-landroid','-o',str(binary)]
 p=subprocess.run(command,capture_output=True,text=True,timeout=120,env=environment);(out/('pixel-compile-'+abi+'.log')).write_text(p.stdout+p.stderr);print(abi,'compile',p.returncode,p.stderr[-5000:],flush=True)
 results.append({'abi':abi,'exit_code':p.returncode,'command':command,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if not p.returncode else None})
receipt={'status':'COMPILE_PASS_RUNTIME_PENDING' if all(r['exit_code']==0 for r in results) else 'COMPILE_FAIL','scope':'Actual EGL/GLES pixel fixture compiled only for both ABI; no device operations permitted','sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources],'results':results}
(out/'pixel-compile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['status']);raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
