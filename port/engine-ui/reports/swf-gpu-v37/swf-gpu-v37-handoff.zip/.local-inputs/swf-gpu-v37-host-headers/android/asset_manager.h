#pragma once
struct AAssetManager;
