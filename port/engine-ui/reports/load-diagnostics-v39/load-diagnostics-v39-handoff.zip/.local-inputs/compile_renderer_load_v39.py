from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/load-diagnostics-v39';results=[]
source=root/'port/android-native/app/src/main/cpp/model_renderer.cpp'
owned=root/'port/engine-ui/tests/renderer_private_save_read_v39.cpp'
for abi in ['arm64-v8a','x86_64']:
 db=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'));row=next(r for r in json.loads(db.read_text()) if Path(r['file']).name=='model_renderer.cpp');args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)]
 flags=[]
 for i,s in enumerate(args):
  if s in ['-isystem','-I']:flags.extend([s,args[i+1]])
  elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
 for request in [0,1]:
  obj=out/(abi+'-diagnosticsON-request'+str(request)+'.o');before=hashlib.sha256(source.read_bytes()).hexdigest()
  command=[args[0],*flags,'-std=c++17','-O2','-Werror','-fPIC','-UDH2_ENABLE_LOAD_DIAGNOSTICS','-DDH2_ENABLE_LOAD_DIAGNOSTICS=1','-UDH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39','-DDH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39='+str(request),'-c',str(source),'-o',str(obj)]
  p=subprocess.run(command,capture_output=True,text=True,timeout=180);(out/(obj.stem+'.log')).write_text(p.stdout+p.stderr);after=hashlib.sha256(source.read_bytes()).hexdigest();results.append({'abi':abi,'diagnostics':1,'explicit_QA_request':request,'exit_code':p.returncode,'source_sha256':before,'source_stable_during_compile':before==after,'command':command});print(abi,'diagnosticsON request',request,p.returncode,p.stderr[-5000:],flush=True)
receipt={'status':'PASS' if all(r['exit_code']==0 and r['source_stable_during_compile'] for r in results) else 'FAIL','scope':'Current actual integrated model_renderer, diagnosticsON explicitQArequest0/1, bothABI; no GPU/runtime execution','results':results,'owned_helper_sha256':hashlib.sha256((root/'port/android-native/app/src/main/cpp/renderer_private_save_read_v39.hpp').read_bytes()).hexdigest(),'owned_include_sha256':hashlib.sha256((root/'port/android-native/app/src/main/cpp/renderer_load_diagnostics_v39.inc').read_bytes()).hexdigest()}
(out/'abi-compile.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if receipt['status']=='PASS' else 1)
