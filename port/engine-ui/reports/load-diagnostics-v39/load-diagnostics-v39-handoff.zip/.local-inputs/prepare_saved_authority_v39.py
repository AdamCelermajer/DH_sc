from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/load-diagnostics-v39';source=root/'port/android-native/app/src/main/cpp/renderer_native_level_c1_v25.inc';text=source.read_bytes().decode()
start=text.index(' bool saved(');end=text.index('\n };',start) if '\n };' in text[start:] else -1
# The saved() is the final struct member; pin its whole function, not the brace
# of its enclosing owner. The exact following struct terminator is authoritative.
boundary=text.index('\n};',start);original=text[start:boundary];assert original.rstrip().endswith('}') and 'bytes.insert' in original
if not original.endswith('\n'):original+='\n'
(out/'original-saved-reader.inc').write_bytes(original.encode())
sources=['port/game-data/player_profile_index_v1.cpp','port/level-world/savegame_stream_v2.cpp','port/level-world/level_savegame_writer_v2.cpp','port/level-world/level_savegame_objects_v2.cpp','port/level-world/level_savegame_cache_v1.cpp']
record={'original_saved_function_sha256':hashlib.sha256(original.encode()).hexdigest(),'source_format_maximum_complete_bytes':4294967295,'format_framing':'u32 section count; each section u32 payload length +4byte tag; INFO int32; OBJS u32 object count, two positive signed32 CStrings, u32 room,u64 payload length, variable virtual object Save','application_transport_policy_bytes':16777216,'policy_is_source_maximum':False,'real_saved_chapter_samples_available':False,'memory_note':'16MiB input cap does not bound all duplicated profile/section/object allocations or prove every future Save virtual fits; aggregate parser/object-stage accounting still required','sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]}
(out/'saved-authority.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
