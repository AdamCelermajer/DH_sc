from pathlib import Path
import subprocess,json,hashlib,resource,os,time
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/load-diagnostics-v39';os.chdir(root)
def bounded(address,cpu):
 def apply():
  resource.setrlimit(resource.RLIMIT_AS,(address,address));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu));resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
 return apply
tests=[('reader',['port/engine-ui/tests/renderer_private_save_read_v39.cpp','port/level-world/level_savegame_cache_v1.cpp','port/game-data/player_profile_index_v1.cpp'],['-Wl,--wrap=fread','-Wl,--wrap=fclose']),('budget',['port/engine-ui/tests/renderer_load_budget_v39.cpp'],[])]
results=[]
for name,sources,extra in tests:
 # Own source/helper must pass without inherited misleading-indentation
 # suppression. The composed legacy cache/profile source retains its existing
 # one-line style; that inherited diagnostic is disabled only for that link.
 own_command=['g++','-std=c++17','-Wall','-Wextra','-Werror','-fsyntax-only','-Iport/android-native/app/src/main/cpp','-Iport/level-world','-I'+str(out),sources[0]]
 own=subprocess.run(own_command,capture_output=True,text=True,timeout=20,preexec_fn=bounded(512*1024**2,10))
 (out/(name+'-owned-strict.log')).write_text(own.stdout+own.stderr)
 if own.returncode:raise RuntimeError(name+' strict own source: '+own.stderr)
 binary=out/(name+'-host.bin');command=['g++','-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-O1','-g','-fsanitize=undefined','-Iport/android-native/app/src/main/cpp','-Iport/level-world','-I'+str(out),*sources,*extra,'-o',str(binary)]
 start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=40,preexec_fn=bounded(512*1024**2,20));(out/(name+'-compile.log')).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(name+' compile: '+p.stderr)
 args=[str(binary)]
 if name=='reader':
  # WSL DrvFS does not support POSIX FIFO creation; use an isolated genuine
  # Linux filesystem directory so nonblocking nonregular refusal is exercised.
  directory=Path('/tmp')/('dh2-private-save-v39-'+str(os.getpid()));directory.mkdir();args.append(str(directory))
 p=subprocess.run(args,capture_output=True,text=True,timeout=10,preexec_fn=bounded(128*1024**2,5));print(name,p.returncode,p.stdout,p.stderr,flush=True)
 result={'name':name,'status':'PASS' if not p.returncode else 'FAIL','stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode,'elapsed_compile_and_test_seconds':time.monotonic()-start,'owned_strict_command':own_command,'owned_strict_no_warning_suppression':True,'compile_command':command,'runtime_command':args,'sanitizers':['undefined'],'hard_compile_AS_MiB':512,'hard_runtime_AS_MiB':128,'hard_runtime_CPU_seconds':5,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]};results.append(result)
 if p.returncode:break
(out/'host-receipt.json').write_text(json.dumps({'status':'PASS' if all(r['status']=='PASS' for r in results) and len(results)==2 else 'FAIL','scope':'Small bounded source/actual-filesystem unit fixtures only; no GPU/emulator/ADB, no profile/game state fabrication','results':results},indent=2)+'\n')
raise SystemExit(0 if len(results)==2 and all(r['status']=='PASS' for r in results) else 1)
