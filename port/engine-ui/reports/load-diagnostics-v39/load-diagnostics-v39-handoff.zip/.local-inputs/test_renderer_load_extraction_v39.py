from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/load-diagnostics-v39';inc=root/'port/android-native/app/src/main/cpp/renderer_load_diagnostics_v39.inc';text=inc.read_text();original=(out/'original-proof-block.inc').read_text()
start=text.index('    if(level.native_floor&&level.native_floor->sewn){');end=text.index('      qa.check_time();clear_qa_cache();',start);body=text[start:end]
assert body.count('qa.step();')==7 and body.count('qa.check_graph(')==1
body=body.replace('\n        qa.step();','').replace('\n      qa.check_graph(floors.records.size(),graph.node_count,graph.edge_count);','')
assert body==original,'Original diagnostic counters/hash/calls changed beyond guards'
assert original.count('for(unsigned a=0;')==5 and original.count('for(unsigned floor=0;floor<floors.records.size();++floor){')==2
guard_start=text.index('    struct QaBudgetStopV39');guard_end=text.index('    // Proof routes',guard_start)
guard=text[guard_start:guard_end].replace('    } qa;','    };')
(out/'budget-extracted-v39.hpp').write_text('#pragma once\n#include <chrono>\n#include <cstdint>\n'+guard)
metadata=json.loads((out/'extraction.json').read_text());assert hashlib.sha256((out/'original-proof-block.inc').read_bytes()).hexdigest()==metadata['original_block_sha256']
record={'status':'PASS','exact_original_body_restored_after_removing_only_guards':True,'pair_sweeps':5,'floor_sweeps':2,'guard_count':7,'preserved_search_expansion_limit':10000,'source_sha256':hashlib.sha256(inc.read_bytes()).hexdigest(),'checks':5,'shared_source_mutations':False}
(out/'extraction-test.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
