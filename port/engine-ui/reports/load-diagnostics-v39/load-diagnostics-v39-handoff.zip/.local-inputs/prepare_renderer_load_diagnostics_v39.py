from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];source=root/'port/android-native/app/src/main/cpp/model_renderer.cpp';text=source.read_bytes().decode();out=root/'port/engine-ui/reports/load-diagnostics-v39';out.mkdir(parents=True,exist_ok=True)
needle='if(level.native_floor&&level.native_floor->sewn){';assert text.count(needle)==1
at=text.index(needle);start=text.rfind('\n',0,at)+1
# Exact brace parsing ignores source string/comment/char content.
opening=text.index('{',at);depth=0;state='normal';escape=False;i=opening
while i<len(text):
 c=text[i];n=text[i+1:i+2]
 if state in ['string','char']:
  if escape:escape=False
  elif c=='\\':escape=True
  elif (state=='string' and c=='"') or (state=='char' and c=="'"):state='normal'
 elif state=='line':
  if c=='\n':state='normal'
 elif state=='block':
  if c=='*' and n=='/':state='normal';i+=1
 elif c=='/' and n=='/':state='line';i+=1
 elif c=='/' and n=='*':state='block';i+=1
 elif c=='"':state='string'
 elif c=="'":state='char'
 elif c=='{':depth+=1
 elif c=='}':
  depth-=1
  if not depth:break
 i+=1
assert depth==0
end=i+1
if text[end:end+2]=='\r\n':end+=2
elif text[end:end+1]=='\n':end+=1
original=text[start:end];assert 'World ready' not in original and 'Native graph route probe' in original
(out/'original-proof-block.inc').write_bytes(original.encode())
body=original.replace('auto& floors=*level.native_floor;const auto& graph=floors.graph;', 'auto& floors=*level.native_floor;const auto& graph=floors.graph;\n      qa.check_graph(floors.records.size(),graph.node_count,graph.edge_count);')
body=body.replace('for(unsigned a=0;a<first.size();++a)for(unsigned b=0;b<last.size();++b){', 'for(unsigned a=0;a<first.size();++a)for(unsigned b=0;b<last.size();++b){\n        qa.step();')
pattern='for(unsigned a=0;a<floors.records.size();++a)for(unsigned b=0;b<floors.records.size();++b){';assert body.count(pattern)==4
body=body.replace(pattern,pattern+'\n        qa.step();')
pattern='for(unsigned floor=0;floor<floors.records.size();++floor){';assert body.count(pattern)==2
body=body.replace(pattern,pattern+'\n        qa.step();')
prefix='''// Explicit opt-in QA only. Root wraps this include in
// #if DH2_ENABLE_LOAD_DIAGNOSTICS; shipping CMake defaults that option OFF.
// A QA build additionally supplies DH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39=true
// (or an explicit boolean request expression). Merely compiling is not a request.
#if defined(DH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39)
if(bool(DH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39)){
    struct QaBudgetStopV39{const char* reason;};
    struct QaBudgetV39{
      std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
      std::uint64_t units{};
      void check_graph(std::uint64_t floors,std::uint64_t nodes,std::uint64_t edges){
        if(floors>64)throw QaBudgetStopV39{"floor cap64"};
        if(nodes>4096)throw QaBudgetStopV39{"node cap4096"};
        if(edges>65536)throw QaBudgetStopV39{"edge cap65536"};
        check_time();
      }
      void check_time(){
        if(std::chrono::steady_clock::now()-start>=std::chrono::milliseconds(1000))
          throw QaBudgetStopV39{"elapsed cap1000ms"};
      }
      void step(){check_time();if(units>=25000)throw QaBudgetStopV39{"iteration cap25000"};++units;}
    } qa;
    // Proof routes alter only the source diagnostic route cache. Clear it
    // even when a budget stops a partial sweep; never leave a partial warm cache.
    const auto clear_qa_cache=[&](){if(level.native_floor&&level.native_floor->sewn)dh2::floors::clear_route_cache(*level.native_floor);};
    if(!level.native_floor||!level.native_floor->sewn){
      __android_log_print(ANDROID_LOG_INFO,"DH2Native","Load diagnostics QA skipped | no sewn floor graph | no proof-complete claim");
    }else try{
'''
suffix='''      qa.check_time();clear_qa_cache();
      __android_log_print(ANDROID_LOG_INFO,"DH2Native","Load diagnostics QA completed | units %llu | max floors64 nodes4096 edges65536 units25000 elapsed1000ms",static_cast<unsigned long long>(qa.units));
    }catch(const QaBudgetStopV39& stop){
      clear_qa_cache();
      __android_log_print(ANDROID_LOG_INFO,"DH2Native","Load diagnostics QA stopped | reason %s | units %llu | no proof-complete claim",stop.reason,static_cast<unsigned long long>(qa.units));
    }catch(...){clear_qa_cache();throw;} // Preserve every actual diagnostic failure.
}
#endif
'''
target=root/'port/android-native/app/src/main/cpp/renderer_load_diagnostics_v39.inc';target.write_bytes((prefix+body+suffix).replace('\r\n','\n').encode())
metadata={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'original_block_sha256':hashlib.sha256(original.encode()).hexdigest(),'original_block_bytes':len(original.encode()),'start_line':text[:start].count('\n')+1,'end_line':text[:end].count('\n'),'pair_sweeps':5,'floor_sweeps':2,'original_block':'port/engine-ui/reports/load-diagnostics-v39/original-proof-block.inc','new_include':str(target),'shared_source_modified':False}
(out/'extraction.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata))
