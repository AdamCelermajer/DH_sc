"""Root transfer tool. Default produces/checks exact surgical patches only.

Only an explicit --apply-* flag writes the shared renderer/connection. Stops
if the frozen proof or saved() block has changed; adjacent edits are preserved.
CMake option/definition ownership remains with root and is never written here.
"""
from pathlib import Path
import argparse,hashlib,json,difflib
root=Path(__file__).resolve().parents[1];out=root/'port/engine-ui/reports/load-diagnostics-v39'
parser=argparse.ArgumentParser();parser.add_argument('--apply-load-diags',action='store_true');parser.add_argument('--apply-save-read',action='store_true');options=parser.parse_args()
model=root/'port/android-native/app/src/main/cpp/model_renderer.cpp';source=model.read_bytes().decode();original=(out/'original-proof-block.inc').read_bytes().decode()
replacement='''#if DH2_ENABLE_LOAD_DIAGNOSTICS
#include "renderer_load_diagnostics_v39.inc"
#endif
'''
metadata=json.loads((out/'extraction.json').read_text());assert hashlib.sha256(original.encode()).hexdigest()==metadata['original_block_sha256']
already_diags=source.count('#include "renderer_load_diagnostics_v39.inc"')==1
if already_diags:
 assert original not in source;candidate=source
else:
 assert source.count(original)==1,'Frozen diagnostic block changed or ambiguous; inspect before transfer'
 candidate=source.replace(original,replacement,1)
saved_file=root/'port/android-native/app/src/main/cpp/renderer_native_level_c1_v25.inc';saved_source=saved_file.read_bytes().decode();saved_meta=json.loads((out/'saved-authority.json').read_text());saved_original=(out/'original-saved-reader.inc').read_bytes().decode()
assert hashlib.sha256(saved_original.encode()).hexdigest()==saved_meta['original_saved_function_sha256']
saved_replacement=''' bool saved(const std::string& name,bool& found,std::vector<std::uint8_t>& bytes,std::string& e){
  return dh2::android_ui::read_private_level_save_v39(directory,name,dh2::android_ui::level_save_transport_budget_v39,found,bytes,e);
 }
'''
already_saved='read_private_level_save_v39' in saved_source
if already_saved:assert saved_original not in saved_source;saved_candidate=saved_source
else:assert saved_source.count(saved_original)==1,'Frozen saved() changed; inspect before transfer';saved_candidate=saved_source.replace(saved_original,saved_replacement,1)
header='#include "renderer_private_save_read_v39.hpp"\n'
model_with_save=candidate if header in candidate else header+candidate
def patch(before,after,path):return '\n'.join(difflib.unified_diff(before.splitlines(),after.splitlines(),fromfile=str(path),tofile=str(path),lineterm=''))+'\n'
(out/'model-renderer-load-v39.patch').write_text(patch(source,candidate,model))
(out/'saved-reader-v39.patch').write_text(patch(saved_source,saved_candidate,saved_file)+patch(source,header+source if header not in source else source,model))
changed=[]
if options.apply_load_diags and not already_diags:model.write_bytes(candidate.encode());changed.append(str(model))
if options.apply_save_read:
 if not already_saved:saved_file.write_bytes(saved_candidate.encode());changed.append(str(saved_file))
 current=model.read_bytes().decode()
 if header not in current:model.write_bytes((header+current).encode());changed.append(str(model))
receipt={'dry_run':not(options.apply_load_diags or options.apply_save_read),'changed':changed,'already_load_diagnostics':already_diags,'already_saved_read':already_saved,'root_CMake_required':'option(DH2_ENABLE_LOAD_DIAGNOSTICS ... OFF); target_compile_definitions(dh2_native PRIVATE DH2_ENABLE_LOAD_DIAGNOSTICS=$<BOOL:${DH2_ENABLE_LOAD_DIAGNOSTICS}>); QA builds explicitly define DH2_LOAD_DIAGNOSTICS_QA_REQUEST_V39=true','load_block_sha256':metadata['original_block_sha256'],'saved_block_sha256':saved_meta['original_saved_function_sha256']}
(out/'transfer-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
