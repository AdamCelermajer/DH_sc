from pathlib import Path
import json,hashlib,subprocess,resource,os
root=Path(__file__).resolve().parents[1];os.chdir(root);out=root/'port/android-native/reports/startup-stage-v41';out.mkdir(parents=True,exist_ok=True)
def limit(memory,cpu):
 def apply():resource.setrlimit(resource.RLIMIT_AS,(memory,memory));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 return apply
sources=['port/engine-ui/tests/startup_stage_telemetry_v41.cpp','port/android-native/app/src/main/cpp/startup_stage_telemetry_v41.cpp'];binary=out/'startup-host.bin';command=['g++','-std=c++17','-Wall','-Wextra','-Werror','-O1','-g','-fsanitize=undefined','-pthread','-Iport/android-native/app/src/main/cpp',*sources,'-o',str(binary)]
p=subprocess.run(command,capture_output=True,text=True,timeout=40,preexec_fn=limit(512*1024**2,20));(out/'host-compile.log').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError(p.stderr)
p=subprocess.run([str(binary)],capture_output=True,text=True,timeout=10,preexec_fn=limit(128*1024**2,5));record={'status':'PASS' if not p.returncode else 'FAIL','exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'sanitizers':['undefined'],'strict_without_warning_suppression':True,'compile_command':command,'bounded_runtime_AS_MiB':128,'bounded_runtime_CPU_seconds':5,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]}
for line in p.stdout.splitlines():
 if line.startswith('JSON '):record['parsed_sample']=json.loads(line[5:])
(out/'host-receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'last_line':p.stdout.splitlines()[-1:] ,'stderr':p.stderr}));raise SystemExit(p.returncode)
