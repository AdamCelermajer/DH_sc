from pathlib import Path
import json,shlex,hashlib,subprocess
root=Path(__file__).resolve().parents[1];out=root/'port/android-native/reports/startup-stage-v41';results=[]
sources=['port/android-native/app/src/main/cpp/startup_stage_telemetry_v41.cpp','port/android-native/app/src/main/cpp/startup_stage_telemetry_jni_v41.cpp']
for abi in ['arm64-v8a','x86_64']:
 db=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'));row=next(r for r in json.loads(db.read_text()) if Path(r['file']).name=='native_app.cpp');args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)];flags=[]
 for i,s in enumerate(args):
  if s in ['-I','-isystem']:flags.extend([s,args[i+1]])
  elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
 for source in sources:
  command=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-O2','-fPIC','-c',str(root/source),'-o',str(out/(Path(source).stem+'-'+abi+'.o'))];p=subprocess.run(command,capture_output=True,text=True,timeout=60);(out/(Path(source).stem+'-'+abi+'.log')).write_text(p.stdout+p.stderr);results.append({'abi':abi,'source':source,'source_sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'exit_code':p.returncode,'command':command});print(abi,source,p.returncode,p.stderr[-2000:],flush=True)
java=root/'port/android-native/app/src/main/java/com/example/dh2/StartupStagesV41.java';compiler=Path(r'C:\Program Files\Android\Android Studio\jbr\bin\javac.exe');classes=out/'java-classes';classes.mkdir(exist_ok=True);p=subprocess.run([str(compiler),'-Xlint:all','-Werror','-d',str(classes),str(java)],capture_output=True,text=True,timeout=30);print('Java',p.returncode,p.stderr,flush=True)
receipt={'status':'PASS' if not p.returncode and all(r['exit_code']==0 for r in results) else 'FAIL','strict_without_warning_suppression':True,'results':results,'java_exit_code':p.returncode,'java_sha256':hashlib.sha256(java.read_bytes()).hexdigest(),'java_stderr':p.stderr};(out/'compile.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if receipt['status']=='PASS' else 1)
