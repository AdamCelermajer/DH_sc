from pathlib import Path
import json,hashlib,re
root=Path(__file__).resolve().parents[1];out=root/'port/android-native/reports/startup-stage-v41';out.mkdir(parents=True,exist_ok=True)
log=root/'port/android-native/reports/physical-v40/game-logcat.txt';lines=log.read_text(errors='replace').splitlines();frames=[]
for number,line in enumerate(lines,1):
 if 'Davey! duration=' not in line:continue
 fields={key:int(value) for key,value in re.findall(r'(\w+)=(\d+)',line)}
 def ms(a,b):return (fields[a]-fields[b])/1e6 if a in fields and b in fields else None
 frames.append({'line':number,'reported_duration_ms':fields.get('duration'),'intended_to_completed_ms':ms('FrameCompleted','IntendedVsync'),'vsync_lateness_ms':ms('Vsync','IntendedVsync'),'traversals_to_draw_ms':ms('DrawStart','PerformTraversalsStart'),'draw_to_syncqueued_ms':ms('SyncQueued','DrawStart'),'issue_to_completed_ms':ms('FrameCompleted','IssueDrawCommandsStart'),'fields':fields})
anchors=['Authored UI shader GPU contract PASS','World ready','Monster scripts ready','Actual demo Level C1 retained','Connected player HUD submitted','Skipped 111 frames','Warning, !readyToDraw()','CPU120','phase frame mean_ms']
source_specs={
'port/android-native/app/src/main/java/com/example/dh2/MainActivity.java':['onCreate','onSurfaceCreated','onSurfaceChanged','loadSelected','ByteArrayOutputStream','NativeBridge.loadWorld','Bitmap.createBitmap','queueEvent','runOnUiThread'],
'port/android-native/app/src/main/cpp/native_app.cpp':['NativeBridge_initialize','original_ui.initialize','front_ui.initialize','validate_pixels','consume_launch_request','front_launch_report=model_renderer::load_world','NativeBridge_loadWorld','GetByteArrayRegion','prepare_player_frame'],
'port/android-native/app/src/main/cpp/original_ui_session.cpp':['bool load(','ui constants','constants_load','localization.load','movie->load','export_bitmap','texture_decode','gpu.image','prepare_player_frame','load-process producer pending'],
'port/android-native/app/src/main/cpp/front_ui_session_v87.cpp':['bool load(','initialize','load_front_screen','make_font_platform','shared_menu_movie->load','movie->load'],
'port/android-native/app/src/main/cpp/model_renderer.cpp':['std::string load_world','rgba.resize','dh2_texture_decode','glTexImage2D','construct_native_level_c1','load_actor_initialization','candidate_groups','World ready'],
'port/android-native/app/src/main/cpp/renderer_native_level_c1_v25.inc':['native_gs_launch_v27=false','Level.Init','prepare_loading','unload_level','destroy_level']}
sources=[]
for path,patterns in source_specs.items():
 file=root/path;sources.append({'path':path,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'anchors':[{'line':i,'text':line.strip()} for i,line in enumerate(file.read_text().splitlines(),1) if any(p in line for p in patterns)]})
record={'scope':'Read-only physical HWUI/source startup audit; brief logcat has no perline timestamps orTIDs, loader stage attribution remains unmeasured; native CPU timing is not displayedFPS','log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'hwui_frames':frames,'log_anchors':[{'line':i,'text':line} for i,line in enumerate(lines,1) if any(a in line for a in anchors)],'sources':sources}
framework=Path(r'C:\Users\adamc\AppData\Local\Android\Sdk\sources\android-37.0\android\opengl\GLSurfaceView.java');framework_lines=framework.read_text().splitlines()
record['framework_corroboration']={'path':str(framework),'sha256':hashlib.sha256(framework.read_bytes()).hexdigest(),'exact_phone_framework':False,'note':'SDK37 source corroborates resize/render-complete wait mechanism; phoneAndroid16/vendor framework may differ','ranges':[{'start':start,'lines':framework_lines[start-1:end]} for start,end in [(541,545),(1545,1580),(1763,1795)]]}
(out/'source-snippets.txt').write_text('\n\n'.join(path+'\n'+'\n'.join(f'{i}: {line}' for i,line in enumerate((root/path).read_text().splitlines(),1) if begin<=i<=end) for path,begin,end in [('port/android-native/app/src/main/java/com/example/dh2/MainActivity.java',360,398),('port/android-native/app/src/main/cpp/native_app.cpp',98,138),('port/android-native/app/src/main/cpp/native_app.cpp',171,205),('port/android-native/app/src/main/cpp/original_ui_session.cpp',365,412)]))
(out/'audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'hwui_frames':frames,'log_line_count':len(lines)},indent=2))
