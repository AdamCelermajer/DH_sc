from pathlib import Path
import json,shlex,hashlib,subprocess
root=Path(__file__).resolve().parents[1];out=root/'port/android-native/reports/present-attribution-v42';results=[]
source=root/'port/android-native/app/src/main/cpp/present_capabilities_v42.cpp'
for abi in ['arm64-v8a','x86_64']:
 db=next((root/'port/android-native/app/.cxx/Debug').glob('*/'+abi+'/compile_commands.json'));row=next(r for r in json.loads(db.read_text()) if Path(r['file']).name=='native_app.cpp');args=row.get('arguments') or [s.strip('"') for s in shlex.split(row['command'],posix=False)];flags=[]
 for i,s in enumerate(args):
  if s in ['-I','-isystem']:flags.extend([s,args[i+1]])
  elif s.startswith(('--target=','--sysroot=','-I','-isystem','-D')):flags.append(s)
 command=[args[0],*flags,'-std=c++17','-Wall','-Wextra','-Werror','-O2','-fPIC','-c',str(source),'-o',str(out/('present-capabilities-'+abi+'.o'))]
 p=subprocess.run(command,capture_output=True,text=True,timeout=30);results.append({'abi':abi,'exit_code':p.returncode,'command':command,'stderr':p.stderr});print(abi,p.returncode,p.stderr[-2000:],flush=True)
java=root/'port/android-native/app/src/main/java/com/example/dh2/FrameBoundaryV42.java';sdk=Path.home()/'AppData/Local/Android/Sdk';jar=sorted((sdk/'platforms').glob('*/android.jar'))[-1];classes=out/'java-classes';classes.mkdir(exist_ok=True)
command=[r'C:\Program Files\Android\Android Studio\jbr\bin\javac.exe','--release','11','-Xlint:all','-Werror','-classpath',str(jar),'-d',str(classes),str(java)]
p=subprocess.run(command,capture_output=True,text=True,timeout=30);print('Java',p.returncode,p.stderr,flush=True)
test=subprocess.run([__import__('sys').executable,'-X','utf8',str(root/'port/android-native/tools/test_present_attribution_v42.py')],capture_output=True,text=True,timeout=15);print(test.stdout+test.stderr,flush=True)
receipt={'status':'PASS' if not p.returncode and not test.returncode and all(r['exit_code']==0 for r in results) else 'FAIL','strict_without_warning_suppression':True,'native':results,'native_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'java_exit_code':p.returncode,'java_sha256':hashlib.sha256(java.read_bytes()).hexdigest(),'java_command':command,'java_stderr':p.stderr,'host_tests_exit_code':test.returncode,'host_tests_output':test.stdout+test.stderr,'no_device_calls':True,'pixel_GPU_or_presentation_runtime_evidence':False}
(out/'compile-test-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if receipt['status']=='PASS' else 1)
