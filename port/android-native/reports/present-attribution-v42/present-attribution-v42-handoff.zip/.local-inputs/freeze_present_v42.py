from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];out=root/'port/android-native/reports/present-attribution-v42'
receipt=json.loads((out/'compile-test-receipt.json').read_text())
assert receipt['status']=='PASS'
files=[root/'port/android-native/app/src/main/java/com/example/dh2/FrameBoundaryV42.java',root/'port/android-native/app/src/main/cpp/present_capabilities_v42.cpp',root/'port/android-native/tools/collect_present_trace_v42.py',root/'port/android-native/tools/analyze_frame_boundary_v42.py',root/'port/android-native/tools/test_present_attribution_v42.py',root/'.local-inputs/compile_present_v42.py',Path(__file__),*[out/name for name in ['capture.textproto','attribution.sql','README.md','ROOT-INTEGRATION.md','STARTUP-EXTRACTION.md','compile-test-receipt.json']]]
assert hashlib.sha256(files[0].read_bytes()).hexdigest()==receipt['java_sha256']
assert hashlib.sha256(files[1].read_bytes()).hexdigest()==receipt['native_sha256']
manifest={'schema':'present-attribution-v42-handoff','source_frozen':True,'strict_compile_and_host_tests':'PASS','actual_runtime_capture':'PENDING','no_device_calls':True,'files':[{'path':str(f.relative_to(root)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in files]}
mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files.append(mp)
archive=out/'present-attribution-v42-handoff.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(f,str(f.relative_to(root)).replace('\\','/'))
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'SHA256.txt').write_text(digest+'  '+archive.name+'\n');print(json.dumps({'archive':str(archive),'sha256':digest,'payload_files':len(files),'runtime':'PENDING'}))
