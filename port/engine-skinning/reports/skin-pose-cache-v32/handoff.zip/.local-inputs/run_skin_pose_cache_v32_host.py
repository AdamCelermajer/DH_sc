from pathlib import Path
import subprocess,json,hashlib,argparse
root=Path(__file__).resolve().parents[1];unix='/mnt/c/Users/adamc/Desktop/workspace/DH_sc'
sources=['port/engine-skinning/tests/skin_pose_cache_v32.cpp','port/engine-skinning/skin_pose_cache_v32.cpp','port/engine-skinning/visual_skin_owner_v6.cpp','port/engine-skinning/visual_skin_selection_v6.cpp','port/engine-skinning/skinning.cpp','port/engine-animation/animation.cpp','port/engine-animation/event_track.cpp','port/engine-animation/events.cpp','port/scene-materials/scene.cpp','port/engine-math/math.cpp','port/engine-resources/resources.cpp','port/asset-payloads/payloads.cpp','port/level-world/objects.cpp']
out=root/'port/engine-skinning/reports/skin-pose-cache-v32';out.mkdir(parents=True,exist_ok=True)
libs=['/home/adampalace/dh2-world-build','/home/adampalace/dh2-world-build/game-data','/home/adampalace/dh2-world-build/engine-ui','/home/adampalace/dh2-world-build/script-runtime','/home/adampalace/dh2-world-build/engine-skinning','/home/adampalace/dh2-world-build/engine-skinning/engine-animation','/home/adampalace/dh2-world-build/engine-skinning/engine-animation/scene-materials']
parser=argparse.ArgumentParser();parser.add_argument('--release',action='store_true');parser.add_argument('--opt',choices=['O1','O2']);options=parser.parse_args()
receipts=[]
for opt in (['-'+options.opt] if options.opt else ['-O2'] if options.release else ['-O1','-O2']):
 exe='.local-inputs/skin_pose_cache_v32_'+opt[1:]
 if options.release:exe+='_release'
 args=['g++','-std=c++17','-Wall','-Wextra','-Werror','-Wno-misleading-indentation',opt,'-g','-Iport/game-data','-Iport/engine-animation','-Iport/engine-skinning','-Iport/scene-materials','-fno-fast-math','-ffp-contract=off',*([] if options.release else ['-fsanitize=address,undefined','-fno-omit-frame-pointer']),'-ffunction-sections','-fdata-sections',*sources,'-Wl,--gc-sections','-lz','-o',exe]
 run=['env','LD_LIBRARY_PATH='+':'.join(libs),'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS=halt_on_error=1',exe,'port/android-native/app/src/main/assets/models/prince_modular.bdae','port/android-native/app/src/main/assets/animations/prince_walk_1hand.bdae']
 for command in [args,run]:
  p=subprocess.run(['wsl.exe','--cd',unix,'--exec',*command],capture_output=True,text=True,timeout=180)
  receipts.append({'args':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(p.returncode,p.stdout,p.stderr[:5000])
  (out/('release-receipt.json' if options.release else 'host-receipt.json')).write_text(json.dumps({'status':'PASS' if p.returncode==0 else 'FAIL','sanitizers':not options.release,'scope':'Actual172 module bit parity, cache invalidation/lifetimes, 12 actor CPU benchmark, no device/FPS claim','receipts':receipts,'sources':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sources]},indent=2))
  if p.returncode:raise SystemExit(p.returncode)
