#pragma once
#include "canonical_dummy_owner_v14.hpp"
#include "canonical_spawn_point_v15.hpp"
#include "canonical_decor_v15.hpp"
#include "canonical_destructible_container_v16.hpp"
#include "canonical_trigger_zone_v22.hpp"

namespace dh2::loader {
// Runtime precedes its receiver: the source receiver borrows that same runtime
// for its entire lifetime. The aliasing factory lease retains both and XML.
template<class Receiver> struct CanonicalAuxiliaryRecordV16 {
 actor::RuntimeState runtime;
 std::unique_ptr<Receiver> owner;
 std::shared_ptr<const void> declaration;
};
using CanonicalDummyRecordV16=CanonicalAuxiliaryRecordV16<world::CanonicalDummyOwnerV14>;
using CanonicalSpawnPointRecordV16=CanonicalAuxiliaryRecordV16<world::CanonicalSpawnPointV15>;
using CanonicalDecorRecordV16=CanonicalAuxiliaryRecordV16<world::CanonicalDecorV15>;
using CanonicalDestructibleRecordV16=CanonicalAuxiliaryRecordV16<world::CanonicalDestructibleContainerV16>;
using CanonicalTriggerZoneRecordV22=CanonicalAuxiliaryRecordV16<world::CanonicalTriggerZoneV22>;
template<class Record,class Services> using CanonicalAuxiliaryProviderV16=std::function<bool(
 const world::CanonicalSourceObjectRequestV1&,const std::shared_ptr<Record>&,
 world::GameObjectInitializationServicesV1&,Services&,std::string&)>;
struct CanonicalAuxiliaryInputsV16 {
 std::shared_ptr<void> world;
 CanonicalAuxiliaryProviderV16<CanonicalDummyRecordV16,world::DummyContinuationServicesV14> dummy;
 CanonicalAuxiliaryProviderV16<CanonicalSpawnPointRecordV16,world::SpawnPointServicesV15> spawn_point;
 CanonicalAuxiliaryProviderV16<CanonicalDecorRecordV16,world::DecorServicesV15> decor;
 CanonicalAuxiliaryProviderV16<CanonicalDestructibleRecordV16,world::DestructibleContainerServicesV16> destructible;
 CanonicalAuxiliaryProviderV16<CanonicalTriggerZoneRecordV22,world::TriggerZoneServicesV22> trigger_zone;
};
class CanonicalAuxiliaryFamiliesV16 {
 CanonicalAuxiliaryInputsV16 inputs_;
 std::vector<std::shared_ptr<CanonicalDummyRecordV16>> dummies_;
 std::vector<std::shared_ptr<CanonicalSpawnPointRecordV16>> spawn_points_;
 std::vector<std::shared_ptr<CanonicalDecorRecordV16>> decor_;
 std::vector<std::shared_ptr<CanonicalDestructibleRecordV16>> destructibles_;
 std::vector<std::shared_ptr<CanonicalTriggerZoneRecordV22>> triggers_;
public:
 explicit CanonicalAuxiliaryFamiliesV16(CanonicalAuxiliaryInputsV16);
 // Connect to the existing class dispatch's remaining callback. Unsupported
 // catalog entries fail explicitly; this never filters an authored declaration.
 bool construct(const world::CanonicalFactoryEntryV1&,const world::CanonicalSourceObjectRequestV1&,
                world::CanonicalClassReceiverV1&,std::string&);
 const auto& dummies()const noexcept{return dummies_;}
 const auto& spawn_points()const noexcept{return spawn_points_;}
 const auto& decor()const noexcept{return decor_;}
 const auto& destructibles()const noexcept{return destructibles_;}
 const auto& triggers()const noexcept{return triggers_;}
};
}
