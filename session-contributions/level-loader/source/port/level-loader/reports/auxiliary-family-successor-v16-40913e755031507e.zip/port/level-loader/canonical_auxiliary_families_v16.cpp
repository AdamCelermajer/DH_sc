#include "canonical_auxiliary_families_v16.hpp"
#include <cstring>
#include <utility>

namespace dh2::loader {
namespace {
bool same_lease(const std::shared_ptr<void>& a,const std::shared_ptr<void>& b){
 return a&&b&&!a.owner_before(b)&&!b.owner_before(a);
}
template<class Receiver,class Services>
bool construct_family(const char* name,const std::shared_ptr<void>& world,
 const CanonicalAuxiliaryProviderV16<CanonicalAuxiliaryRecordV16<Receiver>,Services>& provider,
 const world::CanonicalSourceObjectRequestV1& source,
 std::vector<std::shared_ptr<CanonicalAuxiliaryRecordV16<Receiver>>>& retained,
 world::CanonicalClassReceiverV1& output,std::string& error){
 if(!world||!source.source_lease||!provider){error=std::string("Required actual loader family providers: ")+name;return false;}
 auto record=std::make_shared<CanonicalAuxiliaryRecordV16<Receiver>>();record->declaration=source.source_lease;
 world::GameObjectInitializationServicesV1 initialization;initialization.owner=world;
 Services services;services.owner=world;
 if(!provider(source,record,initialization,services,error))return false;
 if(!same_lease(initialization.owner,world)||!same_lease(services.owner,world)){
  error=std::string("Loader family replaced SAME World lease: ")+name;return false;
 }
 if(record->owner){error=std::string("Loader family provider replayed source constructor: ")+name;return false;}
 record->owner=std::make_unique<Receiver>(world,record->runtime,std::move(initialization),std::move(services));
 auto receiver=std::shared_ptr<Receiver>(record,record->owner.get());
 auto candidate=Receiver::factory_receiver(std::move(receiver),source.source_lease);
 retained.push_back(std::move(record));output=std::move(candidate);return true;
}
}
CanonicalAuxiliaryFamiliesV16::CanonicalAuxiliaryFamiliesV16(CanonicalAuxiliaryInputsV16 inputs):inputs_(std::move(inputs)){}
bool CanonicalAuxiliaryFamiliesV16::construct(const world::CanonicalFactoryEntryV1& entry,
 const world::CanonicalSourceObjectRequestV1& source,world::CanonicalClassReceiverV1& output,std::string& error){
 if(!std::strcmp(entry.name,"Dummy")&&entry.original_address==0x3410a4)
  return construct_family<world::CanonicalDummyOwnerV14>(entry.name,inputs_.world,inputs_.dummy,source,dummies_,output,error);
 if(!std::strcmp(entry.name,"SpawnPoint")&&entry.original_address==0x340e10)
  return construct_family<world::CanonicalSpawnPointV15>(entry.name,inputs_.world,inputs_.spawn_point,source,spawn_points_,output,error);
 if(!std::strcmp(entry.name,"Decor")&&entry.original_address==0x3410fc)
  return construct_family<world::CanonicalDecorV15>(entry.name,inputs_.world,inputs_.decor,source,decor_,output,error);
 if(!std::strcmp(entry.name,"DestructibleContainer")&&entry.original_address==0x340d5c)
  return construct_family<world::CanonicalDestructibleContainerV16>(entry.name,inputs_.world,inputs_.destructible,source,destructibles_,output,error);
 error=std::string("Required actual catalog constructor: ")+entry.name;return false;
}
}
