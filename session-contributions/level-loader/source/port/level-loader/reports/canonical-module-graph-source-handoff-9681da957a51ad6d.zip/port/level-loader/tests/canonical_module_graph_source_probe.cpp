#include "canonical_module_graph_v3.hpp"
#include "module_room_zone_spawn_v3.hpp"
#include "canonical_point3d_globals_v1.hpp"
#include "object_enable_condition_v2.hpp"
#include "navigation_producers.hpp"
#include "module_pf_actor_connection_v3.hpp"
#include "light_set_name_owner_v3.hpp"
#include "canonical_receiver_transport_v1.hpp"
#include "canonical_cached_file_v1.hpp"
#include "canonical_module_files_v1.hpp"
#include "canonical_level_context_v1.hpp"
#include "level_config_publication_v2.hpp"
#include <stdexcept>
#include <cassert>
#include <cstring>
#include <fstream>
#include <iterator>
#include <iostream>
using namespace dh2;using namespace dh2::world;using namespace dh2::loader;
static void require(bool ok,const std::string& e){if(!ok)throw std::runtime_error(e);}
static assets::ZipAssetPackV1 pack(const char* path){
 auto f=std::make_shared<std::ifstream>(path,std::ios::binary|std::ios::ate);require(bool(*f),"cache unavailable");
 assets::ZipBackingV1 b;b.owner=f;b.bytes=std::uint64_t(f->tellg());b.read=[f](std::uint64_t at,void* out,std::size_t n,std::string& e){f->clear();f->seekg(std::streamoff(at));f->read(static_cast<char*>(out),std::streamsize(n));if(!*f){e="cache read failure";return false;}return true;};
 assets::ZipAssetPackV1 z;std::string e;require(z.mount(std::move(b),"com.gameloft.android.GAND.GloftD2SS/files/",e),e);return z;
}

// Platform/local-player/network/Handle transports below are explicit fixtures.
// Constructors, defaults, conditions, visual, PF room, Spawn and Zone are real.
struct Fixture {
 std::shared_ptr<void> pin;CanonicalObjectManagerV1 manager;
 Fixture(std::shared_ptr<void> p):pin(p),manager({this,nullptr,nullptr,nullptr,nullptr,network,nullptr}){}
 static bool network(void*,CanonicalObjectBorrowV1&,std::string&){return true;}
 static bool resolve(void* p,target_providers::Handle16& h,bool,const CanonicalObjectBorrowV1*& out,std::string&){out=static_cast<Fixture*>(p)->manager.object(h.key);if(out)h.cached=out->identity;return true;}
 static bool profile(void*,bool& character,bool& profile,std::uint8_t& flag,std::string&){character=true;profile=false;flag=0;return true;}
 static bool condition(void*,const CanonicalObjectBorrowV1& o,bool mark,std::string& e){auto* b=static_cast<CanonicalGameObjectBaseOwnerV1*>(o.context);bool enabled;return object_test_enable_condition_v2({b->byte(0x8a),b->integer(0xec),b->byte(0xf1),b->pointer(0xa8),b->byte(0xac)},{nullptr,profile,nullptr,nullptr,nullptr},mark,enabled,e);}
};
int main(int argc,char** argv){if(argc!=2)return 2;try{
 auto archive=pack(argv[1]);std::string e;bool found=false;auto bytes=std::make_shared<std::vector<std::uint8_t>>();
 require(archive.read("data/3D/Modules/Swamp/swamp.bdae",found,*bytes,e)&&found,e);
 std::shared_ptr<CanonicalLevelContextV1> level;require(CanonicalLevelContextV1::create({"SWAMP","data/scene/001_swamp.mlx"},bytes,level,e),e);
 auto level_fields=level->config_fields();CanonicalLevelModuleBindingsV2* owned_bindings=nullptr;
 // Explicit empty name-vector/provider fixture; authored sound names remain
 // intact and publish -1. Complete Arrays/Sound/GSLevel initialization is open.
 std::vector<std::string> sound_names;unsigned config_queries=0;
 auto roots=std::make_shared<GameObjectSceneRootRegistryV1>();auto floors=std::make_shared<floors::World>();auto map=std::make_shared<SceneManagerMapOwnerV2>(roots);ModulePFDebugV3 debug;debug.owner=bytes;debug.query=[](const char* key,bool& v,std::string&){assert(std::string(key)=="isTracingNavMeshLoadTime");v=false;return true;};auto rooms=std::make_shared<ModulePFRoomsV3>(floors,map,debug);
 CanonicalPropertyMapV1 properties({nullptr,&canonical_vec3_origin_v1(),nullptr});Fixture fixture(bytes);unsigned zone_pf=0;
 CanonicalRoomZoneFactoryV3 zone_factory({bytes,[&](const std::shared_ptr<CanonicalRoomZoneRecordV3>& r,RoomZoneServicesV3& s,std::string&){std::weak_ptr<CanonicalRoomZoneRecordV3> weak=r;s.game_object.owner=bytes;s.game_object.check_spawn_probability=[](std::int32_t& roll,std::string&){roll=-2;return true;};s.game_object.condition_init=[weak](std::uint32_t offset,std::string& e){auto r=weak.lock();return r&&condition_data_init_v3(r->receiver->base(),offset,{},e);};s.game_object.set_position=[weak](const float* p,bool dest,std::string& e){auto r=weak.lock();return r&&game_object_set_position_v2(r->receiver->base(),p,dest,{},e);};s.game_object.device_high_performance=[](bool& high,std::string&){high=true;return true;};s.game_object.load_visual=[weak](std::string& e){auto r=weak.lock();GameObjectVisualAssetOwnerV1 asset(r->receiver->base(),{});return asset.load_visual(e);};s.game_object.update_pf_object=[&,weak](std::string&){auto r=weak.lock();navigation::ProducerRequest q{};q.object=&r->runtime.object;++zone_pf;return dh2_nav_update_game_object(&q)==0;};return true;}});
 CanonicalSpawnServicesV1 spawn;spawn.context=&fixture;spawn.resolve=Fixture::resolve;spawn.test_enable_condition=Fixture::condition;ModuleRoomZoneSpawnV3 zones(fixture.manager,properties,zone_factory,spawn);
 std::uint32_t counter=0;unsigned pf_calls=0;navigation::ObstacleEntry obstacle_entries[128]{};std::uint32_t obstacle_floors[64]{};navigation::ObstacleRegistry obstacles{obstacle_entries,0,128,obstacle_floors,0,64};LightSetNameOwnerV3 lights;assert(lights.get_id("SceneLight")==1&&lights.get_id("absent")==0);CanonicalModuleGraphServicesV3 services;services.candidate=bytes;services.rooms=rooms;services.visual.owner=bytes;services.visual.roots=roots;services.visual.root_update_counter=&counter;services.visual.driver_type=[](std::int32_t& d,std::string&){d=8;return true;};services.visual.modular_meshes=[](std::vector<std::uintptr_t>& meshes,std::string&){meshes.clear();return true;};services.read_asset=[bytes](const std::string& name,std::shared_ptr<const std::vector<std::uint8_t>>& b,bool& found,std::string&){assert(name=="data/3D/Modules/Swamp/swamp.bdae");b=bytes;found=true;return true;};services.update_pf=[&](CanonicalGameObjectBaseOwnerV1& b,std::string& e){assert(b.identity());++pf_calls;ModulePFActorConnectionV3 connection(b,bytes,&floors->collision_world,&obstacles);return connection.update(e);};services.spawn_zone=[&](const std::string& name,target_providers::Handle16& h,std::uint32_t& type,std::string& e){return zones.spawn(name,h,type,e);};services.zone_init=[&](target_providers::Handle16& h,const std::array<float,6>& box,std::uintptr_t module,std::string& e){return zones.init(h,box,module,e);};auto graph=std::make_shared<CanonicalModuleGraphV3>(services);ModuleRuntimeGlobalsV1 globals;std::vector<std::shared_ptr<CanonicalModuleRecordV2>> modules;
CanonicalLevelModuleConstructionV2 construction;construction.candidate=bytes;construction.module_globals=&globals;construction.level_config.owner=bytes;
construction.level_config.debug_switch=[](const char* key,bool& value,std::string&){assert(std::string(key)=="isTracingLevel");value=false;return true;};
construction.level_config.set_level_config=[&](std::uintptr_t id,std::string& e){++config_queries;LevelConfigPublicationBorrowV2 b{level_fields.level_owner,level_fields.config38,level_fields.music11c,level_fields.safezone120,level_fields.ambient124,bytes,&sound_names,[&](std::uintptr_t identity){return owned_bindings->level_config(identity);}};return level_config_publication_v2(b,id,e);};construction.module_services=[&](const CanonicalSourceObjectRequestV1&,const std::shared_ptr<CanonicalModuleRecordV2>& record,GameObjectInitializationServicesV1& init,ModuleInitServicesV1& module,std::string& e){init.owner=bytes;init.check_spawn_probability=[](std::int32_t& roll,std::string&){roll=-2;return true;};init.device_high_performance=[](bool& high,std::string&){high=true;return true;};std::weak_ptr<CanonicalModuleRecordV2> weak=record;init.init_pf_object=[&,weak](bool flag,const float* p,float radius,std::uintptr_t identity,std::string& e){auto r=weak.lock();ModulePFActorConnectionV3 pf(r->receiver->base(),bytes,&floors->collision_world,&obstacles);return pf.init(flag,p,radius,identity,e);};init.light_set_id=[&](const std::string& name,std::int32_t& id,std::string&){id=lights.get_id(name);return true;};return graph->bind(record,init,module,e);};CanonicalLevelModuleBindingsV2 bindings(properties,{},construction);owned_bindings=&bindings;loader::CanonicalReceiverTransportV1 transport(properties,{bytes,&bindings,[](void* p,const CanonicalFactoryEntryV1& f,const CanonicalSourceObjectRequestV1& q,CanonicalClassReceiverV1& r,std::string& e){return static_cast<CanonicalLevelModuleBindingsV2*>(p)->construct_receiver(f,q,r,e);},nullptr});auto dispatch=transport.services();

// No copied level-specific declarations: feed the original complete MLX walk.
CanonicalCachedFileV1 source(archive,fixture.manager,dispatch,{[](bool ok,std::string&){return ok;},[](std::string&){return true;}},{bytes},ObjectEntryRouteV1::level);
LevelFileWalkStepV1 result=LevelFileWalkStepV1::pending;
for(unsigned n=0;n<1000&&result==LevelFileWalkStepV1::pending;++n)result=source.step("data/scene/001_swamp.mlx","Level");
require(result==LevelFileWalkStepV1::complete,source.error());require(source.attempts().size()==10,"original root declaration count changed");
for(const auto& attempt:source.attempts()){
 const auto* kind=attempt->source().entry().source().attribute("gametype");
 if(!kind||(*kind!="Module"&&*kind!="Block"))continue;
 const auto* object=fixture.manager.object(attempt->factory_attempt()->handle().key);
 require(object&&*object->type_f4==5,"actual Module registration missing");
 auto record=std::static_pointer_cast<CanonicalModuleRecordV2>(object->lease);
 require(record->receiver->base().room64()==-1,"diagnostic occurrence replaced source room64");
 require(dispatch.init_post(dispatch.context,*object,e),e);
 require(record->receiver->module_id()==static_cast<std::int32_t>(modules.size())&&!record->receiver->load_floor_pending(),"actual Module counter/pending state mismatch");
 modules.push_back(record);
}
require(config_queries==1&&*level_fields.config38!=0,"actual config early publication missing");
assert(counter==27);assert(modules.size()==9&&rooms->rooms().size()==9&&floors->records.size()==16&&rooms->exits().size()==19);assert(fixture.manager.pending().size()==9&&fixture.manager.source_count50()==19&&globals.next_generated_zone==9&&zone_pf==9);for(unsigned i=0;i<9;++i){auto* object=fixture.manager.object(10+i);assert(object&&*object->type_f4==11);auto* zone=zone_factory.find(object->identity);assert(zone&&zone->module()==modules[i]->receiver->base().identity());assert(rooms->rooms()[i]->flags24==1&&rooms->rooms()[i]->source_room1c==UINT32_MAX);}if(!floors::post_load(*floors,e)){std::cerr<<e;return 1;}assert(rooms->publish_collision_bounds(e));for(unsigned i=0;i<9;++i)assert(!std::memcmp(&floors->collision_rooms[i].bounds,&rooms->rooms()[i]->bounds,sizeof(octree::Box)));assert(!std::memcmp(&floors->collision_world.bounds,&rooms->bounds(),sizeof(octree::Box)));for(auto& m:modules){bool eligible=false;if(!m->receiver->init_final(eligible,e)){std::cerr<<e;return 1;}assert(eligible&&m->runtime.object.user==m->receiver->base().identity());assert(*m->receiver->base().pointer(0x180)==0);auto visual=graph->visual(*m->receiver->base().pointer(0x2d8));assert(visual);}
std::shared_ptr<CanonicalModuleFilesV1> file_relay;
require(CanonicalModuleFilesV1::create(archive,fixture.manager,dispatch,{[](bool ok,std::string&){return ok;},[](std::string&){return true;}},level,bytes,file_relay,e),e);
require(file_relay->begin_module(0,e),e);auto load_borrow=file_relay->load_borrow();
require(!modules[0]->receiver->load({},load_borrow,e),"unavailable authored chest construction silently succeeded");
require(file_relay->file_count()==1&&!file_relay->file(0).attempts().empty(),"original MGP failure source missing");
const auto& failed=*file_relay->file(0).attempts().back();
require(*failed.source().entry().source().attribute("gametype")=="OpenableContainer"&&failed.factory_attempt()->prefix()==CanonicalFactoryStageV1::empty,"first MGP constructor boundary changed");
require(*load_borrow.object_module_id18c==modules[0]->receiver->module_id(),"failed actual Module load erased SAME Level module ID");
// Explicit graph/map fixture teardown, not whole Level/candidate destruction.
// Failed MGP journals remain retained until this test scope is destroyed.
for(auto& m:modules)require(graph->release(m.get(),e),e);
for(auto id:map->children())assert(map->remove(id,e));assert(map->release(e)&&roots->roots().empty());std::cout<<"{\"validation\":\"PASS\",\"original_mlx_declarations\":10,\"actual_modules\":9,\"floor_clones\":16,\"exits\":19,\"generated_zones\":9,\"actual_init_final\":9,\"first_mgp_missing_type\":\"OpenableContainer\",\"outer_provider_fixtures\":true,\"full_loader_verified\":false}\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
