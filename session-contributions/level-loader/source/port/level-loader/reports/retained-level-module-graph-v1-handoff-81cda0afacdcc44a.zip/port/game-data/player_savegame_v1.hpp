#pragma once
#include "skill_tables.hpp"
#include <array>
#include <map>
namespace dh2::data {
struct SavedSkill8V1 {std::int32_t id;std::uint16_t level;std::uint8_t flag,reserved;};
struct PlayerProfileSpan24V1 {const std::uint8_t* data;std::uint32_t size,cursor,reserved0,reserved1;};
struct SavedSkillsView16V1 {SavedSkill8V1* rows;std::uint32_t count,reserved;};
struct SavedSkillsLoadServices32V1 {
 void* context;
 std::int32_t (*skill_id)(void*,const std::uint8_t*,std::uint32_t);
 std::uint32_t* (*slot_value)(void*,std::uint32_t set,std::int32_t key);
 void (*read_observer)(void*,std::uint32_t bytes);
};
static_assert(sizeof(SavedSkill8V1)==8&&sizeof(PlayerProfileSpan24V1)==24);
static_assert(sizeof(SavedSkillsView16V1)==16&&sizeof(SavedSkillsLoadServices32V1)==32);
struct SavedSkillUpdateServicesV1 {void* context{};bool (*update_skills)(void*,std::uintptr_t character,std::string&){};};
struct SavedFaery4V1 {std::uint8_t state,reserved;std::uint16_t level;};
static_assert(sizeof(SavedFaery4V1)==4);
// Owns the recovered PlayerSavegame fields used by HUD. A blank constructor is
// source state, not a ready campaign player. The campaign section index, quests,
// quests and campaign creation/class/gear producers remain separate owners.
class PlayerSavegameV1 {
 std::int32_t slot_{-1},level_{},class_{-1};std::string name_;
 std::uintptr_t character_{};bool skills_initialized_{};
 std::vector<SavedSkill8V1> skills_;std::array<std::map<std::int32_t,std::uint32_t>,2> slots_;
 std::array<std::array<SavedFaery4V1,5>,3> faeries_{};std::array<bool,3> faeries_initialized_{};
 std::array<std::int32_t,3> current_faery_{};std::int32_t unlocked_difficulty_{};
public:
 PlayerSavegameV1()=default;
 PlayerSavegameV1(const PlayerSavegameV1&)=delete;PlayerSavegameV1& operator=(const PlayerSavegameV1&)=delete;
 void set_character(std::uintptr_t identity)noexcept{character_=identity;}
 void set_slot(std::int32_t slot)noexcept{slot_=slot;}
 bool initialize_skills(const std::vector<std::int32_t>& actual_character_skill_list,std::string&);
 // Original named skills section. Retains reached writes on truncated input;
 // source duplicate entries overwrite, missing names consume/discard levels,
 // loaded maps are merged without clearing or validating saved index values.
 int load_skills(Bytes,SkillTables::Borrow,std::size_t& consumed,std::string&);
 // Only the actual name/level/class named sections; no new outer file format.
 bool load_name(Bytes,std::size_t&,std::string&);
 bool load_level(Bytes,std::size_t&,std::string&);
 bool load_class(Bytes,const std::vector<std::string>& genuine_class_names,std::size_t&,std::string&);
 void initialize_faeries()noexcept; // Source literal five rows, three difficulties.
 bool load_current_faery(Bytes,std::size_t&,std::string&);
 bool load_faeries(Bytes,std::size_t&,bool& source_count_mismatch,std::string&);
 // The first difficulty word belongs to source global CurrentDifficulty;
 // caller must deliver that store before the second per-savegame word read.
 bool load_difficulty(Bytes,void* context,bool (*store_selected)(void*,std::int32_t,std::string&),std::size_t&,std::string&);
 bool set_faery_level(std::uint32_t id,std::int32_t value,std::uint32_t difficulty,std::string&);
 bool set_faery_state(std::uint32_t id,std::int32_t value,std::uint32_t difficulty,std::string&);
 std::int32_t faery_level(std::uint32_t id,std::uint32_t difficulty)const noexcept;
 std::int32_t current_faery(std::uint32_t difficulty)const noexcept;
 const std::array<std::array<SavedFaery4V1,5>,3>& faeries()const noexcept{return faeries_;}
 const std::array<bool,3>& faeries_initialized()const noexcept{return faeries_initialized_;}
 const std::array<std::int32_t,3>& current_faeries()const noexcept{return current_faery_;}
 std::int32_t unlocked_difficulty()const noexcept{return unlocked_difficulty_;}
 bool set_skill_level(std::uint32_t row,std::int32_t level,std::string&);
 bool set_skill_in_slot(std::int32_t slot,std::uint32_t row,const SavedSkillUpdateServicesV1&,std::string&);
 std::int32_t skill_id(std::uint32_t row)const noexcept;
 std::int32_t skill_level(std::uint32_t row)const noexcept;
 std::int32_t skill_in_slot(std::int32_t slot)const noexcept;
 std::int32_t skill_slot(std::uint32_t row)const noexcept;
 bool has_skill_slots()const noexcept{return !slots_[0].empty();}
 const std::vector<SavedSkill8V1>& skills()const noexcept{return skills_;}
 const std::array<std::map<std::int32_t,std::uint32_t>,2>& skill_slots()const noexcept{return slots_;}
 bool skills_initialized()const noexcept{return skills_initialized_;}
 std::int32_t slot()const noexcept{return slot_;}std::int32_t level()const noexcept{return level_;}
 std::int32_t class_id()const noexcept{return class_;}const std::string& name()const noexcept{return name_;}
 std::uintptr_t character()const noexcept{return character_;}
};
}
extern "C" {
// 0 delivered, -1 malformed native entry, -2 truncated stream, -3 required
// storage service failed. Counts retain original signed-loop semantics. No
// bounds-unsafe source Debug continuation is accepted as a valid native span.
int dh2_player_skills_v1_load(dh2::data::SavedSkillsView16V1*,dh2::data::PlayerProfileSpan24V1*,const dh2::data::SavedSkillsLoadServices32V1*) noexcept;
int dh2_saved_skill_v1_level(const dh2::data::SavedSkillsView16V1*,std::uint32_t) noexcept;
int dh2_saved_skill_v1_set_level(dh2::data::SavedSkillsView16V1*,std::uint32_t,std::int32_t) noexcept;
int dh2_inventory_v1_quantity(std::uint32_t raw16) noexcept;
int dh2_inventory_v1_current_equipment(std::uint32_t raw8,std::int32_t requested) noexcept;
std::uint32_t dh2_inventory_v1_swap_equipment(std::uint32_t raw8) noexcept;
}
