#include "canonical_module_graph_v3.hpp"
#include "canonical_openable_graph_v4.hpp"
#include <iomanip>
#include <cstdlib>
#include "../module_draw_frame_v1.hpp"
#include "../retained_level_module_graph_v1.hpp"
#include "../canonical_level_class_dispatch_v1.hpp"
#include "module_room_zone_spawn_v3.hpp"
#include "canonical_point3d_globals_v1.hpp"
#include "object_enable_condition_v2.hpp"
#include "navigation_producers.hpp"
#include "module_pf_actor_connection_v3.hpp"
#include "light_set_name_owner_v3.hpp"
#include "canonical_receiver_transport_v1.hpp"
#include "canonical_cached_file_v1.hpp"
#include "canonical_module_files_v1.hpp"
#include "canonical_level_context_v1.hpp"
#include "level_config_publication_v2.hpp"
#include <stdexcept>
#include <cassert>
#include <cstring>
#include <fstream>
#include <iterator>
#include <iostream>
using namespace dh2;using namespace dh2::world;using namespace dh2::loader;
static void require(bool ok,const std::string& e){if(!ok)throw std::runtime_error(e);}
static assets::ZipAssetPackV1 pack(const char* path){
 auto f=std::make_shared<std::ifstream>(path,std::ios::binary|std::ios::ate);require(bool(*f),"cache unavailable");
 assets::ZipBackingV1 b;b.owner=f;b.bytes=std::uint64_t(f->tellg());b.read=[f](std::uint64_t at,void* out,std::size_t n,std::string& e){f->clear();f->seekg(std::streamoff(at));f->read(static_cast<char*>(out),std::streamsize(n));if(!*f){e="cache read failure";return false;}return true;};
 assets::ZipAssetPackV1 z;std::string e;require(z.mount(std::move(b),"com.gameloft.android.GAND.GloftD2SS/files/",e),e);return z;
}
// Standalone original-cache GameDesign table setup for this source probe.
// The application must borrow its existing initialized Arrays/GameDesign.
struct CharacterTables {
 std::vector<std::vector<std::uint8_t>> raw;
 character::CharacterGameDesign design;data::Dictionary models;data::LootTablesV2 loot;
 explicit CharacterTables(assets::ZipAssetPackV1& archive){
  raw.reserve(32);std::string e;
  auto bytes=[&](const std::string& name){raw.emplace_back();bool found{};require(archive.read("data/pydata/"+name,found,raw.back(),e)&&found,"Required original Character table "+name+": "+e);auto& b=raw.back();return data::Bytes{b.data(),b.size()};};
  character::GameDesignInputs256 input{};character::GameDesignTableInput48* tables[]{&input.characters,&input.classes,&input.ai,&input.factions,&input.levels};const char* prefixes[]{"character_properties","character_classes","ai","ai_factions","levels"};
  for(unsigned i=0;i<5;++i)*tables[i]={bytes(std::string(prefixes[i])+"_pyarray.bin"),bytes(std::string(prefixes[i])+"_pyarraynames.bin"),bytes(std::string(prefixes[i])+"_pystructnames.bin")};
  require(design.initialize(input,e),e);
  require(data::load_dictionary(bytes("character_models_dictionary_pyarraynames.bin"),bytes("character_models_dictionary_pyarray.bin"),models,e),e);
  require(loot.load(bytes("loot_table_pyarray.bin"),bytes("loot_table_pyarraynames.bin"),bytes("loot_table_pystructnames.bin"),e),e);
 }
};
// Platform/local-player/network/Handle transports below are explicit fixtures.
// Constructors, defaults, conditions, visual, PF room, Spawn and Zone are real.
struct Fixture {
 std::shared_ptr<void> pin;CanonicalObjectManagerV1 manager;
 Fixture(std::shared_ptr<void> p):pin(p),manager({this,nullptr,nullptr,nullptr,nullptr,network,nullptr}){}
 static bool network(void*,CanonicalObjectBorrowV1&,std::string&){return true;}
 static bool resolve(void* p,target_providers::Handle16& h,bool,const CanonicalObjectBorrowV1*& out,std::string&){out=static_cast<Fixture*>(p)->manager.object(h.key);if(out)h.cached=out->identity;return true;}
 static bool profile(void*,bool& character,bool& profile,std::uint8_t& flag,std::string&){character=true;profile=false;flag=0;return true;}
 static bool condition(void*,const CanonicalObjectBorrowV1& o,bool mark,std::string& e){auto* b=static_cast<CanonicalGameObjectBaseOwnerV1*>(o.context);bool enabled;return object_test_enable_condition_v2({b->byte(0x8a),b->integer(0xec),b->byte(0xf1),b->pointer(0xa8),b->byte(0xac)},{nullptr,profile,nullptr,nullptr,nullptr},mark,enabled,e);}
};
int main(int argc,char** argv){if(argc!=2)return 2;try{
 auto archive=pack(argv[1]);CharacterTables character_tables(archive);auto application=std::make_shared<ApplicationSpawnRandomOwnerV4>();std::string e;bool found=false;auto bytes=std::make_shared<std::vector<std::uint8_t>>();
 require(archive.read("data/3D/Modules/Swamp/swamp.bdae",found,*bytes,e)&&found,e);
 std::shared_ptr<CanonicalLevelContextV1> level;require(CanonicalLevelContextV1::create({"SWAMP","data/scene/001_swamp.mlx"},bytes,level,e),e);
 // Online/Handle are explicit standalone transport fixtures; RNG and SAME
 // canonical base state are actual. Required delete/visibility paths stay absent.
 auto spawn_for=[application](CanonicalGameObjectBaseOwnerV1& base,std::int32_t& roll,std::string& error){CanonicalSpawnApplicationServicesV4 services;services.application_lease=application;services.random=application.get();services.online_byte5=[](bool& value,std::string&){value=false;return true;};services.handle_as_player=[](bool& value,std::string&){value=false;return true;};std::int32_t probability{};return canonical_check_spawn_probability_v4(base,services,roll,probability,error);};
 auto level_fields=level->config_fields();CanonicalLevelModuleBindingsV2* owned_bindings=nullptr;
 // Explicit empty name-vector/provider fixture; authored sound names remain
 // intact and publish -1. Complete Arrays/Sound/GSLevel initialization is open.
 std::vector<std::string> sound_names;unsigned config_queries=0;
 auto roots=std::make_shared<GameObjectSceneRootRegistryV1>();auto floors=std::make_shared<floors::World>();auto map=std::make_shared<SceneManagerMapOwnerV2>(roots);ModulePFDebugV3 debug;debug.owner=bytes;debug.query=[](const char* key,bool& v,std::string&){assert(std::string(key)=="isTracingNavMeshLoadTime");v=false;return true;};auto rooms=std::make_shared<ModulePFRoomsV3>(floors,map,debug);
 unsigned template_assertions=0;
 // Explicit diagnostic-delivery fixture. Production callers must supply their
 // real Debug/assertion policy; this does not invent templates or descriptors.
 CanonicalPropertyMapV1 properties({&template_assertions,&canonical_vec3_origin_v1(),[](void* p,std::string&){++*static_cast<unsigned*>(p);return true;}});Fixture fixture(bytes);unsigned zone_pf=0;
 CanonicalRoomZoneFactoryV3 zone_factory({bytes,[&](const std::shared_ptr<CanonicalRoomZoneRecordV3>& r,RoomZoneServicesV3& s,std::string&){std::weak_ptr<CanonicalRoomZoneRecordV3> weak=r;s.game_object.owner=bytes;s.game_object.check_spawn_probability=[weak,spawn_for](std::int32_t& roll,std::string& e){auto r=weak.lock();return r&&spawn_for(r->receiver->base(),roll,e);};s.game_object.condition_init=[weak](std::uint32_t offset,std::string& e){auto r=weak.lock();return r&&condition_data_init_v3(r->receiver->base(),offset,{},e);};s.game_object.set_position=[weak](const float* p,bool dest,std::string& e){auto r=weak.lock();return r&&game_object_set_position_v2(r->receiver->base(),p,dest,{},e);};s.game_object.device_high_performance=[](bool& high,std::string&){high=true;return true;};s.game_object.load_visual=[weak](std::string& e){auto r=weak.lock();GameObjectVisualAssetOwnerV1 asset(r->receiver->base(),{});return asset.load_visual(e);};s.game_object.update_pf_object=[&,weak](std::string&){auto r=weak.lock();navigation::ProducerRequest q{};q.object=&r->runtime.object;++zone_pf;return dh2_nav_update_game_object(&q)==0;};return true;}});
 CanonicalSpawnServicesV1 spawn;spawn.context=&fixture;spawn.resolve=Fixture::resolve;spawn.test_enable_condition=Fixture::condition;ModuleRoomZoneSpawnV3 zones(fixture.manager,properties,zone_factory,spawn);
 std::uint32_t counter=0;unsigned pf_calls=0;navigation::ObstacleEntry obstacle_entries[128]{};std::uint32_t obstacle_floors[64]{};navigation::ObstacleRegistry obstacles{obstacle_entries,0,128,obstacle_floors,0,64};LightSetNameOwnerV3 lights;assert(lights.get_id("SceneLight")==1&&lights.get_id("absent")==0);CanonicalModuleGraphServicesV3 services;services.candidate=bytes;services.rooms=rooms;services.visual.owner=bytes;services.visual.roots=roots;services.visual.root_update_counter=&counter;services.visual.driver_type=[](std::int32_t& d,std::string&){d=8;return true;};services.visual.modular_meshes=[](std::vector<std::uintptr_t>& meshes,std::string&){meshes.clear();return true;};services.read_asset=[bytes](const std::string& name,std::shared_ptr<const std::vector<std::uint8_t>>& b,bool& found,std::string&){assert(name=="data/3D/Modules/Swamp/swamp.bdae");b=bytes;found=true;return true;};services.update_pf=[&](CanonicalGameObjectBaseOwnerV1& b,std::string& e){assert(b.identity());++pf_calls;ModulePFActorConnectionV3 connection(b,bytes,&floors->collision_world,&obstacles);return connection.update(e);};services.spawn_zone=[&](const std::string& name,target_providers::Handle16& h,std::uint32_t& type,std::string& e){return zones.spawn(name,h,type,e);};services.zone_init=[&](target_providers::Handle16& h,const std::array<float,6>& box,std::uintptr_t module,std::string& e){return zones.init(h,box,module,e);};auto graph=std::make_shared<CanonicalModuleGraphV3>(services);ModuleRuntimeGlobalsV1 globals;std::vector<std::shared_ptr<CanonicalModuleRecordV2>> modules;
CanonicalLevelModuleConstructionV2 construction;construction.candidate=bytes;construction.module_globals=&globals;construction.level_config.owner=bytes;
construction.level_config.debug_switch=[](const char* key,bool& value,std::string&){assert(std::string(key)=="isTracingLevel");value=false;return true;};
construction.level_config.set_level_config=[&](std::uintptr_t id,std::string& e){++config_queries;LevelConfigPublicationBorrowV2 b{level_fields.level_owner,level_fields.config38,level_fields.music11c,level_fields.safezone120,level_fields.ambient124,bytes,&sound_names,[&](std::uintptr_t identity){return owned_bindings->level_config(identity);}};return level_config_publication_v2(b,id,e);};construction.module_services=[&](const CanonicalSourceObjectRequestV1&,const std::shared_ptr<CanonicalModuleRecordV2>& record,GameObjectInitializationServicesV1& init,ModuleInitServicesV1& module,std::string& e){init.owner=bytes;std::weak_ptr<CanonicalModuleRecordV2> spawn_record=record;init.check_spawn_probability=[spawn_record,spawn_for](std::int32_t& roll,std::string& e){auto r=spawn_record.lock();return r&&spawn_for(r->receiver->base(),roll,e);};init.device_high_performance=[](bool& high,std::string&){high=true;return true;};std::weak_ptr<CanonicalModuleRecordV2> weak=record;init.init_pf_object=[&,weak](bool flag,const float* p,float radius,std::uintptr_t identity,std::string& e){auto r=weak.lock();ModulePFActorConnectionV3 pf(r->receiver->base(),bytes,&floors->collision_world,&obstacles);return pf.init(flag,p,radius,identity,e);};init.light_set_id=[&](const std::string& name,std::int32_t& id,std::string&){id=lights.get_id(name);return true;};return graph->bind(record,init,module,e);};CanonicalLevelModuleBindingsV2 bindings(properties,{},construction);owned_bindings=&bindings;
CanonicalCharacterFamilyServicesV4 character_services;character_services.world=level;character_services.design=&character_tables.design;character_services.models=&character_tables.models;character_services.loot_tables=&character_tables.loot;character_services.loot_random=&application->channel(0);
// Whole Character positioning and InitPost providers remain absent. The
// factory must stop at its actual offset stage instead of writing a fake pose.
auto character_factory=std::make_shared<CanonicalCharacterFamilyFactoryV4>(character_services);
CanonicalLevelClassDispatchInputsV1 class_input;class_input.providers_owner=level;class_input.modules=&bindings;class_input.characters=character_factory;class_input.application_owner=application;class_input.random=application.get();
class_input.openable_services=[level,roots](const CanonicalSourceObjectRequestV1&,CanonicalOpenableGraphServicesV4& s,std::string&){s.world=level;s.roots=roots;return true;};
class_input.spawn_services=[application](const std::shared_ptr<CanonicalOpenableGraphV4>& graph,CanonicalSpawnApplicationServicesV4& s,std::string&){require(graph&&graph->receiver().base().identity(),"Container RNG requires actual receiver");s.application_lease=application;s.random=application.get();s.online_byte5=[](bool& value,std::string&){value=false;return true;};s.handle_as_player=[](bool& value,std::string&){value=false;return true;};return true;};
CanonicalLevelClassDispatchV1 class_dispatch(std::move(class_input));
auto& containers=class_dispatch.containers();
loader::CanonicalReceiverTransportV1 transport(properties,{level,&class_dispatch,[](void* p,const CanonicalFactoryEntryV1& f,const CanonicalSourceObjectRequestV1& q,CanonicalClassReceiverV1& r,std::string& e){return static_cast<CanonicalLevelClassDispatchV1*>(p)->construct(f,q,r,e);},nullptr});auto dispatch=transport.services();
// No copied level-specific declarations: feed the original complete MLX walk.
std::shared_ptr<RetainedLevelModuleGraphV1> preparation;
require(RetainedLevelModuleGraphV1::create({archive,level,bytes,&fixture.manager,dispatch,{[](bool ok,std::string&){return ok;},[](std::string&){return true;}},graph,floors,rooms},preparation,e),e);
const auto& source=preparation->root_file();
require(preparation->level()==level&&&preparation->manager()==&fixture.manager&&preparation->floor_world()==floors,"retained API replaced an authoritative owner");
LevelFileWalkStepV1 result=LevelFileWalkStepV1::pending;
for(unsigned n=0;n<1000&&result==LevelFileWalkStepV1::pending;++n)result=preparation->load_root_step();
require(result==LevelFileWalkStepV1::complete,source.error());require(source.attempts().size()==10,"original root declaration count changed");
for(const auto& attempt:source.attempts()){
 const auto* kind=attempt->source().entry().source().attribute("gametype");
 if(!kind||(*kind!="Module"&&*kind!="Block"))continue;
 const auto* object=fixture.manager.object(attempt->factory_attempt()->handle().key);
 require(object&&*object->type_f4==5,"actual Module registration missing");
 auto record=std::static_pointer_cast<CanonicalModuleRecordV2>(object->lease);
 require(record->receiver->base().room64()==-1,"diagnostic occurrence replaced source room64");
 require(preparation->initialize_next_module(e),e);
 require(record->receiver->module_id()==static_cast<std::int32_t>(modules.size())&&!record->receiver->load_floor_pending(),"actual Module counter/pending state mismatch");
 modules.push_back(record);
}
require(fixture.manager.object(0)==nullptr&&fixture.manager.source_next_key4c()==20,"reserved-null manager key or allocation counter mismatch");
 require(config_queries==1&&*level_fields.config38!=0,"actual config early publication missing");
assert(counter==27);assert(modules.size()==9&&rooms->rooms().size()==9&&floors->records.size()==16&&rooms->exits().size()==19);assert(fixture.manager.pending().size()==9&&fixture.manager.source_count50()==19&&globals.next_generated_zone==9&&zone_pf==9);for(unsigned i=0;i<9;++i){auto* zone=zone_factory.find(fixture.manager.pending()[i]);assert(zone);auto* object=fixture.manager.object(zone->base().shared_handle().key);assert(object&&*object->type_f4==11);assert(zone&&zone->module()==modules[i]->receiver->base().identity());assert(rooms->rooms()[i]->flags24==1&&rooms->rooms()[i]->source_room1c==UINT32_MAX);}if(!preparation->prepare_floors(e)){std::cerr<<e;return 1;}assert(preparation->status().floors_prepared);for(unsigned i=0;i<9;++i)assert(!std::memcmp(&floors->collision_rooms[i].bounds,&rooms->rooms()[i]->bounds,sizeof(octree::Box)));assert(!std::memcmp(&floors->collision_world.bounds,&rooms->bounds(),sizeof(octree::Box)));std::vector<std::shared_ptr<RetainedModuleVisualV3>> retained_visuals;for(auto& m:modules){if(!preparation->finalize_next_module(e)){std::cerr<<e;return 1;}assert(m->runtime.object.user==m->receiver->base().identity());assert(*m->receiver->base().pointer(0x180)==0);auto visual=graph->visual(*m->receiver->base().pointer(0x2d8));require(visual&&visual->controller_identity()!=0&&visual->controller_root_identity()==visual->root_identity(),"Module controller/root identity mismatch");retained_visuals.push_back(visual);}
// Rendering bridge reads the real post-PF Module graph, including removals.
std::vector<ModuleDrawFrameV1> frames;require(preparation->capture_draw_frames(frames,e),e);require(frames.size()==9&&preparation->status().geometry_prepared,"retained API geometry prefix missing");unsigned render_meshes=0;
for(unsigned k=0;k<modules.size();++k){
 auto visual=retained_visuals[k];const auto& frame=frames[k];
 
 require(frame.root_identity==visual->root_identity()&&frame.visual_identity==visual->identity(),"render frame lost SAME root/visual identity");
 const auto& root=visual->scene();const auto& selected=root.selected();unsigned expected=0;
 for(unsigned i=0;i<selected.scene.instances.size();++i)if(root.mesh_attached(i)&&selected.instance_visibility[i]&&(root.root_flags()&1u))++expected;
 require(frame.meshes.size()==expected&&expected>0,"render frame skipped attached visible meshes");
 for(const auto& draw:frame.meshes){const auto& actual=selected.scene.instances[draw.source_instance];require(draw.cached_world==actual.world&&draw.geometry==actual.geometry,"render bridge recomputed optimized cache");}
 render_meshes+=frame.meshes.size();
 // Explicit visibility transport exercise, not a fabricated condition result.
 require(visual->scene().notify_root_visibility(false,e),e);ModuleDrawFrameV1 hidden;
 require(capture_module_draw_frame_v1(visual,modules[k]->receiver->module_id(),hidden,e)&&hidden.meshes.empty(),"hidden actual root still submitted meshes");
 require(visual->scene().notify_root_visibility(true,e),e);ModuleDrawFrameV1 restored;
 require(capture_module_draw_frame_v1(visual,modules[k]->receiver->module_id(),restored,e)&&restored.meshes.size()==expected,"actual root visibility restore lost draw membership");
}
auto file_relay=preparation->module_files();auto load_borrow=file_relay->load_borrow();
require(!preparation->load_next_module_sources({},e),"unavailable authored construction silently succeeded");
require(preparation->status().failed_at==RetainedModulePreparationStageV1::module_files&&preparation->status().geometry_prepared&&!preparation->status().object_sources_complete,"retained failure lost prepared geometry or claimed whole content");
std::vector<ModuleDrawFrameV1> after_failure;require(preparation->capture_draw_frames(after_failure,e)&&after_failure.size()==9,"retained partial graph is inaccessible after object failure");
 const auto module_error=preparation->status().error;
 require(file_relay->file_count()==1&&file_relay->file(0).attempts().size()==3&&containers.size()==2,"actual MGP did not reach next Character boundary: "+module_error);
 const auto& attempts=file_relay->file(0).attempts();
 require(*attempts.back()->source().entry().source().attribute("gametype")=="Character"&&attempts.back()->factory_attempt()->prefix()==CanonicalFactoryStageV1::overrides,"next actual class boundary differs");
 const auto* config=fixture.manager.object(source.attempts().front()->factory_attempt()->handle().key);std::uint8_t across{};
 require(config&&config->read_across_rooms87(config->context,across,e)&&across==0,"documented Config repair lost");
 for(auto id:fixture.manager.pending()){auto* zone=zone_factory.find(id);const auto* object=zone?fixture.manager.object(zone->base().shared_handle().key):nullptr;require(object&&object->read_across_rooms87(object->context,across,e)&&across==0,"documented RoomZone repair lost");}
 require(fixture.manager.source_count50()==22&&fixture.manager.source_next_key4c()==23&&transport.retained_count()==13,"actual Container registration prefix differs");
 for(unsigned i=0;i<2;++i){
  const auto& attempt=*attempts[i];auto chest=containers[i];
  require(attempt.factory_attempt()->stage()==CanonicalFactoryStageV1::complete,"Container source factory did not complete");
  const auto* object=fixture.manager.object(attempt.factory_attempt()->handle().key);
  require(object&&object->identity==chest->receiver().base().identity()&&*object->type_f4==7&&*object->room64==modules[0]->receiver->module_id(),"SAME Container publication/module identity lost");
  const auto* original=canonical_source_entry_v1(attempt.source().request());
  require(original&&original->source().attribute("data_desc")&&*original->source().attribute("data_desc")=="Swamp_Normal_Chest"&&original->source().attribute("position"),"authored Container source missing");
  auto fields=chest->receiver().properties();require(fields.template_name&&*fields.template_name=="OpenableContainer","actual XML template selection differs");
  require(chest->receiver().fields().data_desc==*original->source().attribute("data_desc"),"authored Container data description discarded");
  const char* at=original->source().attribute("position")->c_str();std::array<float,3> expected{};
  for(unsigned component=0;component<3;++component){char* end=nullptr;expected[component]=static_cast<float>(std::strtod(at,&end));require(end!=at,"authored expected position parse failed");at=*end==','?end+1:end;expected[component]+=load_borrow.module_offset160[component];}
  const auto* actual=chest->receiver().base().vector3(0x160);require(std::equal(expected.begin(),expected.end(),actual),"authored Container placement discarded");
 }
 require(template_assertions==3,"named template assertion delivery count differs");
require(!preparation->load_next_module_sources({},e)&&e==module_error&&containers.size()==2,"retained preparation replayed a failed prefix");
 require(!modules[0]->receiver->load({},load_borrow,e)&&e==module_error&&containers.size()==2&&file_relay->file(0).attempts().size()==3,"failed source replayed constructors");
 require(*load_borrow.object_module_id18c==modules[0]->receiver->module_id(),"failed source erased SAME Level context");
 auto character_attempt=attempts.back()->factory_attempt();auto npc=character_factory->find(fixture.manager.object(character_attempt->handle().key)->identity);
 require(npc&&*npc->actor->source_string(0x13b0)=="WanderingPriest"&&npc->actor->source_string(0x1398)->empty(),"actual Character description/template fields lost");
 const auto* original_character=canonical_source_entry_v1(attempts.back()->source().request());std::array<float,3> source_position{};require(npc->actor->source_position(source_position,e),e);
 const char* at=original_character->source().attribute("position")->c_str();for(unsigned axis=0;axis<3;++axis){char* end{};auto expected=static_cast<float>(std::strtod(at,&end));require(source_position[axis]==expected,"authored Character position lost before required whole SetPosition");at=*end==','?end+1:end;}
 const auto rng_calls=application->channel(0).calls;
 require(!containers.front()->factory_receiver().init_post(e)&&e=="OpenableContainer required source service: GetDataId","actual Container RNG did not reach table provider");
 require(application->channel(0).calls==rng_calls+1&&*containers.front()->receiver().base().integer(0x270)==-2,"Container did not consume/cache shared application RNG");
 require(!containers.front()->factory_receiver().init_post(e)&&application->channel(0).calls==rng_calls+1,"Container replay re-rolled shared RNG");

 const auto chest_error=e;for(auto& chest:containers){require(!chest->visual(),"Container visual fabricated");require(chest->release(e),e);}
 // Explicit graph/map fixture teardown, not whole Level/candidate destruction.
// Failed MGP journals remain retained until this test scope is destroyed.
for(auto& m:modules)require(graph->release(m.get(),e),e);
 for(auto& visual:retained_visuals)require(visual->controller_identity()==0&&visual->controller_root_identity()==0&&visual->root_identity()==0,"Module release retained controller/root");
for(unsigned i=0;i<frames.size();++i){
 auto& frame=frames[i];const auto root_id=frame.root_identity;const auto count=frame.meshes.size();
 require(!capture_module_draw_frame_v1(retained_visuals[i],modules[i]->receiver->module_id(),frame,e)&&frame.root_identity==root_id&&frame.meshes.size()==count,"released root capture succeeded or destroyed prior frame");
 for(const auto& draw:frame.meshes){assets::Mesh payload{};require(dh2_mesh_open(&payload,&frame.bres,draw.geometry)==assets::Error::ok,"frame resource pin expired during visual release");}
}
unsigned release_calls=0;require(preparation->discard_after_owner_release([&](std::string& e){++release_calls;for(auto id:map->children())if(!map->remove(id,e))return false;return map->release(e);},e),e);
require(preparation->discard_after_owner_release({},e)&&release_calls==1,"retained cleanup replayed owner release");
require(roots->roots().empty(),"retained roots remained after actual release");
std::vector<ModuleDrawFrameV1> preserved=frames;require(!preparation->capture_draw_frames(preserved,e)&&preserved.size()==frames.size(),"released preparation submitted stale roots");std::cout<<"{\"validation\":\"PASS\",\"original_mlx_declarations\":10,\"actual_modules\":9,\"floor_clones\":16,\"exits\":19,\"generated_zones\":9,\"actual_init_final\":9,\"render_frame_modules\":9,\"render_frame_meshes\":"<<render_meshes<<",\"same_root_controllers\":9,\"controllers_released\":9,\"reserved_null_key0\":true,\"actual_container_constructed\":2,\"actual_container_published\":2,\"factory_failure_prefix\":\"overrides\",\"config_across_rooms_modern_repair\":true,\"room_zone_across_rooms_modern_repair\":true,\"authored_container_properties_verified\":true,\"named_template_context_modern_repair\":true,\"template_assertion_fixture\":true,\"template_context_problem\":false,\"actual_character_constructed\":1,\"character_authored_fields_verified\":true,\"shared_application_RNG_connected\":true,\"first_mgp_missing_type\":\"Character\",\"module_source_error\":"<<std::quoted(module_error)<<",\"container_init_post_missing_service\":"<<std::quoted(chest_error)<<",\"outer_provider_fixtures\":true,\"retained_application_API_verified\":true,\"full_loader_verified\":false}\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
