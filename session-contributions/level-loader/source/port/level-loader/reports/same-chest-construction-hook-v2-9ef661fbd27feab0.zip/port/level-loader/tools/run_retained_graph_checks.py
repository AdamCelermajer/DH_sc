import pathlib,subprocess,hashlib,json,zipfile,sys
root=pathlib.Path(r'C:\Users\adamc\.codex\worktrees\generic-level-loader\DH_sc');loader=root/'port/level-loader';overlay=loader/'vendor/character-rng-integration-v4'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((overlay/'integration-manifest.json').read_text())
for name,entry in manifest['files'].items():assert sha((overlay/name).read_bytes())==entry['sha256'],name
cache=pathlib.Path(r'C:\Users\adamc\Downloads\dungeonhunter2\Dungeon-Hunter-2-HD-v1-0-2-cache.zip')
assert sha(cache.read_bytes())=='3fdf4e4c21d45a780a7c35fb4042abde0e88e76bf75416aad1f227481560b679'
fixtures=json.loads((overlay/'port/level-world/reference/canonical-character-family-v4/cache-fixture-manifest.json').read_text())
with zipfile.ZipFile(cache) as z:
 for row in fixtures:
  name=row['path'].replace('\\','/');raw=(overlay/name).read_bytes();assert sha(raw)==row['sha256'],name
  assert raw==z.read('com.gameloft.android.GAND.GloftD2SS/files/data/pydata/'+pathlib.PurePosixPath(name).name),name
targets=['dh2_loader_module_graph_source_probe','dh2_loader_config_across_regression','dh2_loader_room_zone_across_regression','dh2_loader_character_family_prefix_probe','dh2_loader_application_rng_probe']
linux=lambda p:'/mnt/c/'+str(p).replace('\\','/')[3:]
asset_dir=overlay/'port/android-native/app/src/main/assets/data'
receipt={'scope':'Retained same-Level Module graph API and actual Character constructor/shared application RNG source flow; explicit outer fixtures, no complete Level constructor/gameplay claim','coherent_files_verified':len(manifest['files']),'original_character_table_assets_verified':len(fixtures),'cases':[], 'full_loader_verified':False,'visible_apk_updated':False}
receipt_path=loader/'reports/retained-level-module-graph-v2-checks.json'
if receipt_path.exists():
 old=json.loads(receipt_path.read_text())
 for name,digest in old['source_sha256'].items():assert sha((loader/name).read_bytes())==digest,name
 receipt['cases']=[case for case in old['cases'] if case['build'] not in sys.argv[1:]]
for kind in sys.argv[1:]:
 build=root.parent/'build'/('receiver-transport-'+kind)
 rows=[]
 if kind=='x86_64':
  adb_base=[r'C:\Users\adamc\AppData\Local\Android\Sdk\platform-tools\adb.exe','-s','emulator-5590']
  def adb(args):
   avd=subprocess.check_output(adb_base+['emu','avd','name'],timeout=15).decode().replace('\r','').splitlines()[0];assert avd=='DH2_Loader_API37',avd
   r=subprocess.run(adb_base+args,capture_output=True,timeout=60);assert r.returncode==0,(r.stdout,r.stderr);return r.stdout.decode(errors='replace')
  remote='/data/local/tmp/dh2-loader-retained-graph-v1';adb(['shell','mkdir','-p',remote]);adb(['push',str(asset_dir),remote+'/data'])
 for target in targets:
  binary=build/target
  if kind=='x86_64':
   adb(['push',str(binary),remote+'/'+target]);adb(['shell','chmod','755',remote+'/'+target])
   args=[remote+'/'+target]
   if target==targets[0]:args+=['/data/local/tmp/dh2-loader-map-recovery/cache.zip']
   elif target==targets[3]:args+=[remote+'/data']
   out=adb(['shell']+args)
  else:
   args=['wsl.exe','-d','Ubuntu','--',linux(binary)]
   if target==targets[0]:args+=[linux(cache)]
   elif target==targets[3]:args+=[linux(asset_dir)]
   r=subprocess.run(args,capture_output=True,timeout=60);assert r.returncode==0,(target,r.stdout,r.stderr);out=r.stdout.decode(errors='replace')
  if target==targets[0]:
   result=json.loads(out.strip().splitlines()[-1]);assert result['validation']=='PASS' and result['retained_application_API_verified'] and result['actual_character_constructed']==1 and result['shared_application_RNG_connected'] and not result['full_loader_verified']
  else:
   assert 'PASS' in out or not out.strip(),(target,out);result=out.strip()
   if target==targets[3]:assert '433 actual NPC rows' in out
  rows.append({'target':target,'binary_sha256':sha(binary.read_bytes()),'result':result})
 receipt['cases'].append({'build':kind,'probes':rows})
 print(kind,'PASS',flush=True)
receipt['validation']='PASS';receipt['arm64_binaries']={target:sha((root.parent/'build/receiver-transport-arm64-v8a'/target).read_bytes()) for target in targets}
receipt['source_sha256']={name:sha((loader/name).read_bytes()) for name in ['retained_level_module_graph_v1.hpp','retained_level_module_graph_v1.cpp','canonical_level_class_dispatch_v1.hpp','canonical_level_class_dispatch_v1.cpp','module_draw_frame_v1.hpp','module_draw_frame_v1.cpp','tests/canonical_module_graph_source_probe.cpp']}
receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'validation':'PASS','builds':sys.argv[1:],'coherent_files':len(manifest['files']),'full_loader_verified':False}))
